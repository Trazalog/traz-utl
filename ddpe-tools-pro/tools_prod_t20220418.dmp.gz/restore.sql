--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.11
-- Dumped by pg_dump version 11.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tools_prod_t;
--
-- Name: tools_prod_t; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tools_prod_t WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE tools_prod_t OWNER TO postgres;

\connect tools_prod_t

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: alm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA alm;


ALTER SCHEMA alm OWNER TO postgres;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA core;


ALTER SCHEMA core OWNER TO postgres;

--
-- Name: frm; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA frm;


ALTER SCHEMA frm OWNER TO postgres;

--
-- Name: nco; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA nco;


ALTER SCHEMA nco OWNER TO postgres;

--
-- Name: pan; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pan;


ALTER SCHEMA pan OWNER TO postgres;

--
-- Name: prd; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA prd;


ALTER SCHEMA prd OWNER TO postgres;

--
-- Name: pro; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA pro;


ALTER SCHEMA pro OWNER TO postgres;

--
-- Name: seg; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA seg;


ALTER SCHEMA seg OWNER TO postgres;

--
-- Name: sicpoa; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sicpoa;


ALTER SCHEMA sicpoa OWNER TO postgres;

--
-- Name: sta; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA sta;


ALTER SCHEMA sta OWNER TO postgres;

--
-- Name: tst; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA tst;


ALTER SCHEMA tst OWNER TO postgres;

--
-- Name: agregar_lote_articulo(bigint, double precision); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.agregar_lote_articulo(p_batch_id bigint, p_cantidad double precision) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/**
 * Función para actualizar un lote de almacen con p_batch_id
 * Si no encuentra el lote lanza excepcion BATCH_NO_EXISTE
 */
declare
	v_cuenta integer; 
	v_existencia alm.alm_lotes.cantidad%type;
begin
	with updated_lotes as (	
		update alm.alm_lotes
		set cantidad = cantidad + p_cantidad
		where batch_id = p_batch_id
		returning 1)
		
	select count(1)
	from updated_lotes
	into strict v_cuenta;

	if v_cuenta = 0 then
    	    RAISE INFO 'ALMEXLO - no se encontro el batch id % ', p_batch_id;
    	    raise 'BATCH_INEXISTENTE';
    end if;

   	RAISE INFO 'ALMEXLO - actualizando el batch id % con cantidad %', p_batch_id,p_cantidad;
    return 'CORRECTO';

exception
		when others then 
			raise;
end;
		
$$;


ALTER FUNCTION alm.agregar_lote_articulo(p_batch_id bigint, p_cantidad double precision) OWNER TO postgres;

--
-- Name: ajuste_detalle_ingresar(integer, integer, double precision); Type: PROCEDURE; Schema: alm; Owner: postgres
--

CREATE PROCEDURE alm.ajuste_detalle_ingresar(p_ajus_id integer, p_lote_id integer, p_cantidad double precision)
    LANGUAGE plpgsql
    AS $$
#print_strict_params on

declare
	v_deaj_id alm.deta_ajustes.deaj_id%type;
	v_mensaje varchar;
	v_empr_id alm.ajustes.empr_id%type;
begin
  begin
	  	
	    RAISE INFO 'Obtengo empresa de tabla ajuste con ajus_id %',p_ajus_id;

	    select empr_id 
		into strict v_empr_id
		from alm.ajustes
		where ajus_id = p_ajus_id;
		     
	    RAISE INFO 'insertando Ajustesen deta ajustes %,%,%',p_cantidad,v_empr_id,p_lote_id;

		insert into alm.deta_ajustes (
			   cantidad
	          ,empr_id
	          ,lote_id
	          ,ajus_id)
		values (
			p_cantidad
		    ,v_empr_id
		    ,p_lote_id
		    ,p_ajus_id)
		returning deaj_id into strict v_deaj_id;
		   
	    RAISE INFO 'actualizando alm_lotes % ',p_lote_id;
		   
		update alm.alm_lotes
		set cantidad = cantidad + p_cantidad
		where lote_id = p_lote_id;
	  	
		
       	exception	   
			when NO_DATA_FOUND then
		        RAISE INFO ' ajus_id inexistente %', p_ajus_id;
				v_mensaje = 'AJUS_NO_ENCONTRADO';
		        raise exception 'AJUS_NO_ENCONTRADO:%',p_ajus_id;

       		when FOREIGN_KEY_VIOLATION then
		        RAISE INFO 'lote  inexistente %', p_lote_id;
				v_mensaje = 'LOTEALM_NO_ENCONTRADO';
		        raise exception 'LOTEALM_NO_ENCONTRADO:%',p_lote_id;
		       
		end;	

exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
		raise warning 'ajuste_detalle_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;
END; 
$$;


ALTER PROCEDURE alm.ajuste_detalle_ingresar(p_ajus_id integer, p_lote_id integer, p_cantidad double precision) OWNER TO postgres;

--
-- Name: crear_lote_articulo(integer, integer, integer, character varying, double precision, date, integer, bigint); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.crear_lote_articulo(p_prov_id integer, p_arti_id integer, p_depo_id integer, p_codigo character varying, p_cantidad double precision, p_fec_vencimiento date, p_empr_id integer, p_batch_id bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/**
 * Crea un nuevo lote para un articulo determinado en el deposito informado
 */
begin

	insert into alm.alm_lotes (
	prov_id
	,arti_id
	,depo_id
	,codigo
	,cantidad
	,fec_vencimiento
	,empr_id
	,estado
	,batch_id)
	VALUES( 
	p_prov_id
	,p_arti_id
	,p_depo_id
	,p_codigo
	,p_cantidad
	,p_fec_vencimiento
	,p_empr_id
	,'AC'
	,p_batch_id);

	return 'CORRECTO';

exception
	when unique_violation then 
		RAISE INFO 'error al insertar % : %',sqlerrm,sqlstate;
    	RAISE 'DUP_VAL_LOTALM';
    
    when others then 
		RAISE INFO 'error al insertar % : %',sqlerrm,sqlstate;
    	RAISE;
end;
	-- Enter function body here
$$;


ALTER FUNCTION alm.crear_lote_articulo(p_prov_id integer, p_arti_id integer, p_depo_id integer, p_codigo character varying, p_cantidad double precision, p_fec_vencimiento date, p_empr_id integer, p_batch_id bigint) OWNER TO postgres;

--
-- Name: crear_relacion_case_empresa(); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.crear_relacion_case_empresa() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      /** funcion on insert para insertar relacion case_id con empresa
          *
          */
          INSERT INTO core.case_empresa
          (case_id, empr_id)
          values(new.case_id, new.empr_id)
          ;
    END;
  $$;


ALTER FUNCTION alm.crear_relacion_case_empresa() OWNER TO postgres;

--
-- Name: eliminar_lote_articulo(bigint); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.eliminar_lote_articulo(p_batch_id bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/**
 * Elimina el lote creado anteriorimente
 */
begin

	delete from alm.alm_lotes 
	where batch_id = p_batch_id;

	return 'CORRECTO';

exception
    
    when others then 
		RAISE INFO 'error al eliminar % : %',sqlerrm,sqlstate;
    	RAISE;
end;
	-- Enter function body here
$$;


ALTER FUNCTION alm.eliminar_lote_articulo(p_batch_id bigint) OWNER TO postgres;

--
-- Name: extraer_lote_articulo(bigint, double precision); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.extraer_lote_articulo(p_batch_id bigint, p_cantidad double precision) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/**
 * Función para actualizar un lote de almacen con p_batch_id
 * Si no encuentra el lote lanza excepcion BATCH_NO_EXISTE
 */
declare
	v_updated integer; 
	v_existencia alm.alm_lotes.cantidad%type;
begin
	
	select cantidad
	into strict v_existencia
	from alm.alm_lotes
	where batch_id = p_batch_id;

	if v_existencia >= p_cantidad then
		update alm.alm_lotes
		set cantidad = cantidad - p_cantidad
		where batch_id = p_batch_id;
	else 
    	    RAISE INFO 'ALMEXLO - la cantidad no puede ser negativa  existencia % ', v_existencia;
    	    raise 'CANT_MAYOR_EXISTENCIA';
    end if;

    return 'CORRECTO';

	exception
		when NO_DATA_FOUND then 
	 	  RAISE INFO 'ALMEXLO - batch no encontrado %', p_batch_id;
    	  raise 'BATCH_NO_EXISTE';
		when others then 
			raise;
end;
		
$$;


ALTER FUNCTION alm.extraer_lote_articulo(p_batch_id bigint, p_cantidad double precision) OWNER TO postgres;

--
-- Name: fnupdateresto(); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.fnupdateresto() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		update alm.alm_deta_pedidos_materiales set resto = new.cantidad
		where depe_id = new.depe_id;
	    return new; 
	END;
$$;


ALTER FUNCTION alm.fnupdateresto() OWNER TO postgres;

--
-- Name: obtener_existencia_batch(bigint); Type: FUNCTION; Schema: alm; Owner: postgres
--

CREATE FUNCTION alm.obtener_existencia_batch(p_batch_id bigint) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
declare	
	v_cantidad alm.alm_lotes.cantidad%type =0;
begin
	select sum(cantidad)
	into strict v_cantidad
	from alm.alm_lotes
	where batch_id = p_batch_id;

	return v_cantidad;
exception
	when no_data_found then	
		raise 'BATCH_INEXISTENTE';

end;

$$;


ALTER FUNCTION alm.obtener_existencia_batch(p_batch_id bigint) OWNER TO postgres;

--
-- Name: set_tabla_id_trg(); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.set_tabla_id_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  declare
  	v_mensaje varchar;
    v_tabla varchar;
  BEGIN
    /** calculo el id de tabla concatenando el nombre de tabla y el valor
     *  Si hay empr_id, entonces la tabla se llamara empresa-tabla
     */
	v_tabla = new.tabla;
	if new.empr_id is not null and (old.empr_id is null or old.empr_id != new.empr_id) then 
		v_tabla = new.empr_id||'-'||new.tabla;
	end if;
	new.tabl_id = v_tabla||new.valor;
    new.tabla= v_tabla;

	return new;

exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'SETTABLAID: error generando tabla _id %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;
end;

$$;


ALTER FUNCTION core.set_tabla_id_trg() OWNER TO postgres;

--
-- Name: ult_modificacion_trg(); Type: FUNCTION; Schema: core; Owner: postgres
--

CREATE FUNCTION core.ult_modificacion_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		new.fec_ult_modificacion = now();
		return new;
	exception 
		when others then 
	    	raise warning 'ult_modif: error al setear fecha ult modif %: %', sqlstate,sqlerrm;

	END;
$$;


ALTER FUNCTION core.ult_modificacion_trg() OWNER TO postgres;

--
-- Name: increment_info_id_batch(); Type: FUNCTION; Schema: frm; Owner: postgres
--

CREATE FUNCTION frm.increment_info_id_batch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		perform nextval('frm.instancias_formularios_info_id_batch_seq');
		return null;
end $$;


ALTER FUNCTION frm.increment_info_id_batch() OWNER TO postgres;

--
-- Name: asociar_lote_hijo_trg(); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.asociar_lote_hijo_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  declare
  v_batch_id_hijo prd.lotes.batch_id%type;
  v_cantidad_hijo alm.alm_deta_entrega_materiales.cantidad%type;
  v_batch_id alm.alm_lotes.batch_id%type;
  v_mensaje varchar;
  v_aux int4;
  BEGIN
    /** primero obtengo el batch_id hijo
     * 
     */
	BEGIN  
		select batch_id
		into strict v_batch_id_hijo
		from alm.alm_pedidos_materiales pema
		     ,alm.alm_entrega_materiales enma
		where pema.pema_id = enma.pema_id
	    and enma.enma_id = new.enma_id;
	   
	   	raise info 'TRASLOHI: batch_id_hijo : %',v_batch_id_hijo;

	exception	
		when no_data_found then 
	        RAISE INFO 'TRASLOHI - error  - Entrega o pedido no existente %', new.enma_id;
			v_mensaje = 'ENMA_NO_ENCONTRADO';
	        raise exception 'ENMA_NO_ENCONTRADO:%',new.enma_id;
	end;
	
	/** Obtengo el batch id del lote de la linea entregada actual **/
	begin
		select batch_id
		into v_batch_id
		from alm.alm_lotes
		where lote_id = new.lote_id;

		raise info 'TRASLOHI: batch id actual : %',v_batch_id;

		-- si viene batch id vacio quiere decir que es un lote ingresado por fuera de produccion
	    IF v_batch_id IS NULL OR v_batch_id = 0 THEN 
	    	RETURN NEW;
	    END IF;
	   
	exception	
		when no_data_found then 
	        RAISE INFO 'TRASLOHI - error  - alm lote inexistente %', new.lote_id;
			--v_mensaje = 'ALOT_NO_ENCONTRADO';
	        --raise exception 'ALOT_NO_ENCONTRADO:%',new.lote_id;
		    return new; -- La recepcion no es de produccion, con lo cual no hay batch_id

	end;
	
	/** Verifico si ya se asocio un batch_padre al hijo, sino inserto un registro nuevo de lote hijo**/

	begin
		select 1
		into strict v_aux
		from prd.lotes_hijos
		where batch_id = v_batch_id_hijo
		and batch_id_padre is null;
	
		raise info 'TRASLOHI: hay hijos sin padre con batch id : %',v_batch_id_hijo;

	    update prd.lotes_hijos
	    set batch_id_padre = v_batch_id
	    where batch_id = v_batch_id_hijo
	    and batch_id_padre is null;
	    
	exception
		when no_data_found then 
			/** El lote hijo ya tiene un padre, creo una nueva linea padre para el articulo actual**/
			raise info 'TRASLOHI: NO hay hijos sin padre con batch id : %',v_batch_id_hijo;

			select distinct(cantidad)
			into strict v_cantidad_hijo
			from prd.lotes_hijos
			where batch_id = v_batch_id_hijo;
			
			raise info 'TRASLOHI: cantidad hijo : %',v_cantidad_hijo;
			insert into prd.lotes_hijos
			(batch_id
			 ,batch_id_padre
			 ,empr_id
			 ,cantidad
			 ,cantidad_padre)	
			values(
			v_batch_id_hijo
			,v_batch_id
			,new.empr_id
			,v_cantidad_hijo
			,new.cantidad);

	end;
    
    return new;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'TRASLOHI: error actualizando lotes hijos %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;
end;

$$;


ALTER FUNCTION prd.asociar_lote_hijo_trg() OWNER TO postgres;

--
-- Name: audit_lote(bigint, character varying, character varying); Type: PROCEDURE; Schema: prd; Owner: postgres
--

CREATE PROCEDURE prd.audit_lote(p_batch_id bigint, p_mensaje character varying, p_paso character varying)
    LANGUAGE plpgsql
    AS $$
	/* Audita actividad en operaciones sobre un lote*/
	begin
		raise info 'AUDITANDO %',p_batch_id;

		insert into prd.lotes_audit_log (batch_id ,mensaje ,paso ) 
		values (p_batch_id, p_mensaje, p_paso);

	exception	
		when others then
			begin
	    		raise warning 'audit_lote: error al auditar lote %: %', sqlstate,sqlerrm;
	    	end;
	END;
$$;


ALTER PROCEDURE prd.audit_lote(p_batch_id bigint, p_mensaje character varying, p_paso character varying) OWNER TO postgres;

--
-- Name: cambiar_recipiente(bigint, integer, integer, integer, character varying, character varying, double precision); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.cambiar_recipiente(p_batch_id_origen bigint, p_reci_id_destino integer, p_etap_id_destino integer, p_empre_id integer, p_usuario_app character varying, p_forzar_agregar character varying, p_cantidad double precision DEFAULT 0) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
#print_strict_params on

declare
	v_result_lote varchar;
	v_mensaje varchar;
	v_updated integer; 
	v_lote_id prd.lotes.lote_id%type;
	v_num_orden_prod prd.lotes.num_orden_prod%type;
    v_depo_id_destino alm.alm_depositos.depo_id%type;
    v_arti_id prd.lotes.arti_id%type;
    v_prov_id alm.alm_lotes.prov_id%type;
    v_fec_vencimiento alm.alm_lotes.fec_vencimiento%type;
    v_existencia alm.alm_lotes.cantidad%type;
begin

		begin
	        RAISE INFO 'seleccionando datos para lote = %, p_lote_id', p_batch_id_origen;

		   /** tomos los datos del lote de origen a copiar en el nuevo lote **/
		    select lo.lote_id
		    	,lo.num_orden_prod
		    	,al.arti_id
		    	,al.prov_id
		    	,al.fec_vencimiento
		    into strict v_lote_id
		    	 , v_num_orden_prod
		    	 , v_arti_id
		    	 , v_prov_id
		    	 , v_fec_vencimiento
		    from prd.lotes lo
		    	, alm.alm_lotes al
		    where lo.batch_id = p_batch_id_origen
		    and al.batch_id = lo.batch_id;
		   
	        RAISE INFO 'batch, lote, ord prod, arti_id ,prov_id, orden_prod= %, % , % , % , % , %', p_batch_id_origen,v_lote_id,v_num_orden_prod,v_arti_id,v_prov_id,v_fec_vencimiento;

       	exception	   
			when NO_DATA_FOUND then
		        RAISE INFO 'batch no existe %', p_batch_id_origen;
				v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',p_batch_id_origen;
		       
		end;	

	    begin
	        /** obtengo el deposito de destino del recipiente
	         * de destino
	         */
		    select reci.depo_id
		    into strict v_depo_id_destino
		    from prd.recipientes reci
		    where reci.reci_id = p_reci_id_destino;

	   exception	   
			when NO_DATA_FOUND then
		        RAISE INFO 'recipiente no existe %', p_reci_id_destino;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id_destino;
		       
		end;	
	
		/* Si la cantidad informada es 0, hay que vaciar el lote entero y llevarlo al nuevo recipiente,
		 * sino descuento parcial
		 */
	
		v_existencia = alm.obtener_existencia_batch(p_batch_id_origen);

	 	/* si la cantidad es mayor a la existencia abortamos, sino uso la variable v_existencia para descontar
	 	 * con el valor solicitado por parametro
	 	 */
		if p_cantidad != 0 then
			if p_cantidad > v_existencia then	
			    RAISE INFO 'cantidad mayor a existencia %:%',p_cantidad,v_existencia;
				v_mensaje = 'CANT_MAYOR_EXISTENCIA';
		        raise exception 'CANT_MAYOR_EXISTENCIA:%:%',p_cantidad,v_existencia;
		    else
				v_existencia = p_cantidad;
			end if;
		end if;
	
		/** Crea el batch
		 *  para el movimiento de destino
		 */	   
	   	v_result_lote =
		   	prd.crear_lote(
		   	v_lote_id
		   	,v_arti_id
		   	,v_prov_id
		   	,p_batch_id_origen
		   	,v_existencia
		   	,v_existencia
		   	,v_num_orden_prod  
		   	,p_reci_id_destino 
		   	,p_etap_id_destino
		   	,p_usuario_app 
		   	,p_empre_id
		   	,p_forzar_agregar
		    ,v_fec_vencimiento);
	
	
		return 'CORRECTO';
exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
		raise warning 'cambiar_recipiente: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;
END; 
$$;


ALTER FUNCTION prd.cambiar_recipiente(p_batch_id_origen bigint, p_reci_id_destino integer, p_etap_id_destino integer, p_empre_id integer, p_usuario_app character varying, p_forzar_agregar character varying, p_cantidad double precision) OWNER TO postgres;

--
-- Name: crear_lote(character varying, integer, integer, bigint, double precision, double precision, character varying, integer, integer, character varying, integer, character varying, date, integer, character varying, character varying, bigint); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_lote(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying DEFAULT 'false'::character varying, p_fec_vencimiento date DEFAULT NULL::date, p_recu_id integer DEFAULT NULL::integer, p_tipo_recurso character varying DEFAULT NULL::character varying, p_planificado character varying DEFAULT 'false'::character varying, p_batch_id bigint DEFAULT NULL::bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** Funcion para generar un nuevo lote
 *  Recibe como parametro un id de lote
 *  y un recipiente donde crear el batch.
 *  Si el recipiente esta ocupado, devuelve el error
 */
#print_strict_params on
DECLARE
 v_estado_recipiente prd.recipientes.estado%type; 
 v_batch_id prd.lotes.batch_id%type;
 v_mensaje varchar;
 v_reci_id_padre prd.recipientes.reci_id%type;
 v_depo_id prd.recipientes.depo_id%type;
 v_lote_id prd.lotes.lote_id%type;
 v_arti_id alm.alm_lotes.arti_id%type;
 v_cantidad_padre alm.alm_lotes.cantidad%type;
 v_recu_id prd.recursos_lotes.recu_id%type;
 v_resultado varchar;
 v_estado varchar;
 v_cantidad float;
 v_cuenta integer;
BEGIN
		
	/* seteo el estado inicial dependiendo si se llama al procedure desde Guardar o desde Planificar estapa */
		if (p_planificado='true') then
			v_estado = 'PLANIFICADO';
		else
			v_estado = 'En Curso';
		end if;
		
		/**************************
		 * BLOQUE 1: VALIDO EL ESTADO DEL RECIPIENTE
		 */
		begin
		        
			RAISE INFO 'PRDCRLO - ṕ_forzar_agregar = %, p_lote_id % y p_batch_id_padre %: ', p_forzar_agregar, p_lote_id, p_batch_id_padre;

			select reci.estado
				   ,reci.depo_id
			into strict v_estado_recipiente
				,v_depo_id
			from PRD.RECIPIENTES reci
			where reci.reci_id = p_reci_id;

			/** Valido que el recipiente exista y no tenga contenido **/
		    if (p_forzar_agregar!='true') and p_planificado = 'false' then
				
				    if v_estado_recipiente != 'VACIO' then
		
				        RAISE INFO 'PRDCRLO - error 1 - recipiente lleno , estado = % ', v_estado_recipiente;
		                v_mensaje = 'RECI_NO_VACIO';
				    	raise exception 'RECI_NO_VACIO:%',p_reci_id;
				    end if;
				   
		    end if;
		exception	   
			when too_many_rows then
		        RAISE INFO 'PRDCRLO - error 9 - recipiente duplicado %', p_reci_id;
				v_mensaje = 'RECI_DUPLICADO';
		        raise exception 'RECI_DUPLICADO:%',p_reci_id;
		       

			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 2 - recipiente no encontrado %', p_reci_id;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id;
		       
		end;	

   /*******************************************
    * BLOQUE 2 CREO O REUTILIZO LOTE
    * 
    */
	
   /**
	 * Una vez validado el recipiente, creo el nuevo lote
	 */		
		
    if (p_forzar_agregar='true') then
	    RAISE INFO 'PRDCRLO - 2 - ṕ_forzar_agregar = %, p_lote_id % y p_batch_id_padre %: ', p_forzar_agregar, p_lote_id, p_batch_id_padre;

        begin
	        select lo.batch_id
	        	   ,lo.lote_id
	        	   ,al.arti_id
	        into strict v_batch_id
	        	 ,v_lote_id
	        	 ,v_arti_id
	        from prd.lotes lo
	             ,alm.alm_lotes al
	        where reci_id  = p_reci_id
	        and lo.batch_id = al.batch_id
	        and lo.estado = 'En Curso';

	     /**
	      * Valido que si se quieren unir lotes, coincida el articulo y el nuemro de lote
	      */
	    if v_arti_id != p_arti_id or p_lote_id != v_lote_id then
		        RAISE INFO 'PRDCRLO - error 3 el articulo y lote destino %:% son != de los solicitados %,%',v_arti_id,v_lote_id,p_arti_id,p_lote_id;
				v_mensaje = 'ART_O_LOTE_DISTINTO';
				raise exception 'ART_O_LOTE_DISTINTO:%-%-%-%',v_arti_id,v_lote_id,p_arti_id,p_lote_id;
	    end if;
	       
	    exception
		   when TOO_MANY_ROWS then
		        RAISE INFO 'PRDCRLO - error 20 = %',sqlerrm;
				v_mensaje = 'RECI_DUPLICADO';
				raise exception 'RECI_DUPLICADO:%',p_reci_id;

	    	when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 4 = %',sqlerrm;
				v_mensaje = 'BATCH_NO_ENCONTRADO';
				raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
        end;
	       
    else
		begin
    		RAISE INFO 'PRDCRLO - p_forzar_agregar = %, p_lote_id % y p_batch_id_padre %: ', p_forzar_agregar, p_lote_id, p_batch_id_padre;
	
		    /** Inserto en la tabla de batch, creando el batch_id
		     * de la secuencia de lotes
		     */
    		if p_batch_id is not null and p_batch_id != 0 then
    		/* me informan un batch id existente, viene de un batch guardado pero no iniciado, no lo inserto*/
    			v_batch_id = p_batch_id;
    			
    			with updated_batch as (
	    			update prd.lotes 
	    			set lote_id = p_lote_id
	    				,estado = v_estado
	    				,num_orden_prod = p_num_orden_prod
	    				,reci_id = p_reci_id
	    			where batch_id = v_batch_id
	    			returning 1)
	    			
				select count(1)
				from updated_batch
				into strict v_cuenta;

				if v_cuenta = 0 then
			    	    RAISE INFO 'PRDCLO - no se encontro el batch id % cuenta % ', p_batch_id,v_cuenta;
			    	    raise 'BATCH_NO_ENCONTRADO';
			    end if;
    		
    		
    		else
				with inserted_batch as (
					insert into 
					prd.lotes (
					lote_id
					,estado
					,num_orden_prod
					,etap_id
					,usuario_app
					,reci_id
					,empr_id)	
					values (
					p_lote_id
					,v_estado
					,p_num_orden_prod
					,p_etap_id
					,p_usuario_app
					,p_reci_id
					,p_empr_id
					)
					returning batch_id
				)

				select batch_id
				into strict v_batch_id
				from inserted_batch;

			end if;
		
			/** si estay grabando planificado no debo lockear el recipiente */
			if v_estado != 'En Curso' then		
			    
			    /** Actualizo el recipiente como lleno
			     */
			    update prd.recipientes 
			    set estado = 'LLENO'
			    where reci_id = p_reci_id;

			end if;
		
	   exception
		   when others then
		        RAISE INFO 'PRDCRLO - error 5 - error creando lote y recipiente  %:% ',sqlstate,sqlerrm;
				v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
		  
    end if;
		
    /******************************************************************************
     * BLOQUE 3: ASOCIACION CON LOTES PADRE Y ACTUALIZACION ESTADOS Y  DE CANTIDADES
     * 
     */
   
    if v_estado != 'PLANIFICADO' then
	    /** Actualizo el arbol de batchs colocando el 
	     *  nuevo batch como hijo del p_batch_id_padre
	     * si el padre viene en 0 es un batch al inicio 
	     * del proceso productivo 
	     */
		insert into prd.lotes_hijos (
		batch_id
		,batch_id_padre
		,empr_id
		,cantidad
		,cantidad_padre)
		values
		(v_batch_id
		,case when p_batch_id_padre = 0 then null else p_batch_id_padre end
		,p_empr_id
		,p_cantidad
		,p_cantidad_padre);
		
		RAISE INFO 'PRDCRLO - Batch id % generado en recipiente %',v_batch_id,p_reci_id;
	
	    /**Cambiamos el estado del lote origen a FINALIZADO si ya no quedan existencias
		 * y vacio el recipiente
		 */
	
		
		if (p_batch_id_padre !=0 and p_cantidad_padre != 0) then
		
			--Obtengo la exisstencia actual del padre para entender si finalizar
			v_cantidad_padre = alm.obtener_existencia_batch(p_batch_id_padre);
			
			RAISE INFO 'PRDCRLO - cantidad padre existente:informada %.%',v_cantidad_padre,p_cantidad_padre;
	
			if v_cantidad_padre - p_cantidad_padre = 0 then
		
				RAISE INFO 'PRDCRLO - Finalizando lote % ',p_batch_id_padre;
	
				update prd.lotes
				set estado = 'FINALIZADO'
				where batch_id = p_batch_id_padre
				returning reci_id into v_reci_id_padre;
		
				update prd.recipientes
				set estado = 'VACIO'
				where reci_id = v_reci_id_padre;
			end if;
		
	
			/**
			 * Actualizo la existencia del padre
			 */
	
			RAISE INFO 'PRDCRLO - actualizo existencia %:% ',p_batch_id_padre,p_cantidad_padre;
	
			v_resultado = alm.extraer_lote_articulo(p_batch_id_padre
													,p_cantidad_padre);
		
		end if;
	    /**
	     * Genera el lote asociado en almacenes
	     *
	     */
	
    end if;	

	/*************************************************************************************
	 * BLOQUE 4: ACTUALIZACION DE LOTE EN ALMACENES EN CASO DE INFORMARCE ARTI_ID
	 * 
	 */
   
	if p_arti_id != 0 then --si se informa articulos del lote los inserto en alm_lotes, sino no
	    if (p_forzar_agregar='true') then
	
	    	RAISE INFO 'PRDCRLO - forzar agregar es true, agrego cantidad % al batch %',p_cantidad,v_batch_id;
	    	v_resultado = alm.agregar_lote_articulo(v_batch_id
													,p_cantidad);
		else
	    	RAISE INFO 'PRDCRLO - forzar agregar es false, ingreso cantidad % al batch %',p_cantidad,v_batch_id;
			
			v_cantidad = alm.obtener_existencia_batch(v_batch_id);
			
			/* Si existia lote, seguramente el lote fue grabado como PLANIFICADO
			 * Como debe haber un unico producto por lote
			 * elimino el lote almacen anterior asociado al actual batch_id
			 */
			if v_cantidad != 0 then
	    		v_resultado = alm.eliminar_lote_articulo(v_batch_id);
	    	end if;
	    
			v_resultado = alm.crear_lote_articulo(
									p_prov_id
									,p_arti_id 
									,v_depo_id
									,p_lote_id 
									,p_cantidad 
									,p_fec_vencimiento
									,p_empr_id 
									,v_batch_id );
		end if;						
	end if;

	RAISE INFO 'PRDCRLO - resultado ops almacen %',v_resultado;

	/*************************************************************************
	 * BLOQUE 5: ACTUALIZACION DE RECURSO DE TRABAJO EN CASO DE INFORMARSE
	 * 
	 */


	/** Si el actual lote tiene un recurso asociado lo asocio **/
    if p_recu_id is not null and p_recu_id != 0 then
    	
       begin
    		RAISE INFO 'PRDCRLO - p_recu_id = %', p_recu_id;

			/** Valido que el recursos  exista  **/
			select recu_id
			into strict v_recu_id
			from prd.recursos recu
			where recu.recu_id = p_recu_id;

			insert into prd.recursos_lotes(batch_id
											,recu_id
											,empr_id
											,cantidad
											,tipo)
					values (v_batch_id
							,p_recu_id
							,p_empr_id
							,p_cantidad
							,p_tipo_recurso);
						
		exception	   
		
			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 10 - recurso no encontrado %', p_recu_id;
				v_mensaje = 'RECU_NO_ENCONTRADO';
		        raise exception 'RECU_NO_ENCONTRADO:%',p_recu_id;
		       
		end;	

	end if;

	return v_batch_id;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'crear_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;

END; 
$$;


ALTER FUNCTION prd.crear_lote(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying, p_fec_vencimiento date, p_recu_id integer, p_tipo_recurso character varying, p_planificado character varying, p_batch_id bigint) OWNER TO postgres;

--
-- Name: crear_lote_noco(character varying, integer, integer, bigint, double precision, double precision, character varying, integer, integer, character varying, integer, character varying, date, integer, character varying, character varying, bigint, character varying); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_lote_noco(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying DEFAULT 'false'::character varying, p_fec_vencimiento date DEFAULT NULL::date, p_recu_id integer DEFAULT NULL::integer, p_tipo_recurso character varying DEFAULT NULL::character varying, p_planificado character varying DEFAULT 'false'::character varying, p_batch_id bigint DEFAULT NULL::bigint, p_noco_list character varying DEFAULT NULL::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** @version v1.1
 *  Funcion para generar un nuevo lote, y finalizar los lotes padres en la cadena productiva
 *  Recibe como parametro un id de lote
 *  y un recipiente donde crear el batch.
 *  Si el recipiente esta ocupado, devuelve el error con un mensaje para que el usuario tome una decisión 
 *  y vuelva a llamar a la funcion con p_forzar_agregar = treu
 *  Recibe una lista de noco_id, y asocia no consumibles al lote creado
 *  p_lote_id character varying Código de lote a generar
 *  p_arti_id integer  Articulo a asociar como PRODUCTO en el nuevo lote, si es 0 es un lote sin PRODUCTO
 *  p_prov_id integer  Proveedor del articulo a generar
 *  p_batch_id_padre bigint Batch Id del lote padre, si viene 0 es un lote al inicio de la cadena productiva y no tiene padre
 *  p_cantidad double precision Cantidad a generar en stock del nuevo 
 *  p_cantidad_padre double precision Cantidad a descontar del lote padre informado (si fue informado)
 *  p_num_orden_prod character varying Orden de producción asociada al lote
 *  p_reci_id integer Id de recipiente a asociar al nuevo lote
 *  p_etap_id integer Id de Etapa productiva (prd.etapas) al cual representa este lote
 *  p_usuario_app character varying usuario que genera el lote
 *  p_empr_id integer Id de empresa
 *  p_forzar_agregar character varying DEFAULT 'false'::character varying Bandera que fuerza a unificar lotes con 
                                                                       distinto articulo o id de lote en un mismo recipiente por 
                                                                       petición del usuario. Si viene en false, y el recipiente 
                                                                       esta LLENO, informará en una excepction TOOLSERROR si es 
                                                                       mismo arituclo  o lote 
 *  p_fec_vencimiento date DEFAULT NULL::date fecha de vencimiento del actual lote
 *  p_recu_id integer DEFAULT NULL::integer Recurso de trabajo asociado a la generación del lote, por ejemplo operario
 *  p_tipo_recurso character varying DEFAULT NULL::character varying  tipo del recurso informado
 *  p_planificado character varying DEFAULT 'false'::character varying Si es true, genera un lote en modo PLANIFICADO, no generando 
                                                                    información de stock y permitiendo utilziar recipientes LLENOS 
                                                                    para un futuro uso
 *  p_batch_id bigint DEFAULT NULL::bigint Informa si estamos trabajando sobre un batch existente ya, por ej: era un batch PLANIFICADO que vamos a Iniciar
 *  p_noco_list character varying DEFAULT NULL::character varying) Lista de no consumibles separada por ; que contendran al lote que estamos generando
 *  RETURNS character varying Batch id generado
 *  @author RRuiz
 */
#print_strict_params on
DECLARE
 v_estado_recipiente prd.recipientes.estado%type; 
 v_batch_id prd.lotes.batch_id%type;
 v_batch_id_aux prd.lotes.batch_id%type;
 v_mensaje varchar;
 v_reci_id_padre prd.recipientes.reci_id%type;
 v_depo_id prd.recipientes.depo_id%type;
 v_lote_id prd.lotes.lote_id%type;
 v_arti_id alm.alm_lotes.arti_id%type;
 v_cantidad_padre alm.alm_lotes.cantidad%type;
 v_recu_id prd.recursos_lotes.recu_id%type;
 v_resultado varchar;
 v_estado varchar;
 v_cantidad float;
 v_cuenta integer;
 v_artDif boolean = false;
 v_lotDif boolean = false;
 v_lotartIgual boolean = false;
 v_countLotesRec integer = 0;
 v_info_error varchar;
 v_step varchar = '0';
 v_noco_id_aux varchar;
 v_index integer = 1;
 verificarRecipiente CURSOR (p_batch_id INTEGER
			   ,p_arti_id INTEGER
			   ,p_lote_id VARCHAR) for
						   	select lo.batch_id
							,case when al.arti_id is null then 0 else al.arti_id end arti_id
							,case when lo.lote_id is null then '' else lo.lote_id end lote_id
							from prd.lotes lo
							left join alm.alm_lotes al on lo.batch_id = al.batch_id
							where reci_id  = p_reci_id
							and ((al.arti_id != p_arti_id or al.arti_id is null) or (lo.lote_id != p_lote_id or lo.lote_id is null))
							and lo.estado = 'En Curso';


BEGIN
		
		/* seteo el estado inicial dependiendo si se llama al procedure desde Guardar o desde Planificar estapa */
		if (p_planificado='true') then
			v_estado = 'PLANIFICADO';
		else
			v_estado = 'En Curso';
		end if;
		
		/**************************
		 * BLOQUE 1: VALIDO EL ESTADO DEL RECIPIENTE Y SI NO ESTA VACIO PIDO AL USUARIO TOMAR ACCION
		 */
	    v_step='1';
		begin
		        
			RAISE INFO 'PRDCRLO - BL1 valido reci - ṕ_forzar_agregar = %, p_lote_id % ', p_forzar_agregar, p_lote_id;

			/** Valido que el recipiente exista **/
			select reci.estado
				   ,reci.depo_id
			into strict v_estado_recipiente
				,v_depo_id
			from PRD.RECIPIENTES reci
			where reci.reci_id = p_reci_id;

				       
	    	/*
		 	* 1 - si forzar_agregar = false, verifica si el recipiente esta vacio, si no esta vacio 
		 	*  a) verifica si en el recipiente esta el mismo articulo, sino retorna RECI_NO_VACIO_DIST_ART
		 	*  b) si es mismo articulo y distinto lote retorna RECI_NO_VACIO_DIST_LOTE_IGUAL_ART
		 	*  c) si es mismo arituclo y lote retorna RECI_NO_VACIO_MISMO_IGUAL_ART_LOTE
                	*/	
	    	v_step='2';
    
			if v_estado_recipiente = 'LLENO' then
				open verificarRecipiente(p_reci_id,p_arti_id,p_lote_id);
				loop
					fetch verificarRecipiente into v_batch_id_aux ,v_arti_id,v_lote_id;
					exit when NOT FOUND;
      
       				if v_arti_id != p_arti_id then 
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_arti_id p arti id % % %',v_batch_id_aux,v_arti_id,p_arti_id;
						v_artDif = true;
					elsif v_lote_id != p_lote_id then
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_lote_id p lote id % >%< >%<',v_batch_id_aux,v_lote_id,p_lote_id;
						v_lotDif = true;					        		
					else 
						v_lotartIgual = true;
					end if;
				end loop;
				close verificarRecipiente;
				RAISE INFO 'PRDCRLO - revisando recipientes banderas % % %',v_artDif,v_lotDif,v_lotartIgual;
			    v_step='3';

			
				/* Corto la ejecución, hay que advertir al usuario que el recipiente no esta vacio y que decida que hacer **/
	    		if p_forzar_agregar='false' and p_planificado = 'false' then
	
	    			v_info_error = 'reci_id='||p_reci_id||'-arti_id='||p_arti_id||'-lote_id='||p_lote_id;
					if v_artDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_ART'; /* caso a */
						raise exception 'RECI_NO_VACIO_DIST_ART-%',v_info_error;
					elsif v_lotDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART'; /* caso b */
				    	raise exception 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART-%',v_info_error;
					else
			            v_mensaje = 'RECI_NO_VACIO_IGUAL_ART_LOTE'; /* caso c */
				    	raise exception 'RECI_NO_VACIO_IGUAL_ART_LOTE-%',v_info_error;
					end if;
				else	
					if v_lotartIgual then
						v_artDif = false;
						v_lotDif = false;
					end if;
				end if;	
	
			end if;
				  
		exception	   
			when too_many_rows then
		        RAISE INFO 'PRDCRLO - error 9 - recipiente duplicado %', p_reci_id;
				v_mensaje = 'RECI_DUPLICADO';
		        raise exception 'RECI_DUPLICADO:%',p_reci_id;

			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 2 - recipiente no encontrado %', p_reci_id;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id;
		       
		end;	
		v_step='4';

   /*******************************************
    * BLOQUE 2 CREO O REUTILIZO LOTE
    * 
    * Una vez validado el recipiente, creo el nuevo lote
    * si forzar agregar = true, entonces
    *  para el caso a) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso b) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso c) actualiza la existencia del lote con mismo arti y lote (unifica lote)
     **/

    RAISE INFO 'PRDCRLO - BL2  lote -  v_estado_recipiente % v_artDif % v_lotDif % ', v_estado_recipiente,v_artDif,v_lotDif;
		
    /* CAMINO 1: Si es un lote planificado o si unifica recipientes o unifica lote */
    if ( p_planificado = 'true' or ( v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif ) )then
   
	begin

			v_step='5';
             /* CASO 1: Si p_batch_id no viene vacio me informan un batch id existente, 
               es decir viene de un batch guardado pero no iniciado, no lo inserto sino actualizo el batch, puede ser que 
               este actualizando los datos del planificado o bien iniciando, depende de si p_planificado es true o false */


    		if p_batch_id is not null and p_batch_id != 0 then
    			RAISE INFO 'PRDCRLO - reu lote -  v_estado = %, p_lote_id % y v_batch_id %: ', v_estado, p_lote_id, p_batch_id;

    			v_batch_id = p_batch_id;
    			
    			with updated_batch as (
	    			update prd.lotes 
	    			set lote_id = p_lote_id
	    				,estado = v_estado
	    				,num_orden_prod = p_num_orden_prod
	    				,reci_id = p_reci_id
	    			where batch_id = v_batch_id
	    			returning 1)
	    			
				select count(1)
				from updated_batch
				into strict v_cuenta;
                
                /* Si no actualizó nada, el batch_id no existia */
				if v_cuenta = 0 then
			    	    RAISE INFO 'PRDCLO - no se encontro el batch id % cuenta % ', p_batch_id,v_cuenta;
			    	    raise 'BATCH_NO_ENCONTRADO';
			    end if;
    			
				    		
    		ELSE
             /* CASO 2 - no se informa p_batch_id existente, genero un nuevo lote **/
    		    v_step='6';

    		    RAISE INFO 'PRDCRLO - ins lote -  p_lote_id % ', p_lote_id;

				with inserted_batch as (
					insert into 
					prd.lotes (
					lote_id
					,estado
					,num_orden_prod
					,etap_id
					,usuario_app
					,reci_id
					,empr_id)	
					values (
					p_lote_id
					,v_estado
					,p_num_orden_prod
					,p_etap_id
					,p_usuario_app
					,p_reci_id
					,p_empr_id
					)
					returning batch_id
				)

				select batch_id
				into strict v_batch_id
				from inserted_batch;

				RAISE INFO 'PRDCRLO - ins lote -  v_batch_id % ', v_batch_id;

			end if;
		
			/** si estay grabando planificado no debo lockear el recipiente */
			if v_estado != 'PLANIFICADO' then		
			    
			    /** Actualizo el recipiente como lleno
			     */
			    update prd.recipientes 
			    set estado = 'LLENO'
			    where reci_id = p_reci_id;

			end if;
						
		    v_step='7';

	   exception
		   when others then
		        RAISE INFO 'PRDCRLO - error 5 - error creando lote y recipiente  %:% ',sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
    else /** CAMINO 2: Existe un recipiente lleno con mismo arti_id y lote_id que el lote que queremos crear, no lo creo sino unifico **/
	begin
			RAISE INFO 'PRDCRLO - nada con lote -  p_forzar_agregar = %', p_forzar_agregar;

	        select lo.batch_id
	        into strict v_batch_id
	        from prd.lotes lo
	             ,alm.alm_lotes al
	        where reci_id  = p_reci_id
            and lo.lote_id = p_lote_id 
	        and al.arti_id = p_arti_id
			and lo.batch_id = al.batch_id
	        and lo.estado = 'En Curso';

	       	/** Venia de un lote planificado, que al unificarse con uno existente lo damos por finalizado */
	        if p_batch_id is not null and p_batch_id != 0 then 
	        	update prd.lotes 
	        	set estado ='FINALIZADO'	
	        	where batch_id = p_batch_id;
	        end if;
			v_step='8';

    exception
		   when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 20 - error buscando lote para unificar reci,lote,arti:%:%:% error %:% ',p_reci_id,p_lote_id,p_arti_id,sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
				  
    end if;

   
    /********************************************************************************
     * BLOQUE 3: PADRES
     * ASOCIACION CON LOTES PADRE Y ACTUALIZACION ESTADOS Y DE CANTIDADES
     * 
     */
	RAISE INFO 'PRDCRLO - BL3 -  padres -  estado % batch id padre %',v_estado,p_batch_id_padre;

    if v_estado != 'PLANIFICADO' then
		v_step='9';

    	/** Actualizo el arbol de batchs colocando el 
	     *  nuevo batch como hijo del p_batch_id_padre
	     * si el padre viene en 0 es un batch al inicio 
	     * del proceso productivo 
	     */
		insert into prd.lotes_hijos (
		batch_id
		,batch_id_padre
		,empr_id
		,cantidad
		,cantidad_padre)
		values
		(v_batch_id
		,case when p_batch_id_padre = 0 then null else p_batch_id_padre end
		,p_empr_id
		,p_cantidad
		,p_cantidad_padre);
		
		RAISE INFO 'PRDCRLO - Batch id % generado en recipiente %',v_batch_id,p_reci_id;
	
	    /**Cambiamos el estado del lote padre  a FINALIZADO si ya no quedan existencias
		 * y vacio el recipiente
		 */
		if (p_batch_id_padre !=0 ) then

                --Obtengo la existencia actual del padre para entender si finalizar
                v_step='10';

                begin
                    v_cantidad_padre = alm.obtener_existencia_batch(p_batch_id_padre);
                exception 
                    when others then
                        RAISE INFO 'PRDCRLO - no hay lote asociado, asumimos que es un batch sin producto %:%:% ',p_batch_id_padre,sqlstate,sqlerrm;
                        v_cantidad_padre = 0;
                end;
            		
				v_step='10,5';
				RAISE INFO 'PRDCRLO - cantidad padre existente:informada %.%',v_cantidad_padre,p_cantidad_padre;
		
                /* Si no queda producto en el lote padre, o si el lote no tiene asociado un producto, 
                   lo finalizo e intento vaciar el recipiente (si no existen otros lotes En curso en el mismo)*/
				if v_cantidad_padre - p_cantidad_padre = 0 or v_cantidad_padre=0 then
			
					RAISE INFO 'PRDCRLO - Finalizando lote % ',p_batch_id_padre;
					v_step='11';
	
					update prd.lotes
					set estado = 'FINALIZADO'
					where batch_id = p_batch_id_padre
					returning reci_id into v_reci_id_padre;
					
					select count(1)
					into strict v_countLotesRec
					from prd.lotes
					where reci_id = v_reci_id_padre
					and estado = 'En Curso';
					
					/** Si no hay mas lotes activos en el recipiente lo pongo como VACIO **/
					if (v_countLotesRec = 0) then
						update prd.recipientes
						set estado = 'VACIO'
						where reci_id = v_reci_id_padre;
					end if;
				end if;
			
		
				/**
				 * Actualizo la existencia del padre si tiene producto asociado
				 */
                if v_cantidad_padre != 0 then
                    RAISE INFO 'PRDCRLO - actualizo existencia %:% ',p_batch_id_padre,p_cantidad_padre;
                    v_step='11,5';
                    v_resultado = alm.extraer_lote_articulo(p_batch_id_padre,p_cantidad_padre);
                end if;

			
		end if;

	
    end if;	

	/*************************************************************************************
	 * BLOQUE 4: ACTUALIZACION DE LOTE DEL PRODUCTO EN PRODUCCION
	 * EN ALMACENES EN CASO DE INFORMARSE ARTI_ID 
	 * 
	 */
	RAISE INFO 'PRDCRLO - BL4 -  lote producto - p_arti_id % v_estado %',p_arti_id,v_estado;
    /* si se informa articulos del lote los inserto en alm_lotes, sino no */
	if p_arti_id != 0 and v_estado != 'PLANIFICADO' then 
		v_step='12';

		/** Si el recipiente esta vacio o unifico recipiente, creo un lote, sino actualizo el existente**/
		if v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif then
	    		
				v_resultado = alm.crear_lote_articulo(
										p_prov_id
										,p_arti_id 
										,v_depo_id
										,p_lote_id 
										,p_cantidad 
										,p_fec_vencimiento
										,p_empr_id 
										,v_batch_id );
		else
			    RAISE INFO 'PRDCRLO - es un batch existente, agrego cantidad % al batch %',p_cantidad,v_batch_id;
	    		v_resultado = alm.agregar_lote_articulo(v_batch_id ,p_cantidad);

		end if;						
		RAISE INFO 'PRDCRLO - resultado ops almacen %',v_resultado;

	end if;

    /*************************************************************************
	 * BLOQUE 5: ACTUALIZACION DE RECURSO DE TRABAJO EN CASO DE INFORMARSE
	 * Viene informado en p_recu_id
	 */
    RAISE INFO 'PRDCRLO - BL5 RECURSO TRABAJO - recu_id %',p_recu_id;


	/** Si el actual lote tiene un recurso asociado lo asocio **/
    if p_recu_id is not null and p_recu_id != 0 then
       v_step='13';
	
       begin

	       RAISE INFO 'PRDCRLO - p_recu_id = %', p_recu_id;

			/** Valido que el recursos  exista  **/
			select recu_id
			into strict v_recu_id
			from prd.recursos recu
			where recu.recu_id = p_recu_id;

			/** Eliminio todo si fue grabado como planificado**/
			delete from prd.recursos_lotes
			where batch_id = v_batch_id
			and tipo=p_tipo_recurso;

			/* Inserto el recurso **/
			insert into prd.recursos_lotes(batch_id
											,recu_id
											,empr_id
											,cantidad
											,tipo)
					values (v_batch_id
							,p_recu_id
							,p_empr_id
							,p_cantidad
							,p_tipo_recurso);
						
		exception	   
		
			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 10 - recurso no encontrado %', p_recu_id;
				v_mensaje = 'RECU_NO_ENCONTRADO';
		        raise exception 'RECU_NO_ENCONTRADO:%',p_recu_id;
		       
		end;	

	end if;

	v_step='14';

	/*************************************************************************
	 * BLOQUE 6: asocio no consumibles, los cuales vienen separados por ; en p_noco_list
	 * 
	 */

    RAISE INFO 'PRDCRLO - BL6 no consumibles - noco_list %',p_noco_list;

   	-- tomo el primero
    select split_part(p_noco_list,';',1) 
    into strict v_noco_id_aux;

    WHILE v_noco_id_aux != '' LOOP

    	begin
			RAISE INFO 'PRDCRLO - BL6 no consumibles - inserto noco_id % con batch  %',v_noco_id_aux, v_batch_id;

	    	insert into nco.no_consumibles_lotes (noco_id,batch_id,usuario_app,empr_id)
			values (v_noco_id_aux,v_batch_id,p_usuario_app,p_empr_id);
		
		exception
			when others then
				RAISE INFO 'PRDCRLO - BL6 no consumibles - inserto ya existia el noco asociado al batch';
			/* si falla no hago nada */
		end;

		v_index = v_index+1;

		select split_part(p_noco_list,';',v_index) 
	    into strict v_noco_id_aux;
	   
    END LOOP; 
    call prd.audit_lote(v_batch_id,'batch generado: '||v_batch_id||
                            ' lote:'||p_lote_id||
                            ' batch padre:'|| p_batch_id_padre||
                            ' recipiente: '||p_reci_id||
                            ' articulo: '||p_arti_id||
                            ' recurso ' ||p_recu_id||
                            ' no con:'||p_noco_list||
                            ' forzar_agregar: '||p_forzar_agregar 
                            ,v_step);
    
	return v_batch_id;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'crear_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%:%<<',v_mensaje,v_step;
	    end if;

END; 
$$;


ALTER FUNCTION prd.crear_lote_noco(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying, p_fec_vencimiento date, p_recu_id integer, p_tipo_recurso character varying, p_planificado character varying, p_batch_id bigint, p_noco_list character varying) OWNER TO postgres;

--
-- Name: crear_lote_v2(character varying, integer, integer, bigint, double precision, double precision, character varying, integer, integer, character varying, integer, character varying, date, integer, character varying, character varying, bigint); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_lote_v2(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying DEFAULT 'false'::character varying, p_fec_vencimiento date DEFAULT NULL::date, p_recu_id integer DEFAULT NULL::integer, p_tipo_recurso character varying DEFAULT NULL::character varying, p_planificado character varying DEFAULT 'false'::character varying, p_batch_id bigint DEFAULT NULL::bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** @version v1.1
 *  Funcion para generar un nuevo lote, y finalizar los lotes padres en la cadena productiva
 *  Recibe como parametro un id de lote
 *  y un recipiente donde crear el batch.
 *  Si el recipiente esta ocupado, devuelve el error con un mensaje para que el usuario tome una decisión 
 *  y vuelva a llamar a la funcion con p_forzar_agregar = treu
 *  p_lote_id character varying Código de lote a generar
 *  p_arti_id integer  Articulo a asociar como PRODUCTO en el nuevo lote, si es 0 es un lote sin PRODUCTO
 *  p_prov_id integer  Proveedor del articulo a generar
 *  p_batch_id_padre bigint Batch Id del lote padre, si viene 0 es un lote al inicio de la cadena productiva y no tiene padre
 *  p_cantidad double precision Cantidad a generar en stock del nuevo 
 *  p_cantidad_padre double precision Cantidad a descontar del lote padre informado (si fue informado)
 *  p_num_orden_prod character varying Orden de producción asociada al lote
 *  p_reci_id integer Id de recipiente a asociar al nuevo lote
 *  p_etap_id integer Id de Etapa productiva (prd.etapas) al cual representa este lote
 *  p_usuario_app character varying usuario que genera el lote
 *  p_empr_id integer Id de empresa
 *  p_forzar_agregar character varying DEFAULT 'false'::character varying Bandera que fuerza a unificar lotes con 
                                                                       distinto articulo o id de lote en un mismo recipiente por 
                                                                       petición del usuario. Si viene en false, y el recipiente 
                                                                       esta LLENO, informará en una excepction TOOLSERROR si es 
                                                                       mismo arituclo  o lote 
 *  p_fec_vencimiento date DEFAULT NULL::date fecha de vencimiento del actual lote
 *  p_recu_id integer DEFAULT NULL::integer Recurso de trabajo asociado a la generación del lote, por ejemplo operario
 *  p_tipo_recurso character varying DEFAULT NULL::character varying  tipo del recurso informado
 *  p_planificado character varying DEFAULT 'false'::character varying Si es true, genera un lote en modo PLANIFICADO, no generando 
                                                                    información de stock y permitiendo utilziar recipientes LLENOS 
                                                                    para un futuro uso
 *  p_batch_id bigint DEFAULT NULL::bigint Informa si estamos trabajando sobre un batch existente ya, por ej: era un batch PLANIFICADO que vamos a Iniciar
 *  RETURNS character varying Batch id generado
 *  @author RRuiz
 */
#print_strict_params on
DECLARE
 v_estado_recipiente prd.recipientes.estado%type; 
 v_batch_id prd.lotes.batch_id%type;
 v_batch_id_aux prd.lotes.batch_id%type;
 v_mensaje varchar;
 v_reci_id_padre prd.recipientes.reci_id%type;
 v_depo_id prd.recipientes.depo_id%type;
 v_lote_id prd.lotes.lote_id%type;
 v_arti_id alm.alm_lotes.arti_id%type;
 v_cantidad_padre alm.alm_lotes.cantidad%type;
 v_recu_id prd.recursos_lotes.recu_id%type;
 v_resultado varchar;
 v_estado varchar;
 v_cantidad float;
 v_cuenta integer;
 v_artDif boolean = false;
 v_lotDif boolean = false;
 v_lotartIgual boolean = false;
 v_countLotesRec integer = 0;
 v_info_error varchar;
 v_step varchar = '0';
 v_index integer = 1;
 verificarRecipiente CURSOR (p_batch_id INTEGER
			   ,p_arti_id INTEGER
			   ,p_lote_id VARCHAR)for 
			   				select lo.batch_id
							,case when al.arti_id is null then 0 else al.arti_id end arti_id
							,case when lo.lote_id is null then '' else lo.lote_id end lote_id
							from prd.lotes lo
							left join alm.alm_lotes al on lo.batch_id = al.batch_id
							where reci_id  = p_reci_id
							and ((al.arti_id != p_arti_id or al.arti_id is null) or (lo.lote_id != p_lote_id or lo.lote_id is null))
							and lo.estado = 'En Curso';


BEGIN
		
		/* seteo el estado inicial dependiendo si se llama al procedure desde Guardar o desde Planificar estapa */
		if (p_planificado='true') then
			v_estado = 'PLANIFICADO';
		else
			v_estado = 'En Curso';
		end if;
		
		/**************************
		 * BLOQUE 1: VALIDO EL ESTADO DEL RECIPIENTE Y SI NO ESTA VACIO PIDO AL USUARIO TOMAR ACCION
		 */
	    v_step='1';
		begin
		        
			RAISE INFO 'PRDCRLO - BL1 valido reci - ṕ_forzar_agregar = %, p_lote_id % ', p_forzar_agregar, p_lote_id;

			/** Valido que el recipiente exista **/
			select reci.estado
				   ,reci.depo_id
			into strict v_estado_recipiente
				,v_depo_id
			from PRD.RECIPIENTES reci
			where reci.reci_id = p_reci_id;

				       
	    	/*
		 	* 1 - si forzar_agregar = false, verifica si el recipiente esta vacio, si no esta vacio 
		 	*  a) verifica si en el recipiente esta el mismo articulo, sino retorna RECI_NO_VACIO_DIST_ART
		 	*  b) si es mismo articulo y distinto lote retorna RECI_NO_VACIO_DIST_LOTE_IGUAL_ART
		 	*  c) si es mismo arituclo y lote retorna RECI_NO_VACIO_MISMO_IGUAL_ART_LOTE
                	*/	
	    	v_step='2';
    
			if v_estado_recipiente = 'LLENO' then
				open verificarRecipiente(p_reci_id,p_arti_id,p_lote_id);
				loop
					fetch verificarRecipiente into v_batch_id_aux ,v_arti_id,v_lote_id;
					exit when NOT FOUND;
      
       				if v_arti_id != p_arti_id then 
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_arti_id p arti id % % %',v_batch_id_aux,v_arti_id,p_arti_id;
						v_artDif = true;
					elsif v_lote_id != p_lote_id then
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_lote_id p lote id % >%< >%<',v_batch_id_aux,v_lote_id,p_lote_id;
						v_lotDif = true;					        		
					else 
						v_lotartIgual = true;
					end if;
				end loop;
				close verificarRecipiente;
				RAISE INFO 'PRDCRLO - revisando recipientes banderas % % %',v_artDif,v_lotDif,v_lotartIgual;
			    v_step='3';

			
				/* Corto la ejecución, hay que advertir al usuario que el recipiente no esta vacio y que decida que hacer **/
	    		if p_forzar_agregar='false' and p_planificado = 'false' then
	
	    			v_info_error = 'reci_id='||p_reci_id||'-arti_id='||p_arti_id||'-lote_id='||p_lote_id;
					if v_artDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_ART'; /* caso a */
						raise exception 'RECI_NO_VACIO_DIST_ART-%',v_info_error;
					elsif v_lotDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART'; /* caso b */
				    	raise exception 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART-%',v_info_error;
					else
			            v_mensaje = 'RECI_NO_VACIO_IGUAL_ART_LOTE'; /* caso c */
				    	raise exception 'RECI_NO_VACIO_IGUAL_ART_LOTE-%',v_info_error;
					end if;
				else	
					if v_lotartIgual then
						v_artDif = false;
						v_lotDif = false;
					end if;
				end if;	
	
			end if;
				  
		exception	   
			when too_many_rows then
		        RAISE INFO 'PRDCRLO - error 9 - recipiente duplicado %', p_reci_id;
				v_mensaje = 'RECI_DUPLICADO';
		        raise exception 'RECI_DUPLICADO:%',p_reci_id;

			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 2 - recipiente no encontrado %', p_reci_id;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id;
		       
		end;	
		v_step='4';

   /*******************************************
    * BLOQUE 2 CREO O REUTILIZO LOTE
    * 
    * Una vez validado el recipiente, creo el nuevo lote
    * si forzar agregar = true, entonces
    *  para el caso a) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso b) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso c) actualiza la existencia del lote con mismo arti y lote (unifica lote)
     **/

    RAISE INFO 'PRDCRLO - BL2  lote -  v_estado_recipiente % v_artDif % v_lotDif % ', v_estado_recipiente,v_artDif,v_lotDif;
		
    /* CAMINO 1: Si es un lote planificado o si unifica recipientes o unifica lote */
    if ( p_planificado = 'true' or ( v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif ) )then
   
	begin

			v_step='5';
             /* CASO 1: Si p_batch_id no viene vacio me informan un batch id existente, 
               es decir viene de un batch guardado pero no iniciado, no lo inserto sino actualizo el batch, puede ser que 
               este actualizando los datos del planificado o bien iniciando, depende de si p_planificado es true o false */


    		if p_batch_id is not null and p_batch_id != 0 then
    			RAISE INFO 'PRDCRLO - reu lote -  v_estado = %, p_lote_id % y v_batch_id %: ', v_estado, p_lote_id, p_batch_id;

    			v_batch_id = p_batch_id;
    			
    			with updated_batch as (
	    			update prd.lotes 
	    			set lote_id = p_lote_id
	    				,estado = v_estado
	    				,num_orden_prod = p_num_orden_prod
	    				,reci_id = p_reci_id
	    			where batch_id = v_batch_id
	    			returning 1)
	    			
				select count(1)
				from updated_batch
				into strict v_cuenta;
                
                /* Si no actualizó nada, el batch_id no existia */
				if v_cuenta = 0 then
			    	    RAISE INFO 'PRDCLO - no se encontro el batch id % cuenta % ', p_batch_id,v_cuenta;
			    	    raise 'BATCH_NO_ENCONTRADO';
			    end if;
    			
				    		
    		ELSE
             /* CASO 2 - no se informa p_batch_id existente, genero un nuevo lote **/
    		    v_step='6';

    		    RAISE INFO 'PRDCRLO - ins lote -  p_lote_id % ', p_lote_id;

				with inserted_batch as (
					insert into 
					prd.lotes (
					lote_id
					,estado
					,num_orden_prod
					,etap_id
					,usuario_app
					,reci_id
					,empr_id)	
					values (
					p_lote_id
					,v_estado
					,p_num_orden_prod
					,p_etap_id
					,p_usuario_app
					,p_reci_id
					,p_empr_id
					)
					returning batch_id
				)

				select batch_id
				into strict v_batch_id
				from inserted_batch;

				RAISE INFO 'PRDCRLO - ins lote -  v_batch_id % ', v_batch_id;

			end if;
		
			/** si estay grabando planificado no debo lockear el recipiente */
			if v_estado != 'PLANIFICADO' then		
			    
			    /** Actualizo el recipiente como lleno
			     */
			    update prd.recipientes 
			    set estado = 'LLENO'
			    where reci_id = p_reci_id;

			end if;
						
		    v_step='7';

	   exception
		   when others then
		        RAISE INFO 'PRDCRLO - error 5 - error creando lote y recipiente  %:% ',sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
    else /** CAMINO 2: Existe un recipiente lleno con mismo arti_id y lote_id que el lote que queremos crear, no lo creo sino unifico **/
	begin
			RAISE INFO 'PRDCRLO - nada con lote -  p_forzar_agregar = %', p_forzar_agregar;

	        select lo.batch_id
	        into strict v_batch_id
	        from prd.lotes lo
	             ,alm.alm_lotes al
	        where reci_id  = p_reci_id
            and lo.lote_id = p_lote_id 
	        and al.arti_id = p_arti_id
			and lo.batch_id = al.batch_id
	        and lo.estado = 'En Curso';

	       	/** Venia de un lote planificado, que al unificarse con uno existente lo damos por finalizado */
	        if p_batch_id is not null and p_batch_id != 0 then 
	        	update prd.lotes 
	        	set estado ='FINALIZADO'	
	        	where batch_id = p_batch_id;
	        end if;
			v_step='8';

    exception
		   when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 20 - error buscando lote para unificar reci,lote,arti:%:%:% error %:% ',p_reci_id,p_lote_id,p_arti_id,sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
				  
    end if;

   
    /********************************************************************************
     * BLOQUE 3: PADRES
     * ASOCIACION CON LOTES PADRE Y ACTUALIZACION ESTADOS Y DE CANTIDADES
     * 
     */
	RAISE INFO 'PRDCRLO - BL3 -  padres -  estado % batch id padre %',v_estado,p_batch_id_padre;

    if v_estado != 'PLANIFICADO' then
		v_step='9';

    	/** Actualizo el arbol de batchs colocando el 
	     *  nuevo batch como hijo del p_batch_id_padre
	     * si el padre viene en 0 es un batch al inicio 
	     * del proceso productivo 
	     */
		insert into prd.lotes_hijos (
		batch_id
		,batch_id_padre
		,empr_id
		,cantidad
		,cantidad_padre)
		values
		(v_batch_id
		,case when p_batch_id_padre = 0 then null else p_batch_id_padre end
		,p_empr_id
		,p_cantidad
		,p_cantidad_padre);
		
		RAISE INFO 'PRDCRLO - Batch id % generado en recipiente %',v_batch_id,p_reci_id;
	
	    /**Cambiamos el estado del lote padre  a FINALIZADO si ya no quedan existencias
		 * y vacio el recipiente
		 */
		if (p_batch_id_padre !=0 ) then

                --Obtengo la existencia actual del padre para entender si finalizar
                v_step='10';

                begin
                    v_cantidad_padre = alm.obtener_existencia_batch(p_batch_id_padre);
                exception 
                    when others then
                        RAISE INFO 'PRDCRLO - no hay lote asociado, asumimos que es un batch sin producto %:%:% ',p_batch_id_padre,sqlstate,sqlerrm;
                        v_cantidad_padre = 0;
                end;
            		
				v_step='10,5';
				RAISE INFO 'PRDCRLO - cantidad padre existente:informada %.%',v_cantidad_padre,p_cantidad_padre;
		
                /* Si no queda producto en el lote padre, o si el lote no tiene asociado un producto, 
                   lo finalizo e intento vaciar el recipiente (si no existen otros lotes En curso en el mismo)*/
				if v_cantidad_padre - p_cantidad_padre = 0 or v_cantidad_padre=0 then
			
					RAISE INFO 'PRDCRLO - Finalizando lote % ',p_batch_id_padre;
					v_step='11';
	
					update prd.lotes
					set estado = 'FINALIZADO'
					where batch_id = p_batch_id_padre
					returning reci_id into v_reci_id_padre;
					
					select count(1)
					into strict v_countLotesRec
					from prd.lotes
					where reci_id = v_reci_id_padre
					and estado = 'En Curso';
					
					/** Si no hay mas lotes activos en el recipiente lo pongo como VACIO **/
					if (v_countLotesRec = 0) then
						update prd.recipientes
						set estado = 'VACIO'
						where reci_id = v_reci_id_padre;
					end if;
				end if;
			
		
				/**
				 * Actualizo la existencia del padre si tiene producto asociado
				 */
                if v_cantidad_padre != 0 then
                    RAISE INFO 'PRDCRLO - actualizo existencia %:% ',p_batch_id_padre,p_cantidad_padre;
                    v_step='11,5';
                    v_resultado = alm.extraer_lote_articulo(p_batch_id_padre,p_cantidad_padre);
                end if;

			
		end if;

	
    end if;	

	/*************************************************************************************
	 * BLOQUE 4: ACTUALIZACION DE LOTE DEL PRODUCTO EN PRODUCCION
	 * EN ALMACENES EN CASO DE INFORMARSE ARTI_ID 
	 * 
	 */
	RAISE INFO 'PRDCRLO - BL4 -  lote producto - p_arti_id % v_estado %',p_arti_id,v_estado;
    /* si se informa articulos del lote los inserto en alm_lotes, sino no */
	if p_arti_id != 0 and v_estado != 'PLANIFICADO' then 
		v_step='12';

		/** Si el recipiente esta vacio o unifico recipiente, creo un lote, sino actualizo el existente**/
		if v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif then
	    		
				v_resultado = alm.crear_lote_articulo(
										p_prov_id
										,p_arti_id 
										,v_depo_id
										,p_lote_id 
										,p_cantidad 
										,p_fec_vencimiento
										,p_empr_id 
										,v_batch_id );
		else
			    RAISE INFO 'PRDCRLO - es un batch existente, agrego cantidad % al batch %',p_cantidad,v_batch_id;
	    		v_resultado = alm.agregar_lote_articulo(v_batch_id ,p_cantidad);

		end if;						
		RAISE INFO 'PRDCRLO - resultado ops almacen %',v_resultado;

	end if;

    /*************************************************************************
	 * BLOQUE 5: ACTUALIZACION DE RECURSO DE TRABAJO EN CASO DE INFORMARSE
	 * Viene informado en p_recu_id
	 */
    RAISE INFO 'PRDCRLO - BL5 RECURSO TRABAJO - recu_id %',p_recu_id;


	/** Si el actual lote tiene un recurso asociado lo asocio **/
    if p_recu_id is not null and p_recu_id != 0 then
       v_step='13';
	
       begin

	       RAISE INFO 'PRDCRLO - p_recu_id = %', p_recu_id;

			/** Valido que el recursos  exista  **/
			select recu_id
			into strict v_recu_id
			from prd.recursos recu
			where recu.recu_id = p_recu_id;

			/** Eliminio todo si fue grabado como planificado**/
			delete from prd.recursos_lotes
			where batch_id = v_batch_id
			and tipo=p_tipo_recurso;

			/* Inserto el recurso **/
			insert into prd.recursos_lotes(batch_id
											,recu_id
											,empr_id
											,cantidad
											,tipo)
					values (v_batch_id
							,p_recu_id
							,p_empr_id
							,p_cantidad
							,p_tipo_recurso);
						
		exception	   
		
			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 10 - recurso no encontrado %', p_recu_id;
				v_mensaje = 'RECU_NO_ENCONTRADO';
		        raise exception 'RECU_NO_ENCONTRADO:%',p_recu_id;
		       
		end;	

	end if;

	v_step='14';

    call prd.audit_lote(v_batch_id,'batch generado: '||v_batch_id||
                            ' lote:'||p_lote_id||
                            ' batch padre:'|| p_batch_id_padre||
                            ' recipiente: '||p_reci_id||
                            ' articulo: '||p_arti_id||
                            ' recurso ' ||p_recu_id||
                            ' forzar_agregar: '||p_forzar_agregar 
                            ,v_step);
    
	return v_batch_id;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'crear_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%:%<<',v_mensaje,v_step;
	    end if;

END; 
$$;


ALTER FUNCTION prd.crear_lote_v2(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying, p_fec_vencimiento date, p_recu_id integer, p_tipo_recurso character varying, p_planificado character varying, p_batch_id bigint) OWNER TO postgres;

--
-- Name: crear_lote_v2(character varying, integer, integer, bigint, double precision, double precision, character varying, integer, integer, character varying, integer, character varying, date, integer, character varying, character varying, bigint, timestamp without time zone); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_lote_v2(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying DEFAULT 'false'::character varying, p_fec_vencimiento date DEFAULT NULL::date, p_recu_id integer DEFAULT NULL::integer, p_tipo_recurso character varying DEFAULT NULL::character varying, p_planificado character varying DEFAULT 'false'::character varying, p_batch_id bigint DEFAULT NULL::bigint, p_fec_alta timestamp without time zone DEFAULT NULL::timestamp without time zone) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** @version v1.3
 *  Funcion para generar un nuevo lote, y finalizar los lotes padres en la cadena productiva
 *  Recibe como parametro un id de lote
 *  y un recipiente donde crear el batch.
 *  Si el recipiente esta ocupado, devuelve el error con un mensaje para que el usuario tome una decisión 
 *  y vuelva a llamar a la funcion con p_forzar_agregar = treu
 *  p_lote_id character varying Código de lote a generar
 *  p_arti_id integer  Articulo a asociar como PRODUCTO en el nuevo lote, si es 0 es un lote sin PRODUCTO
 *  p_prov_id integer  Proveedor del articulo a generar
 *  p_batch_id_padre bigint Batch Id del lote padre, si viene 0 es un lote al inicio de la cadena productiva y no tiene padre
 *  p_cantidad double precision Cantidad a generar en stock del nuevo 
 *  p_cantidad_padre double precision Cantidad a descontar del lote padre informado (si fue informado)
 *  p_num_orden_prod character varying Orden de producción asociada al lote
 *  p_reci_id integer Id de recipiente a asociar al nuevo lote
 *  p_etap_id integer Id de Etapa productiva (prd.etapas) al cual representa este lote
 *  p_usuario_app character varying usuario que genera el lote
 *  p_empr_id integer Id de empresa
 *  p_forzar_agregar character varying DEFAULT c_false::character varying Bandera que fuerza a unificar lotes con 
                                                                       distinto articulo o id de lote en un mismo recipiente por 
                                                                       petición del usuario. Si viene en false, y el recipiente 
                                                                       esta LLENO, informará en una excepction TOOLSERROR si es 
                                                                       mismo arituclo  o lote 
 *  p_fec_vencimiento date DEFAULT NULL::date fecha de vencimiento del actual lote
 *  p_recu_id integer DEFAULT NULL::integer Recurso de trabajo asociado a la generación del lote, por ejemplo operario
 *  p_tipo_recurso character varying DEFAULT NULL::character varying  tipo del recurso informado
 *  p_planificado character varying DEFAULT c_false::character varying Si es true, genera un lote en modo PLANIFICADO, no generando 
                                                                    información de stock y permitiendo utilziar recipientes LLENOS 
                                                                    para un futuro uso
 *  p_batch_id bigint DEFAULT NULL::bigint Informa si estamos trabajando sobre un batch existente ya, por ej: era un batch PLANIFICADO que vamos a Iniciar
 *  p_fec_alta timestamp DEFAULT NULL:timestamp Fecha informada de inicio de producción del lote, si viene null se usa la fecha actual
 *  *  RETURNS character varying Batch id generado
 *  @author RRuiz
 */
#print_strict_params on
DECLARE
 v_estado_recipiente prd.recipientes.estado%type; 
 v_batch_id prd.lotes.batch_id%type;
 v_batch_id_aux prd.lotes.batch_id%type;
 v_mensaje varchar;
 v_reci_id_padre prd.recipientes.reci_id%type;
 v_depo_id prd.recipientes.depo_id%type;
 v_lote_id prd.lotes.lote_id%type;
 v_arti_id alm.alm_lotes.arti_id%type;
 v_cantidad_padre alm.alm_lotes.cantidad%type;
 v_recu_id prd.recursos_lotes.recu_id%type;
 v_resultado varchar;
 v_estado varchar;
 v_cantidad float;
 v_cuenta integer;
 v_artDif boolean = false;
 v_lotDif boolean = false;
 v_lotartIgual boolean = false;
 v_countLotesRec integer = 0;
 v_info_error varchar;
 v_step varchar = '0';
 v_index integer = 1;
 c_en_curso constant varchar := 'En Curso';
 c_planificado constant varchar  := 'PLANIFICADO';
 c_finalizado constant varchar := 'FINALIZADO';
 c_vacio constant varchar := 'VACIO';
 c_lleno constant varchar := 'LLENO';
 c_true constant varchar := 'true';
 c_false constant varchar := 'false';

 verificarRecipiente CURSOR (p_batch_id INTEGER
			   ,p_arti_id INTEGER
			   ,p_lote_id VARCHAR)for 
			   				select lo.batch_id
							,case when al.arti_id is null then 0 else al.arti_id end arti_id
							,case when lo.lote_id is null then '' else lo.lote_id end lote_id
							from prd.lotes lo
							left join alm.alm_lotes al on lo.batch_id = al.batch_id
							where reci_id  = p_reci_id
							and ((al.arti_id != p_arti_id or al.arti_id is null) or (lo.lote_id != p_lote_id or lo.lote_id is null))
							and lo.estado = c_en_curso ;


BEGIN
		
		/* seteo el estado inicial dependiendo si se llama al procedure desde Guardar o desde Planificar estapa */
		if (p_planificado=c_true) then
			v_estado = c_planificado;
		else
			v_estado = c_en_curso;
		end if;
		
		/**************************
		 * BLOQUE 1: VALIDO EL ESTADO DEL RECIPIENTE Y SI NO ESTA VACIO PIDO AL USUARIO TOMAR ACCION
		 */
	    v_step='1';
		begin
		        
			RAISE INFO 'PRDCRLO - BL1 valido reci - ṕ_forzar_agregar = %, p_lote_id % ', p_forzar_agregar, p_lote_id;

			/** Valido que el recipiente exista **/
			select reci.estado
				   ,reci.depo_id
			into strict v_estado_recipiente
				,v_depo_id
			from PRD.RECIPIENTES reci
			where reci.reci_id = p_reci_id;

				       
	    	/*
		 	* 1 - si forzar_agregar = false, verifica si el recipiente esta vacio, si no esta vacio 
		 	*  a) verifica si en el recipiente esta el mismo articulo, sino retorna RECI_NO_VACIO_DIST_ART
		 	*  b) si es mismo articulo y distinto lote retorna RECI_NO_VACIO_DIST_LOTE_IGUAL_ART
		 	*  c) si es mismo arituclo y lote retorna RECI_NO_VACIO_MISMO_IGUAL_ART_LOTE
                	*/	
	    	v_step='2';
    
			if v_estado_recipiente = c_lleno then
				open verificarRecipiente(p_reci_id,p_arti_id,p_lote_id);
				loop
					fetch verificarRecipiente into v_batch_id_aux ,v_arti_id,v_lote_id;
					exit when NOT FOUND;
      
       				if v_arti_id != p_arti_id then 
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_arti_id p arti id % % %',v_batch_id_aux,v_arti_id,p_arti_id;
						v_artDif = true;
					elsif v_lote_id != p_lote_id then
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_lote_id p lote id % >%< >%<',v_batch_id_aux,v_lote_id,p_lote_id;
						v_lotDif = true;					        		
					else 
						v_lotartIgual = true;
					end if;
				end loop;
				close verificarRecipiente;
				RAISE INFO 'PRDCRLO - revisando recipientes banderas % % %',v_artDif,v_lotDif,v_lotartIgual;
			    v_step='3';

			
				/* Corto la ejecución, hay que advertir al usuario que el recipiente no esta vacio y que decida que hacer **/
	    		if p_forzar_agregar=c_false and p_planificado = c_false then
	
	    			v_info_error = 'reci_id='||p_reci_id||'-arti_id='||p_arti_id||'-lote_id='||p_lote_id;
					if v_artDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_ART'; /* caso a */
						raise exception 'RECI_NO_VACIO_DIST_ART-%',v_info_error;
					elsif v_lotDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART'; /* caso b */
				    	raise exception 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART-%',v_info_error;
					else
			            v_mensaje = 'RECI_NO_VACIO_IGUAL_ART_LOTE'; /* caso c */
				    	raise exception 'RECI_NO_VACIO_IGUAL_ART_LOTE-%',v_info_error;
					end if;
				else	
					if v_lotartIgual then
						v_artDif = false;
						v_lotDif = false;
					end if;
				end if;	
	
			end if;
				  
		exception	   
			when too_many_rows then
		        RAISE INFO 'PRDCRLO - error 9 - recipiente duplicado %', p_reci_id;
				v_mensaje = 'RECI_DUPLICADO';
		        raise exception 'RECI_DUPLICADO:%',p_reci_id;

			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 2 - recipiente no encontrado %', p_reci_id;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id;
		       
		end;	
		v_step='4';

   /*******************************************
    * BLOQUE 2 CREO O REUTILIZO LOTE
    * 
    * Una vez validado el recipiente, creo el nuevo lote
    * si forzar agregar = true, entonces
    *  para el caso a) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso b) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso c) actualiza la existencia del lote con mismo arti y lote (unifica lote)
     **/

    RAISE INFO 'PRDCRLO - BL2  lote -  v_estado_recipiente % v_artDif % v_lotDif % ', v_estado_recipiente,v_artDif,v_lotDif;
		
    /* CAMINO 1: Si es un lote planificado o si unifica recipientes o unifica lote */
    if ( p_planificado = c_true or ( v_estado_recipiente = c_vacio or  v_artDif or  v_lotDif ) )then
   
	begin

			v_step='5';
             /* CASO 1: Si p_batch_id no viene vacio me informan un batch id existente, 
               es decir viene de un batch guardado pero no iniciado, no lo inserto sino actualizo el batch, puede ser que 
               este actualizando los datos del planificado o bien iniciando, depende de si p_planificado es true o false */


    		if p_batch_id is not null and p_batch_id != 0 then
    			RAISE INFO 'PRDCRLO - reu lote -  v_estado = %, p_lote_id % y v_batch_id %: ', v_estado, p_lote_id, p_batch_id;

    			v_batch_id = p_batch_id;
    			
    			with updated_batch as (
	    			update prd.lotes 
	    			set lote_id = p_lote_id
	    				,estado = v_estado
	    				,num_orden_prod = p_num_orden_prod
	    				,reci_id = p_reci_id
	    				,usuario_app_ult_modificacion  = p_usuario_app 
	    				,fec_planificado = case when v_estado = c_planificado then now() else fec_planificado end 
	    				,fec_iniciado  = case when v_estado = c_en_curso then 
	    									case when p_fec_alta is null then now() else p_fec_alta end
	    								 else null::timestamp end
	    			where batch_id = v_batch_id
	    			returning 1)
	    			
				select count(1)
				from updated_batch
				into strict v_cuenta;
                
                /* Si no actualizó nada, el batch_id no existia */
				if v_cuenta = 0 then
			    	    RAISE INFO 'PRDCLO - no se encontro el batch id % cuenta % ', p_batch_id,v_cuenta;
			    	    raise 'BATCH_NO_ENCONTRADO';
			    end if;
    			
				    		
    		ELSE
             /* CASO 2 - no se informa p_batch_id existente, genero un nuevo lote **/
    		    v_step='6';

    		    RAISE INFO 'PRDCRLO - ins lote -  p_lote_id % ', p_lote_id;

				with inserted_batch as (
					insert into 
					prd.lotes (
					lote_id
					,estado
					,num_orden_prod
					,etap_id
					,usuario_app
					,reci_id
					,empr_id
					,fec_planificado
					,fec_iniciado)	
					values (
					p_lote_id
					,v_estado
					,p_num_orden_prod
					,p_etap_id
					,p_usuario_app
					,p_reci_id
					,p_empr_id
					,case when v_estado = c_planificado then now() else null::TIMESTAMP  end 
					,case when v_estado = c_en_curso  then 
						case when p_fec_alta is null then now() else p_fec_alta end 
					 else null::TIMESTAMP END
					)
					returning batch_id
				)

				select batch_id
				into strict v_batch_id
				from inserted_batch;

				RAISE INFO 'PRDCRLO - ins lote -  v_batch_id % ', v_batch_id;

			end if;
		
			/** si estay grabando planificado no debo lockear el recipiente */
			if v_estado != c_planificado then		
			    
			    /** Actualizo el recipiente como lleno
			     */
			    update prd.recipientes 
			    set estado = c_lleno
			    where reci_id = p_reci_id;

			end if;
						
		    v_step='7';

	   exception
		   when others then
		        RAISE INFO 'PRDCRLO - error 5 - error creando lote y recipiente  %:% ',sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
    else /** CAMINO 2: Existe un recipiente lleno con mismo arti_id y lote_id que el lote que queremos crear, no lo creo sino unifico **/
	begin
			RAISE INFO 'PRDCRLO - nada con lote -  p_forzar_agregar = %', p_forzar_agregar;

	        select lo.batch_id
	        into strict v_batch_id
	        from prd.lotes lo
	             ,alm.alm_lotes al
	        where reci_id  = p_reci_id
            and lo.lote_id = p_lote_id 
	        and al.arti_id = p_arti_id
			and lo.batch_id = al.batch_id
	        and lo.estado = c_en_curso;

	       	/** Venia de un lote planificado, que al unificarse con uno existente lo damos por finalizado */
	        if p_batch_id is not null and p_batch_id != 0 then 
	        	update prd.lotes 
	        	set estado = c_finalizado 	
	        	    ,usuario_app_ult_modificacion  = p_usuario_app 
	        	    ,fec_finalizado = now()
	        	where batch_id = p_batch_id;
	        end if;
			v_step='8';

    exception
		   when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 20 - error buscando lote para unificar reci,lote,arti:%:%:% error %:% ',p_reci_id,p_lote_id,p_arti_id,sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO:%',sqlerrm;
		   end;
				  
    end if;

   
    /********************************************************************************
     * BLOQUE 3: PADRES
     * ASOCIACION CON LOTES PADRE Y ACTUALIZACION ESTADOS Y DE CANTIDADES
     * 
     */
	RAISE INFO 'PRDCRLO - BL3 -  padres -  estado % batch id padre %',v_estado,p_batch_id_padre;

    if v_estado !=  c_planificado  then
		v_step='9';

    	/** Actualizo el arbol de batchs colocando el 
	     *  nuevo batch como hijo del p_batch_id_padre
	     * si el padre viene en 0 es un batch al inicio 
	     * del proceso productivo 
	     */
		insert into prd.lotes_hijos (
		batch_id
		,batch_id_padre
		,empr_id
		,cantidad
		,cantidad_padre)
		values
		(v_batch_id
		,case when p_batch_id_padre = 0 then null else p_batch_id_padre end
		,p_empr_id
		,p_cantidad
		,p_cantidad_padre);
		
		RAISE INFO 'PRDCRLO - Batch id % generado en recipiente %',v_batch_id,p_reci_id;
	
	    /**Cambiamos el estado del lote padre  a FINALIZADO si ya no quedan existencias
		 * y vacio el recipiente
		 */
		if (p_batch_id_padre !=0 ) then

                --Obtengo la existencia actual del padre para entender si finalizar
                v_step='10';

                begin
                    v_cantidad_padre = alm.obtener_existencia_batch(p_batch_id_padre);
                exception 
                    when others then
                        RAISE INFO 'PRDCRLO - no hay lote asociado, asumimos que es un batch sin producto %:%:% ',p_batch_id_padre,sqlstate,sqlerrm;
                        v_cantidad_padre = 0;
                end;
            		
				v_step='10,5';
				RAISE INFO 'PRDCRLO - cantidad padre existente:informada %.%',v_cantidad_padre,p_cantidad_padre;
		
                /* Si no queda producto en el lote padre, o si el lote no tiene asociado un producto, 
                   lo finalizo e intento vaciar el recipiente (si no existen otros lotes En curso en el mismo)*/
				if v_cantidad_padre - p_cantidad_padre = 0 or v_cantidad_padre=0 then
			
					RAISE INFO 'PRDCRLO - Finalizando lote % ',p_batch_id_padre;
					v_step='11';
	
					update prd.lotes
					set estado = c_finalizado
						,usuario_app_ult_modificacion  = p_usuario_app 
						,fec_finalizado = now()
					where batch_id = p_batch_id_padre
					returning reci_id into v_reci_id_padre;
					
					select count(1)
					into strict v_countLotesRec
					from prd.lotes
					where reci_id = v_reci_id_padre
					and estado = c_en_curso;
					
					/** Si no hay mas lotes activos en el recipiente lo pongo como VACIO **/
					if (v_countLotesRec = 0) then
						update prd.recipientes
						set estado = c_vacio
						where reci_id = v_reci_id_padre;
					end if;
				end if;
			
		
				/**
				 * Actualizo la existencia del padre si tiene producto asociado
				 */
                if v_cantidad_padre != 0 then
                    RAISE INFO 'PRDCRLO - actualizo existencia %:% ',p_batch_id_padre,p_cantidad_padre;
                    v_step='11,5';
                    v_resultado = alm.extraer_lote_articulo(p_batch_id_padre,p_cantidad_padre);
                end if;

			
		end if;

	
    end if;	

	/*************************************************************************************
	 * BLOQUE 4: ACTUALIZACION DE LOTE DEL PRODUCTO EN PRODUCCION
	 * EN ALMACENES EN CASO DE INFORMARSE ARTI_ID 
	 * 
	 */
	RAISE INFO 'PRDCRLO - BL4 -  lote producto - p_arti_id % v_estado %',p_arti_id,v_estado;
    /* si se informa articulos del lote los inserto en alm_lotes, sino no */
	if p_arti_id != 0 and v_estado != c_planificado  then 
		v_step='12';

		/** Si el recipiente esta vacio o unifico recipiente, creo un lote, sino actualizo el existente**/
		if v_estado_recipiente = c_vacio or  v_artDif or  v_lotDif then
	    		
				v_resultado = alm.crear_lote_articulo(
										p_prov_id
										,p_arti_id 
										,v_depo_id
										,p_lote_id 
										,p_cantidad 
										,p_fec_vencimiento
										,p_empr_id 
										,v_batch_id );
		else
			    RAISE INFO 'PRDCRLO - es un batch existente, agrego cantidad % al batch %',p_cantidad,v_batch_id;
	    		v_resultado = alm.agregar_lote_articulo(v_batch_id ,p_cantidad);

		end if;						
		RAISE INFO 'PRDCRLO - resultado ops almacen %',v_resultado;

	end if;

    /*************************************************************************
	 * BLOQUE 5: ACTUALIZACION DE RECURSO DE TRABAJO EN CASO DE INFORMARSE
	 * Viene informado en p_recu_id
	 */
    RAISE INFO 'PRDCRLO - BL5 RECURSO TRABAJO - recu_id %',p_recu_id;


	/** Si el actual lote tiene un recurso asociado lo asocio **/
    if p_recu_id is not null and p_recu_id != 0 then
       v_step='13';
	
       begin

	       RAISE INFO 'PRDCRLO - p_recu_id = %', p_recu_id;

			/** Valido que el recursos  exista  **/
			select recu_id
			into strict v_recu_id
			from prd.recursos recu
			where recu.recu_id = p_recu_id;

			/** Eliminio todo si fue grabado como planificado**/
			delete from prd.recursos_lotes
			where batch_id = v_batch_id
			and tipo=p_tipo_recurso;

			/* Inserto el recurso **/
			insert into prd.recursos_lotes(batch_id
											,recu_id
											,empr_id
											,cantidad
											,tipo)
					values (v_batch_id
							,p_recu_id
							,p_empr_id
							,p_cantidad
							,p_tipo_recurso);
						
		exception	   
		
			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 10 - recurso no encontrado %', p_recu_id;
				v_mensaje = 'RECU_NO_ENCONTRADO';
		        raise exception 'RECU_NO_ENCONTRADO:%',p_recu_id;
		       
		end;	

	end if;

	v_step='14';

    call prd.audit_lote(v_batch_id,'batch generado: '||v_batch_id||
                            ' lote:'||p_lote_id||
                            ' batch padre:'|| p_batch_id_padre||
                            ' recipiente: '||p_reci_id||
                            ' articulo: '||p_arti_id||
                            ' recurso ' ||p_recu_id||
                            ' forzar_agregar: '||p_forzar_agregar 
                            ,v_step);
    
	return v_batch_id;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'crear_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%:%<<',v_mensaje,v_step;
	    end if;

END; 
$$;


ALTER FUNCTION prd.crear_lote_v2(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying, p_fec_vencimiento date, p_recu_id integer, p_tipo_recurso character varying, p_planificado character varying, p_batch_id bigint, p_fec_alta timestamp without time zone) OWNER TO postgres;

--
-- Name: crear_lote_v2_old(character varying, integer, integer, bigint, double precision, double precision, character varying, integer, integer, character varying, integer, character varying, date, integer, character varying, character varying, bigint); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_lote_v2_old(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying DEFAULT 'false'::character varying, p_fec_vencimiento date DEFAULT NULL::date, p_recu_id integer DEFAULT NULL::integer, p_tipo_recurso character varying DEFAULT NULL::character varying, p_planificado character varying DEFAULT 'false'::character varying, p_batch_id bigint DEFAULT NULL::bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** Funcion para generar un nuevo lote
 *  Recibe como parametro un id de lote
 *  y un recipiente donde crear el batch.
 *  Si el recipiente esta ocupado, devuelve el error
 */
#print_strict_params on
DECLARE
 v_estado_recipiente prd.recipientes.estado%type; 
 v_batch_id prd.lotes.batch_id%type;
 v_batch_id_aux prd.lotes.batch_id%type;
 v_mensaje varchar;
 v_reci_id_padre prd.recipientes.reci_id%type;
 v_depo_id prd.recipientes.depo_id%type;
 v_lote_id prd.lotes.lote_id%type;
 v_arti_id alm.alm_lotes.arti_id%type;
 v_cantidad_padre alm.alm_lotes.cantidad%type;
 v_recu_id prd.recursos_lotes.recu_id%type;
 v_resultado varchar;
 v_estado varchar;
 v_cantidad float;
 v_cuenta integer;
 v_artDif boolean = false;
 v_lotDif boolean = false;
 v_lotartIgual boolean = false;
 v_countLotesRec integer = 0;
 v_info_error varchar;
 verificarRecipiente CURSOR (p_batch_id INTEGER
			   ,p_arti_id INTEGER
			   ,p_lote_id VARCHAR) for
				select lo.batch_id
				,al.arti_id
				,lo.lote_id
				from prd.lotes lo
				,alm.alm_lotes al
				where reci_id  = p_reci_id
				and (al.arti_id != p_arti_id or lo.lote_id != p_lote_id)
				and lo.batch_id = al.batch_id
				and lo.estado = 'En Curso';


BEGIN
		
		/* seteo el estado inicial dependiendo si se llama al procedure desde Guardar o desde Planificar estapa */
		if (p_planificado='true') then
			v_estado = 'PLANIFICADO';
		else
			v_estado = 'En Curso';
		end if;
		
		/**************************
		 * BLOQUE 1: VALIDO EL ESTADO DEL RECIPIENTE
		 */
		begin
		        
			RAISE INFO 'PRDCRLO - BL1 valido reci - ṕ_forzar_agregar = %, p_lote_id % ', p_forzar_agregar, p_lote_id;

			/** Valido que el recipiente exista y no tenga contenido **/
			select reci.estado
				   ,reci.depo_id
			into strict v_estado_recipiente
				,v_depo_id
			from PRD.RECIPIENTES reci
			where reci.reci_id = p_reci_id;

				       
	    		/*
		 	* 1 - si forzar_agregar = false, verifica si el recipiente esta vacio, si no esta vacio 
		 	*  a) verifica si en el recipiente esta el mismo articulo, sino retorna RECI_NO_VACIO_DIST_ART
		 	*  b) si es mismo articulo y distinto lote retorna RECI_NO_VACIO_DIST_LOTE_IGUAL_ART
		 	*  c) si es mismo arituclo y lote retorna RECI_NO_VACIO_MISMO_IGUAL_ART_LOTE
                	*/	
    
			if v_estado_recipiente != 'VACIO' then
				open verificarRecipiente(p_reci_id,p_arti_id,p_lote_id);
				loop
					fetch verificarRecipiente into v_batch_id_aux ,v_arti_id,v_lote_id;
					exit when NOT FOUND;
      
       				if v_arti_id != p_arti_id then 
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_arti_id p arti id % % %',v_batch_id_aux,v_arti_id,p_arti_id;
						v_artDif = true;
					elsif v_lote_id != p_lote_id then
       					RAISE DEBUG 'PRDCRLO - revisando recipientes batch v_lote_id p lote id % >%< >%<',v_batch_id_aux,v_lote_id,p_lote_id;
						v_lotDif = true;					        		
					else 
						v_lotartIgual = true;
					end if;
				end loop;
				close verificarRecipiente;
				RAISE INFO 'PRDCRLO - revisando recipientes banderas % % %',v_artDif,v_lotDif,v_lotartIgual;
			
				/* Corto la ejecución, hay que advertir al usuario que el recipiente no esta vacio y que decida que hacer **/
	    		if p_forzar_agregar!='true' and p_planificado = 'false' then
	
	    			v_info_error = 'reci_id='||p_reci_id||'-arti_id='||p_arti_id||'-lote_id='||p_lote_id;
					if v_artDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_ART'; /* caso a */
						raise exception 'RECI_NO_VACIO_DIST_ART-%',v_info_error;
					elsif v_lotDif then
			            v_mensaje = 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART'; /* caso b */
				    	raise exception 'RECI_NO_VACIO_DIST_LOTE_IGUAL_ART-%',v_info_error;
					else
			            v_mensaje = 'RECI_NO_VACIO_IGUAL_ART_LOTE'; /* caso c */
				    	raise exception 'RECI_NO_VACIO_IGUAL_ART_LOTE-%',v_info_error;
					end if;
				else	
					if v_lotartIgual then
						v_artDif = false;
						v_lotDif = false;
					end if;
				end if;	
	
			end if;
				  
		exception	   
			when too_many_rows then
		        RAISE INFO 'PRDCRLO - error 9 - recipiente duplicado %', p_reci_id;
				v_mensaje = 'RECI_DUPLICADO';
		        raise exception 'RECI_DUPLICADO:%',p_reci_id;

			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 2 - recipiente no encontrado %', p_reci_id;
				v_mensaje = 'RECI_NO_ENCONTRADO';
		        raise exception 'RECI_NO_ENCONTRADO:%',p_reci_id;
		       
		end;	

   /*******************************************
    * BLOQUE 2 CREO O REUTILIZO LOTE
    * 
    */
	
   /**
    * Una vez validado el recipiente, creo el nuevo lote
    * si forzar agregar = true, entonces
    *  para el caso a) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso b) crea un nuevo lote con mismo reci_id (unifica recipientes)
    *  para el caso c) actualiza la existencia del lote con mismo arti y lote (unifica lote)
     **/

    RAISE INFO 'PRDCRLO - BL2  lote -  v_estado_recipiente % v_artDif % v_lotDif % ', v_estado_recipiente,v_artDif,v_lotDif;
		
    if ( p_planificado = 'true' or ( v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif ) )then
   
	begin
	
    		if p_batch_id is not null and p_batch_id != 0 then
    		/* me informan un batch id existente, viene de un batch guardado pero no iniciado, no lo inserto*/
    			RAISE INFO 'PRDCRLO - reu lote -  v_estado = %, p_lote_id % y v_batch_id %: ', v_estado, p_lote_id, p_batch_id;

    			v_batch_id = p_batch_id;
    			
    			with updated_batch as (
	    			update prd.lotes 
	    			set lote_id = p_lote_id
	    				,estado = v_estado
	    				,num_orden_prod = p_num_orden_prod
	    				,reci_id = p_reci_id
	    			where batch_id = v_batch_id
	    			returning 1)
	    			
				select count(1)
				from updated_batch
				into strict v_cuenta;

				if v_cuenta = 0 then
			    	    RAISE INFO 'PRDCLO - no se encontro el batch id % cuenta % ', p_batch_id,v_cuenta;
			    	    raise 'BATCH_NO_ENCONTRADO-F';
			    end if;
    			
				    		
    		else
    		    RAISE INFO 'PRDCRLO - ins lote -  p_lote_id % ', p_lote_id;

				with inserted_batch as (
					insert into 
					prd.lotes (
					lote_id
					,estado
					,num_orden_prod
					,etap_id
					,usuario_app
					,reci_id
					,empr_id)	
					values (
					p_lote_id
					,v_estado
					,p_num_orden_prod
					,p_etap_id
					,p_usuario_app
					,p_reci_id
					,p_empr_id
					)
					returning batch_id
				)

				select batch_id
				into strict v_batch_id
				from inserted_batch;

				RAISE INFO 'PRDCRLO - ins lote -  v_batch_id % ', v_batch_id;

			end if;
		
			/** si estay grabando planificado no debo lockear el recipiente */
			if v_estado != 'PLANIFICADO' then		
			    
			    /** Actualizo el recipiente como lleno
			     */
			    update prd.recipientes 
			    set estado = 'LLENO'
			    where reci_id = p_reci_id;

			end if;
						
		
	   exception
		   when others then
		        RAISE INFO 'PRDCRLO - error 5 - error creando lote y recipiente  %:% ',sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO-RF:%',sqlerrm;
		   end;
    else /** Existe un recipiente lleno con mismo arti_id y lote_id que el lote que queremos crear, no lo creo sino unifico **/
	begin
			RAISE INFO 'PRDCRLO - nada con lote -  p_forzar_agregar = %', p_forzar_agregar;

	        select lo.batch_id
	        into strict v_batch_id
	        from prd.lotes lo
	             ,alm.alm_lotes al
	        where reci_id  = p_reci_id
            and lo.lote_id = p_lote_id 
	        and al.arti_id = p_arti_id
			and lo.batch_id = al.batch_id
	        and lo.estado = 'En Curso';

	       	/** Venia de un lote planificado, que al unificarse con uno existente lo damos por finalizado */
	        if p_batch_id is not null and p_batch_id != '' then 
	        	update prd.lotes 
	        	set estado ='FINALIZADO'
	        	where batch_id = p_batch_id;
	        end if;

    exception
		   when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 20 - error buscando lote para unificar reci,lote,arti:%:%:% error %:% ',p_reci_id,p_lote_id,p_arti_id,sqlstate,sqlerrm;
			v_mensaje = 'BATCH_NO_ENCONTRADO';
		        raise exception 'BATCH_NO_ENCONTRADO-MF:%',sqlerrm;
		   end;
				  
    end if;

   
    /********************************************************************************
     * BLOQUE 3: PADRES
     * ASOCIACION CON LOTES PADRE Y ACTUALIZACION ESTADOS Y DE CANTIDADES
     * 
     */
	RAISE INFO 'PRDCRLO - BL3 -  padres -  estado % batch id padre %',v_estado,p_batch_id_padre;
   
    if v_estado != 'PLANIFICADO' then

    	/** Actualizo el arbol de batchs colocando el 
	     *  nuevo batch como hijo del p_batch_id_padre
	     * si el padre viene en 0 es un batch al inicio 
	     * del proceso productivo 
	     */
		insert into prd.lotes_hijos (
		batch_id
		,batch_id_padre
		,empr_id
		,cantidad
		,cantidad_padre)
		values
		(v_batch_id
		,case when p_batch_id_padre = 0 then null else p_batch_id_padre end
		,p_empr_id
		,p_cantidad
		,p_cantidad_padre);
		
		RAISE INFO 'PRDCRLO - Batch id % generado en recipiente %',v_batch_id,p_reci_id;
	
	    /**Cambiamos el estado del lote origen a FINALIZADO si ya no quedan existencias
		 * y vacio el recipiente
		 */
		if (p_batch_id_padre !=0 and p_cantidad_padre != 0) then
		
			--Obtengo la existencia actual del padre para entender si finalizar
			v_cantidad_padre = alm.obtener_existencia_batch(p_batch_id_padre);
			
			RAISE INFO 'PRDCRLO - cantidad padre existente:informada %.%',v_cantidad_padre,p_cantidad_padre;
	
			if v_cantidad_padre - p_cantidad_padre = 0 then
		
				RAISE INFO 'PRDCRLO - Finalizando lote % ',p_batch_id_padre;
	
				update prd.lotes
				set estado = 'FINALIZADO'
				where batch_id = p_batch_id_padre
				returning reci_id into v_reci_id_padre;
				
				select count(1)
				into strict v_countLotesRec
				from prd.lotes
				where reci_id = v_reci_id_padre
				and estado = 'En Curso';
				
				/** Si no hay mas lotes activos en el recipiente lo pongo como VACIO **/
				if (v_countLotesRec = 0) then
					update prd.recipientes
					set estado = 'VACIO'
					where reci_id = v_reci_id_padre;
				end if;
			end if;
		
	
			/**
			 * Actualizo la existencia del padre
			 */
	
			RAISE INFO 'PRDCRLO - actualizo existencia %:% ',p_batch_id_padre,p_cantidad_padre;
	
			v_resultado = alm.extraer_lote_articulo(p_batch_id_padre,p_cantidad_padre);
		
		end if;
	    /**
	     * Genera el lote asociado en almacenes
	     *
	     */
	
    end if;	

	/*************************************************************************************
	 * BLOQUE 4: ACTUALIZACION DE LOTE DEL PRODUCTO EN PRODUCCION
	 * EN ALMACENES EN CASO DE INFORMARSE ARTI_ID 
	 * 
	 */
	RAISE INFO 'PRDCRLO - BL4 -  lote producto - p_arti_id % v_estado %',p_arti_id,v_estado;
   
	if p_arti_id != 0 and v_estado != 'PLANIFICADO' then --si se informa articulos del lote los inserto en alm_lotes, sino no

		/** mismas condiciones que al insertar batch para insertar lote almacen o actualizar**/
		if v_estado_recipiente = 'VACIO' or  v_artDif or  v_lotDif then
	    		
				v_resultado = alm.crear_lote_articulo(
										p_prov_id
										,p_arti_id 
										,v_depo_id
										,p_lote_id 
										,p_cantidad 
										,p_fec_vencimiento
										,p_empr_id 
										,v_batch_id );
		else
			    RAISE INFO 'PRDCRLO - es un batch existente, agrego cantidad % al batch %',p_cantidad,v_batch_id;
	    		v_resultado = alm.agregar_lote_articulo(v_batch_id ,p_cantidad);

		end if;						
		RAISE INFO 'PRDCRLO - resultado ops almacen %',v_resultado;

	end if;


	/*************************************************************************
	 * BLOQUE 5: ACTUALIZACION DE RECURSO DE TRABAJO EN CASO DE INFORMARSE
	 * 
	 */
    RAISE INFO 'PRDCRLO - BL5 RECURSO TRABAJO - recu_id %',p_recu_id;


	/** Si el actual lote tiene un recurso asociado lo asocio **/
    if p_recu_id is not null and p_recu_id != 0 then
    	
       begin

	       RAISE INFO 'PRDCRLO - p_recu_id = %', p_recu_id;

			/** Valido que el recursos  exista  **/
			select recu_id
			into strict v_recu_id
			from prd.recursos recu
			where recu.recu_id = p_recu_id;

			/** Eliminio todo si fue grabado como planificado**/
			delete from prd.recursos_lotes
			where batch_id = v_batch_id
			and tipo=p_tipo_recurso;

			/* Inserto el recurso **/
			insert into prd.recursos_lotes(batch_id
											,recu_id
											,empr_id
											,cantidad
											,tipo)
					values (v_batch_id
							,p_recu_id
							,p_empr_id
							,p_cantidad
							,p_tipo_recurso);
						
		exception	   
		
			when NO_DATA_FOUND then
		        RAISE INFO 'PRDCRLO - error 10 - recurso no encontrado %', p_recu_id;
				v_mensaje = 'RECU_NO_ENCONTRADO';
		        raise exception 'RECU_NO_ENCONTRADO:%',p_recu_id;
		       
		end;	

	end if;

	return v_batch_id;


exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'crear_lote: error al crear lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;

END; 
$$;


ALTER FUNCTION prd.crear_lote_v2_old(p_lote_id character varying, p_arti_id integer, p_prov_id integer, p_batch_id_padre bigint, p_cantidad double precision, p_cantidad_padre double precision, p_num_orden_prod character varying, p_reci_id integer, p_etap_id integer, p_usuario_app character varying, p_empr_id integer, p_forzar_agregar character varying, p_fec_vencimiento date, p_recu_id integer, p_tipo_recurso character varying, p_planificado character varying, p_batch_id bigint) OWNER TO postgres;

--
-- Name: crear_prd_recurso_trg(); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.crear_prd_recurso_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
  BEGIN
    /** funcion para utilizarse on insert para insertar el articulo como recurso
     * 
     */
    INSERT INTO prd.recursos
    (tipo
     ,arti_id
     ,empr_id
     )
    values
    ('MATERIAL'
     ,new.arti_id
     ,new.empr_id);

    return new;
exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise 'crear_recurso: error al crear recurso %-%-%-%',new.arti_id,new.empr_id, sqlstate,sqlerrm;

    END;
$$;


ALTER FUNCTION prd.crear_prd_recurso_trg() OWNER TO postgres;

--
-- Name: eliminar_prd_recurso_trg(); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.eliminar_prd_recurso_trg() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
  BEGIN
    /** funcion para utilizarse on insert para insertar el articulo como recurso
     * 
     */
    delete from prd.recursos
    where arti_id = old.arti_id;
   
	return new;
    END;
$$;


ALTER FUNCTION prd.eliminar_prd_recurso_trg() OWNER TO postgres;

--
-- Name: finalizar_lote(bigint); Type: FUNCTION; Schema: prd; Owner: postgres
--

CREATE FUNCTION prd.finalizar_lote(p_batch_id bigint) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
/** Funcion para finalizar un lote que no tiene producto, y vaciar recipiente 
 *  si no hay otros lotes utilizando el recipiente
 *  @author RRuiz
 */
#print_strict_params on
DECLARE
 v_cantidad alm.alm_lotes.cantidad%type;
 v_reci_id prd.recipientes.reci_id%type;
 v_tieneProd boolean = false;
 v_countLotesRec integer = 0;
 v_mensaje varchar;


BEGIN

	/* Primero obtengo la cantidad del producto asociado al lote, deberia salir 
	 * por excepción y poner la bandera en true			
	 * 
	 */
    RAISE INFO 'PRDFILO - Finalizando lote % ',p_batch_id;

    begin

        v_cantidad = alm.obtener_existencia_batch(p_batch_id);

       RAISE INFO 'PRDFILO - cant %',v_cantidad;
		if v_cantidad is null then
			v_tieneProd = false;
	 	else
       		v_tieneProd = true;
		end if;
    exception 
        when others then
            v_tieneProd = false;
        	RAISE INFO 'PRDFILO - no hay lote asociado, asumimos que es un batch sin producto %:%:% ',p_batch_id,sqlstate,sqlerrm;
    end;
		    
	/* Cambio el estado solo si no tiene producto */
	if v_tieneProd = false then
		RAISE INFO 'PRDFILO - El lote no tiene producto, finalizando';

		update prd.lotes
		set estado = 'FINALIZADO'
		where batch_id = p_batch_id
		returning reci_id into v_reci_id;
		
		select count(1)
		into strict v_countLotesRec
		from prd.lotes
		where reci_id = v_reci_id
		and estado = 'En Curso';
		
		/** Si no hay mas lotes activos en el recipiente lo pongo como VACIO **/
		if (v_countLotesRec = 0) then
    		RAISE INFO 'PRDFILO - Actualizo recipiente como vacio % ',v_reci_id;
			update prd.recipientes
			set estado = 'VACIO'
			where reci_id = v_reci_id;
		end if;
	end if;
    return 'ok';

exception
	when others then
	    /** capturo cualquier posible excepcion y la retorno como respuesta **/
	    raise warning 'PRDFILO: error al finalizar lote %: %', sqlstate,sqlerrm;

		v_mensaje=sqlerrm;
		if v_mensaje is null or v_mensaje = '' then	
	    	raise '>>TOOLSERROR:ERROR_INTERNO<<';
	    else
	    	raise '>>TOOLSERROR:%<<',v_mensaje;
	    end if;

END; 
$$;


ALTER FUNCTION prd.finalizar_lote(p_batch_id bigint) OWNER TO postgres;

--
-- Name: bulkload_articulos(character varying, integer); Type: FUNCTION; Schema: sta; Owner: postgres
--

CREATE FUNCTION sta.bulkload_articulos(p_archivo character varying, p_empr_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
	v_codigo_aux varchar;
	v_descripcion_aux varchar;
 	v_umedida_aux varchar;
 	v_tipo_aux varchar;
	cur_articsv CURSOR FOR SELECT
						ltrim(rtrim(upper(ar."Código")))
						, ar."Descripción"
						, ltrim(rtrim(upper( ar."U. Medida")))
						, sta.calcula_tipo_articulo(ar."Código")
						FROM sta.articulos ar
						WHERE ar.procesado = FALSE;

 	BEGIN
		/**
		 * Carga de un archivo csv
		 * 	con columnas "Código","Descripción", "U. Medida"
		 * los datos en alm_articulos
		 * la primer fila de csv debe tener estos nombres no importa el orden
		 */
	    RAISE INFO 'BULKART: Cargando archivo % con empresa %',p_archivo, p_empr_id;

		BEGIN

		   EXECUTE 
			FORMAT('COPY sta.articulos (id,"Etapa","U. Medida","Código","Descripción") FROM %s WITH CSV HEADER'
		    ,p_archivo);
	       
		    RAISE INFO 'BULKART: Archivo cargado';
       
		    RAISE INFO 'BULKART: Eliminando registros sin codigo o descripcion con empresa %',p_empr_id;

			DELETE FROM sta.articulos ar 
			WHERE ar."Código" IS  NULL
			OR ar."Descripción" IS NULL;

			RAISE INFO 'BULKART: Insertando registros';
			open cur_articsv;
			loop
				fetch cur_articsv into v_codigo_aux,v_descripcion_aux,v_umedida_aux,v_tipo_aux;
				exit when NOT FOUND;
	    		
				RAISE INFO 'BULKART: Procesando registro  %-%-%-%',v_codigo_aux,v_descripcion_aux,v_umedida_aux,v_tipo_aux;
      		
				INSERT INTO
					alm.alm_articulos (
					    barcode 
					    ,descripcion 
					    ,costo 
					    ,es_caja 
					    ,cantidad_caja 
					    ,punto_pedido 
					    ,estado 
					    ,unidad_medida 
					    ,empr_id 
					    ,es_loteado
					    ,tipo)
				 VALUES(
						v_codigo_aux
						,v_descripcion_aux
						,0
						,FALSE
						,0
						,0
						,'AC'
						,v_umedida_aux
						,p_empr_id
						,FALSE
						,v_tipo_aux);
			end loop;
			CLOSE cur_articsv;
			RAISE INFO 'BULKART: Registros cargados, marcando batch como procesado';

			UPDATE
				sta.articulos
			SET
				procesado = TRUE
				, fec_proceso = now()
			WHERE
				procesado = FALSE;

			RAISE INFO 'BULKART: Carga bulk terminada exitosamente';
	EXCEPTION	
		when others then
			/* Borro el actual CSV con error*/
			DELETE FROM sta.articulos ar 
			WHERE ar.procesado = FALSE;
			raise EXCEPTION 'BULKART: error al cargar batch de articulos %: %', sqlstate,sqlerrm;

	END;

	RETURN TRUE;
END;
$$;


ALTER FUNCTION sta.bulkload_articulos(p_archivo character varying, p_empr_id integer) OWNER TO postgres;

--
-- Name: bulkload_articulos_etapas(character varying, integer); Type: FUNCTION; Schema: sta; Owner: postgres
--

CREATE FUNCTION sta.bulkload_articulos_etapas(p_archivo character varying, p_empr_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
	v_etapa_aux varchar;
	v_entrada_aux varchar;
 	v_salida_aux varchar;
 	v_producto_aux varchar;
 	v_etap_id int4;
	cur_artietapcsv CURSOR FOR SELECT
						ltrim(rtrim(upper(ae."Etapa")))
						, ltrim(rtrim(upper(ae."Entrada"))) 
						, ltrim(rtrim(upper(ae."Producto"))) 
						, ltrim(rtrim(upper(ae."Salida"))) 
						FROM sta.articulos_etapas ae 
						WHERE ae.procesado = FALSE;

 	BEGIN
		/**
		 * Carga de un archivo csv
		 * 	con columnas "Etapa","Entrada", "Producto","Salida"
		 * los datos en prd.etapas_materiales (entrada), prd.etapas_productos y prd.etapas_salidas
		 * la primer fila de csv debe tener estos nombres no importa el orden
		 */
	    RAISE INFO 'BULKARET: Cargando archivo % con empresa %',p_archivo, p_empr_id;

		BEGIN

		   EXECUTE 
			FORMAT('COPY sta.articulos_etapas ("Etapa","Entrada","Producto","Salida") FROM %s WITH CSV HEADER'
		    ,p_archivo);
	       
		    RAISE INFO 'BULKARET: Archivo cargado';
       
		    RAISE INFO 'BULKARET: Eliminando registros invalidos  %',p_empr_id;

			DELETE FROM sta.articulos_etapas ar 
			WHERE ar."Etapa" IS  NULL
			OR (ar."Entrada" = '0' AND ar."Producto" = '0'AND ar."Salida" ='0')
			OR (ar."Entrada" IS NULL AND ar."Producto" IS NULL AND ar."Salida" IS NULL);

			RAISE INFO 'BULKARET: Insertando registros';
			open cur_artietapcsv;
			loop
				fetch cur_artietapcsv into v_etapa_aux,v_entrada_aux,v_producto_aux,v_salida_aux;
				exit when NOT FOUND;
	    		
				RAISE INFO 'BULKARET: Obtengo etapa %',v_etapa_aux;
	
				SELECT etap_id 
				INTO STRICT v_etap_id
				FROM prd.etapas e 
				WHERE UPPER(E.nombre )= v_etapa_aux
				AND e.empr_id = p_empr_id;
			
				RAISE INFO 'BULKARET: Procesando registro  %(%)-%-%-%<<',v_etapa_aux,v_etap_id,v_entrada_aux,v_producto_aux,v_salida_aux;      		


				IF v_entrada_aux IS NOT NULL AND v_entrada_aux != '' AND v_entrada_aux !='0' THEN 
				
					RAISE INFO 'BULKARET: Insertando en etapas_materiales  %(%)-%<<',v_etapa_aux,v_etap_id,v_entrada_aux;      		
					BEGIN
						
						INSERT INTO prd.etapas_materiales
						(arti_id 
						,etap_id )
						SELECT a.arti_id
						,v_etap_id
						FROM alm.alm_articulos a 
						WHERE a.barcode = v_entrada_aux
						AND a.empr_id =p_empr_id;
					EXCEPTION
						WHEN unique_violation THEN
							RAISE INFO 'BULKARET: Registro existente, obviando';      		
					END;
				
					END IF;
			
				IF v_producto_aux IS NOT NULL AND v_producto_aux != '' AND v_producto_aux !='0' THEN 
				
					BEGIN 
						RAISE INFO 'BULKARET: Insertando en etapas_productos  %(%)-%<<',v_etapa_aux,v_etap_id,v_producto_aux;      		
						INSERT INTO prd.etapas_productos
						(arti_id 
						,etap_id )
						SELECT a.arti_id
						,v_etap_id
						FROM alm.alm_articulos a 
						WHERE a.barcode = v_producto_aux
						AND a.empr_id =p_empr_id;

					EXCEPTION
						WHEN unique_violation THEN
							RAISE INFO 'BULKARET: Registro existente, obviando';      		
					END;

				END IF;
			
				IF v_salida_aux IS NOT NULL AND v_salida_aux != '' AND v_salida_aux !='0' THEN 

					BEGIN 
						RAISE INFO 'BULKARET: Insertando en etapas_salidas  %(%)-%<<',v_etapa_aux,v_etap_id,v_salida_aux;      		
						INSERT INTO prd.etapas_salidas 
						(arti_id 
						,etap_id )
						SELECT a.arti_id
						,v_etap_id
						FROM alm.alm_articulos a 
						WHERE a.barcode = v_salida_aux
						AND a.empr_id =p_empr_id;
					EXCEPTION
						WHEN unique_violation THEN
							RAISE INFO 'BULKARET: Registro existente, obviando';      		
					END;

				END IF;
		
	
			end loop;
			CLOSE cur_artietapcsv;
			RAISE INFO 'BULKARET: Registros cargados, marcando batch como procesado';

			UPDATE
				sta.articulos_etapas 
			SET
				procesado = TRUE
				, fec_proceso = now()
			WHERE
				procesado = FALSE;

			RAISE INFO 'BULKARET: Carga bulk terminada exitosamente';
	EXCEPTION	
		when others then
			/* Borro el actual CSV con error*/
			DELETE FROM sta.articulos_etapas ar 
			WHERE ar.procesado = FALSE;
			raise EXCEPTION 'BULKARET: error al cargar batch de articulos %: %', sqlstate,sqlerrm;

	END;

	RETURN TRUE;
END;
$$;


ALTER FUNCTION sta.bulkload_articulos_etapas(p_archivo character varying, p_empr_id integer) OWNER TO postgres;

--
-- Name: calcula_tipo_articulo(character varying); Type: FUNCTION; Schema: sta; Owner: postgres
--

CREATE FUNCTION sta.calcula_tipo_articulo(p_codigo character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		v_trailing varchar;
		v_tipo varchar;
	BEGIN
		/** Calcula de acuerdo al codigo el id 
		 *  de tipo de articulo
		 *  @author rruiz
		 */
		v_trailing = substring(p_codigo,1,2);
		
		SELECT t.tabl_id
		INTO STRICT v_tipo
		FROM core.tablas t 
		WHERE t.tabla = 'tipo_articulo'
		AND t.valor2 = v_trailing;
	
		RETURN v_tipo;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
			RAISE INFO 'CALCTIPO: El tipo de articulo no se puede calcular para el codigo % - y con 2 primeras letras %',p_codigo, v_trailing;
			RETURN 'ERROR';
       
	END;
$$;


ALTER FUNCTION sta.calcula_tipo_articulo(p_codigo character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ajustes; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.ajustes (
    ajus_id integer NOT NULL,
    tipo_ajuste character varying,
    justificacion character varying,
    usuario_app character varying,
    empr_id integer NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL
);


ALTER TABLE alm.ajustes OWNER TO postgres;

--
-- Name: ajustes_ajus_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.ajustes_ajus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.ajustes_ajus_id_seq OWNER TO postgres;

--
-- Name: ajustes_ajus_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.ajustes_ajus_id_seq OWNED BY alm.ajustes.ajus_id;


--
-- Name: alm_articulos; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_articulos (
    arti_id integer NOT NULL,
    barcode character varying(50) NOT NULL,
    descripcion character varying(1000),
    costo numeric(14,2),
    es_caja boolean NOT NULL,
    cantidad_caja integer,
    punto_pedido integer,
    estado character varying(45) DEFAULT 'AC'::character varying,
    unidad_medida character varying(45),
    empr_id integer NOT NULL,
    es_loteado boolean NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false NOT NULL,
    tiar_id character varying,
    unme_id character varying
);


ALTER TABLE alm.alm_articulos OWNER TO postgres;

--
-- Name: alm_articulos_arti_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_articulos_arti_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_articulos_arti_id_seq OWNER TO postgres;

--
-- Name: alm_articulos_arti_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_articulos_arti_id_seq OWNED BY alm.alm_articulos.arti_id;


--
-- Name: alm_depositos; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_depositos (
    depo_id integer NOT NULL,
    descripcion character varying(255) DEFAULT NULL::character varying,
    direccion character varying(255) DEFAULT NULL::character varying,
    gps character varying(255) DEFAULT NULL::character varying,
    estado character varying(10),
    loca_id character varying(255) DEFAULT NULL::character varying,
    pais_id character varying(255) DEFAULT NULL::character varying,
    empr_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false NOT NULL,
    reci_id integer,
    esta_id integer NOT NULL
);


ALTER TABLE alm.alm_depositos OWNER TO postgres;

--
-- Name: alm_depositos_depo_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_depositos_depo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_depositos_depo_id_seq OWNER TO postgres;

--
-- Name: alm_depositos_depo_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_depositos_depo_id_seq OWNED BY alm.alm_depositos.depo_id;


--
-- Name: alm_deta_entrega_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_deta_entrega_materiales (
    deen_id integer NOT NULL,
    enma_id integer NOT NULL,
    cantidad integer NOT NULL,
    arti_id integer NOT NULL,
    prov_id integer,
    lote_id integer NOT NULL,
    depo_id integer,
    empr_id integer NOT NULL,
    precio double precision,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE alm.alm_deta_entrega_materiales OWNER TO postgres;

--
-- Name: alm_deta_entrega_materiales_deen_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_deta_entrega_materiales_deen_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_deta_entrega_materiales_deen_id_seq OWNER TO postgres;

--
-- Name: alm_deta_entrega_materiales_deen_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_deta_entrega_materiales_deen_id_seq OWNED BY alm.alm_deta_entrega_materiales.deen_id;


--
-- Name: alm_deta_pedidos_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_deta_pedidos_materiales (
    depe_id integer NOT NULL,
    cantidad integer,
    resto integer,
    fecha_entrega date,
    fecha_entregado date,
    pema_id integer NOT NULL,
    arti_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE alm.alm_deta_pedidos_materiales OWNER TO postgres;

--
-- Name: alm_deta_pedidos_materiales_depe_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_deta_pedidos_materiales_depe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_deta_pedidos_materiales_depe_id_seq OWNER TO postgres;

--
-- Name: alm_deta_pedidos_materiales_depe_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_deta_pedidos_materiales_depe_id_seq OWNED BY alm.alm_deta_pedidos_materiales.depe_id;


--
-- Name: alm_deta_recepcion_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_deta_recepcion_materiales (
    dere_id integer NOT NULL,
    cantidad double precision NOT NULL,
    precio double precision,
    empr_id integer NOT NULL,
    rema_id integer NOT NULL,
    lote_id integer NOT NULL,
    prov_id integer NOT NULL,
    arti_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE alm.alm_deta_recepcion_materiales OWNER TO postgres;

--
-- Name: alm_deta_recepcion_materiales_dere_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_deta_recepcion_materiales_dere_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_deta_recepcion_materiales_dere_id_seq OWNER TO postgres;

--
-- Name: alm_deta_recepcion_materiales_dere_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_deta_recepcion_materiales_dere_id_seq OWNED BY alm.alm_deta_recepcion_materiales.dere_id;


--
-- Name: alm_entrega_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_entrega_materiales (
    enma_id integer NOT NULL,
    fecha date,
    solicitante character varying(100) DEFAULT NULL::character varying,
    dni character varying(45) DEFAULT NULL::character varying,
    comprobante character varying(50) DEFAULT NULL::character varying,
    empr_id integer NOT NULL,
    pema_id integer,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE alm.alm_entrega_materiales OWNER TO postgres;

--
-- Name: alm_entrega_materiales_enma_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_entrega_materiales_enma_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_entrega_materiales_enma_id_seq OWNER TO postgres;

--
-- Name: alm_entrega_materiales_enma_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_entrega_materiales_enma_id_seq OWNED BY alm.alm_entrega_materiales.enma_id;


--
-- Name: alm_lotes; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_lotes (
    lote_id integer NOT NULL,
    prov_id integer NOT NULL,
    arti_id integer NOT NULL,
    depo_id integer NOT NULL,
    codigo character varying(255) DEFAULT NULL::character varying,
    fec_vencimiento date,
    cantidad double precision,
    empr_id integer NOT NULL,
    user_id integer,
    estado character varying DEFAULT 'AC'::character varying,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    batch_id bigint
);


ALTER TABLE alm.alm_lotes OWNER TO postgres;

--
-- Name: alm_lotes_lote_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_lotes_lote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_lotes_lote_id_seq OWNER TO postgres;

--
-- Name: alm_lotes_lote_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_lotes_lote_id_seq OWNED BY alm.alm_lotes.lote_id;


--
-- Name: alm_pedidos_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_pedidos_materiales (
    pema_id integer NOT NULL,
    fecha date NOT NULL,
    motivo_rechazo character varying(500) DEFAULT NULL::character varying,
    justificacion character varying(300) DEFAULT NULL::character varying,
    case_id integer,
    ortr_id integer,
    estado character varying(45) DEFAULT 'PLANIFICADO'::character varying,
    empr_id integer,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    batch_id integer
);


ALTER TABLE alm.alm_pedidos_materiales OWNER TO postgres;

--
-- Name: alm_pedidos_materiales_pema_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_pedidos_materiales_pema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_pedidos_materiales_pema_id_seq OWNER TO postgres;

--
-- Name: alm_pedidos_materiales_pema_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_pedidos_materiales_pema_id_seq OWNED BY alm.alm_pedidos_materiales.pema_id;


--
-- Name: alm_proveedores; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_proveedores (
    prov_id integer NOT NULL,
    nombre character varying(255) DEFAULT NULL::character varying,
    cuit character varying(50) DEFAULT NULL::character varying,
    domicilio character varying(255) DEFAULT NULL::character varying,
    telefono character varying(50) DEFAULT NULL::character varying,
    email character varying(100) DEFAULT NULL::character varying,
    empr_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    loca_id character varying,
    esta_id character varying,
    pais_id character varying
);


ALTER TABLE alm.alm_proveedores OWNER TO postgres;

--
-- Name: alm_proveedores_articulos; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_proveedores_articulos (
    prov_id integer NOT NULL,
    arti_id integer NOT NULL
);


ALTER TABLE alm.alm_proveedores_articulos OWNER TO postgres;

--
-- Name: alm_proveedores_prov_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_proveedores_prov_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_proveedores_prov_id_seq OWNER TO postgres;

--
-- Name: alm_proveedores_prov_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_proveedores_prov_id_seq OWNED BY alm.alm_proveedores.prov_id;


--
-- Name: alm_recepcion_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.alm_recepcion_materiales (
    rema_id integer NOT NULL,
    fecha timestamp without time zone NOT NULL,
    comprobante character varying(255) NOT NULL,
    empr_id integer NOT NULL,
    prov_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    batch_id integer
);


ALTER TABLE alm.alm_recepcion_materiales OWNER TO postgres;

--
-- Name: alm_recepcion_materiales_rema_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.alm_recepcion_materiales_rema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.alm_recepcion_materiales_rema_id_seq OWNER TO postgres;

--
-- Name: alm_recepcion_materiales_rema_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.alm_recepcion_materiales_rema_id_seq OWNED BY alm.alm_recepcion_materiales.rema_id;


--
-- Name: deta_ajustes; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.deta_ajustes (
    deaj_id integer NOT NULL,
    cantidad double precision,
    empr_id integer NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER,
    lote_id integer,
    ajus_id integer NOT NULL
);


ALTER TABLE alm.deta_ajustes OWNER TO postgres;

--
-- Name: deta_ajustes_deaj_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.deta_ajustes_deaj_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.deta_ajustes_deaj_id_seq OWNER TO postgres;

--
-- Name: deta_ajustes_deaj_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.deta_ajustes_deaj_id_seq OWNED BY alm.deta_ajustes.deaj_id;


--
-- Name: deta_movimientos_internos; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.deta_movimientos_internos (
    demi_id integer NOT NULL,
    codigo character varying(255) DEFAULT NULL::character varying,
    cantidad_cargada double precision NOT NULL,
    cantidad_recibida double precision,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying,
    moin_id integer NOT NULL,
    arti_id integer,
    lote_id_origen integer,
    lote_id_destino integer
);


ALTER TABLE alm.deta_movimientos_internos OWNER TO postgres;

--
-- Name: deta_movimientos_internos_demi_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.deta_movimientos_internos_demi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.deta_movimientos_internos_demi_id_seq OWNER TO postgres;

--
-- Name: deta_movimientos_internos_demi_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.deta_movimientos_internos_demi_id_seq OWNED BY alm.deta_movimientos_internos.demi_id;


--
-- Name: items; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.items (
    item_id integer NOT NULL,
    label character varying(45),
    name character varying(45),
    requerido smallint NOT NULL,
    tipo_dato character varying(45),
    valo_id character varying(45),
    orden integer,
    aux character varying(45),
    mostrar character varying(10),
    cond_mostrar character varying(50),
    deshabilitado character varying(10),
    cond_habilitado character varying(50),
    fec_alta timestamp without time zone DEFAULT now(),
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE alm.items OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.items_item_id_seq OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.items_item_id_seq OWNED BY alm.items.item_id;


--
-- Name: lotes; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.lotes (
    lote_id character varying,
    batch_id bigint NOT NULL,
    estado character varying NOT NULL,
    num_orden_prod character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    etap_id integer NOT NULL,
    eliminado smallint DEFAULT 0 NOT NULL,
    nombre character varying,
    reci_id integer,
    empr_id integer,
    usuario_app character varying,
    arti_id integer,
    info_id integer,
    fec_planificado timestamp without time zone,
    fec_iniciado timestamp without time zone,
    fec_finalizado timestamp without time zone,
    fec_ult_modificacion timestamp without time zone,
    usuario_app_ult_modificacion character varying
);


ALTER TABLE prd.lotes OWNER TO postgres;

--
-- Name: lotes_hijos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.lotes_hijos (
    batch_id integer NOT NULL,
    batch_id_padre integer,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    eliminado smallint DEFAULT 0 NOT NULL,
    empr_id integer,
    cantidad double precision,
    cantidad_padre double precision
);


ALTER TABLE prd.lotes_hijos OWNER TO postgres;

--
-- Name: movimientos_historicos_vw; Type: VIEW; Schema: alm; Owner: postgres
--

CREATE VIEW alm.movimientos_historicos_vw AS
 SELECT adem.enma_id AS referencia,
    adem.cantidad,
    adem.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    al.codigo AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'EGRESO'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM alm.alm_deta_entrega_materiales adem,
    alm.alm_articulos aa,
    alm.alm_lotes al,
    alm.alm_depositos ad
  WHERE ((aa.arti_id = adem.arti_id) AND (al.lote_id = adem.lote_id) AND (al.depo_id = ad.depo_id))
UNION ALL
 SELECT adrm.rema_id AS referencia,
    adrm.cantidad,
    adrm.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    al.codigo AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'INGRESO'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM alm.alm_deta_recepcion_materiales adrm,
    alm.alm_articulos aa,
    alm.alm_lotes al,
    alm.alm_depositos ad
  WHERE ((aa.arti_id = adrm.arti_id) AND (al.lote_id = adrm.lote_id) AND (al.depo_id = ad.depo_id))
UNION ALL
 SELECT dmi.demi_id AS referencia,
    dmi.cantidad_recibida AS cantidad,
    dmi.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    al.codigo AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'MOV. ENTRADA'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM alm.deta_movimientos_internos dmi,
    alm.alm_articulos aa,
    alm.alm_lotes al,
    alm.alm_depositos ad
  WHERE ((aa.arti_id = dmi.arti_id) AND (al.lote_id = dmi.lote_id_destino) AND (ad.depo_id = al.depo_id))
UNION ALL
 SELECT dmi.demi_id AS referencia,
    dmi.cantidad_cargada AS cantidad,
    dmi.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    al.codigo AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'MOV. SALIDA'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM alm.deta_movimientos_internos dmi,
    alm.alm_articulos aa,
    alm.alm_lotes al,
    alm.alm_depositos ad
  WHERE ((aa.arti_id = dmi.arti_id) AND (al.lote_id = dmi.lote_id_destino) AND (ad.depo_id = al.depo_id))
UNION ALL
 SELECT da.deaj_id AS referencia,
    da.cantidad,
    da.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    al.codigo AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'AJUSTE'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM alm.deta_ajustes da,
    alm.alm_lotes al,
    alm.alm_articulos aa,
    alm.alm_depositos ad
  WHERE ((da.lote_id = al.lote_id) AND (al.arti_id = aa.arti_id) AND (ad.depo_id = al.depo_id))
UNION ALL
 SELECT lh.batch_id AS referencia,
    lh.cantidad,
    lh.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    (lh.batch_id)::character varying AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'INGRESO PRODUCTO'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM prd.lotes_hijos lh,
    prd.lotes lpadre,
    prd.lotes l2,
    alm.alm_lotes al,
    alm.alm_articulos aa,
    alm.alm_depositos ad
  WHERE ((lh.batch_id_padre = lpadre.batch_id) AND (lh.batch_id = l2.batch_id) AND (l2.batch_id = al.batch_id) AND (al.arti_id = aa.arti_id) AND (lpadre.etap_id < 1000) AND (al.depo_id = ad.depo_id))
UNION ALL
 SELECT lh.batch_id AS referencia,
    lh.cantidad,
    lh.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    (lh.batch_id)::character varying AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'INGRESO PROD. EN PROCESO'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM prd.lotes_hijos lh,
    prd.lotes l,
    alm.alm_lotes al,
    alm.alm_articulos aa,
    alm.alm_depositos ad
  WHERE ((lh.batch_id = l.batch_id) AND (l.batch_id = al.batch_id) AND (al.arti_id = aa.arti_id) AND (l.etap_id < 1000) AND (al.depo_id = ad.depo_id))
UNION ALL
 SELECT lh.batch_id_padre AS referencia,
    lh.cantidad_padre AS cantidad,
    lh.fec_alta,
    aa.barcode AS codigo,
    aa.descripcion,
    (lh.batch_id)::character varying AS lote,
    al.cantidad AS stock_actual,
    ad.descripcion AS deposito,
    al.depo_id,
    'EGRESO PROD. EN PROCESO'::text AS tipo_mov,
    aa.arti_id,
    al.lote_id
   FROM prd.lotes_hijos lh,
    prd.lotes l,
    alm.alm_lotes al,
    alm.alm_articulos aa,
    alm.alm_depositos ad
  WHERE ((lh.batch_id_padre = l.batch_id) AND (l.etap_id < 1000) AND (l.batch_id = al.batch_id) AND (al.arti_id = aa.arti_id) AND (lh.cantidad_padre <> (0)::double precision));


ALTER TABLE alm.movimientos_historicos_vw OWNER TO postgres;

--
-- Name: movimientos_internos; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.movimientos_internos (
    moin_id integer NOT NULL,
    estado character varying NOT NULL,
    num_comprobante character varying,
    fec_envio date NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    patente character varying,
    acoplado character varying,
    conductor character varying,
    fec_recepcion date,
    observaciones_recepcion character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    depo_id_origen integer NOT NULL,
    depo_id_destino integer NOT NULL,
    empr_id integer NOT NULL
);


ALTER TABLE alm.movimientos_internos OWNER TO postgres;

--
-- Name: movimientos_internos_moin_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.movimientos_internos_moin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.movimientos_internos_moin_id_seq OWNER TO postgres;

--
-- Name: movimientos_internos_moin_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.movimientos_internos_moin_id_seq OWNED BY alm.movimientos_internos.moin_id;


--
-- Name: origen_pedido_materiales; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.origen_pedido_materiales (
    tipo character varying NOT NULL,
    orig_id integer NOT NULL,
    pema_id integer NOT NULL
);


ALTER TABLE alm.origen_pedido_materiales OWNER TO postgres;

--
-- Name: utl_tablas; Type: TABLE; Schema: alm; Owner: postgres
--

CREATE TABLE alm.utl_tablas (
    tabl_id integer NOT NULL,
    tabla character varying(50),
    valor character varying(50),
    descripcion character varying(200),
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE alm.utl_tablas OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE; Schema: alm; Owner: postgres
--

CREATE SEQUENCE alm.utl_tablas_tabl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE alm.utl_tablas_tabl_id_seq OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE OWNED BY; Schema: alm; Owner: postgres
--

ALTER SEQUENCE alm.utl_tablas_tabl_id_seq OWNED BY alm.utl_tablas.tabl_id;


--
-- Name: calendario; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.calendario (
    cale_id integer NOT NULL,
    nom_calendario character varying(255),
    descripcion character varying(255),
    seleccionado character varying(255),
    eliminado character varying(255),
    fec_alta date,
    usuario character varying(255),
    empr_id integer
);


ALTER TABLE core.calendario OWNER TO postgres;

--
-- Name: calendario_cale_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.calendario_cale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.calendario_cale_id_seq OWNER TO postgres;

--
-- Name: calendario_cale_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.calendario_cale_id_seq OWNED BY core.calendario.cale_id;


--
-- Name: case_empresa; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.case_empresa (
    case_id integer NOT NULL,
    empr_id integer NOT NULL
);


ALTER TABLE core.case_empresa OWNER TO postgres;

--
-- Name: clientes; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.clientes (
    clie_id integer NOT NULL,
    nombre character varying NOT NULL,
    dir_entrega character varying,
    observaciones character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    ticl_id character varying NOT NULL,
    empr_id integer NOT NULL,
    estado character varying DEFAULT 'ACTIVO'::character varying NOT NULL
);


ALTER TABLE core.clientes OWNER TO postgres;

--
-- Name: clientes_clie_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.clientes_clie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.clientes_clie_id_seq OWNER TO postgres;

--
-- Name: clientes_clie_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.clientes_clie_id_seq OWNED BY core.clientes.clie_id;


--
-- Name: componente_equipo; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.componente_equipo (
    comp_id integer NOT NULL,
    equi_id integer NOT NULL,
    codigo character varying,
    empr_id integer NOT NULL,
    sist_id integer,
    usuario_app character varying NOT NULL,
    fec_alta timestamp(0) without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    coeq_id integer NOT NULL
);


ALTER TABLE core.componente_equipo OWNER TO postgres;

--
-- Name: componente_equipo_coeq_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.componente_equipo_coeq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.componente_equipo_coeq_id_seq OWNER TO postgres;

--
-- Name: componente_equipo_coeq_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.componente_equipo_coeq_id_seq OWNED BY core.componente_equipo.coeq_id;


--
-- Name: empresas; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.empresas (
    empr_id integer NOT NULL,
    descripcion character varying,
    cuit character varying,
    direccion character varying,
    telefono character varying,
    email character varying,
    imagepath character varying,
    loca_id integer,
    prov_id integer,
    pais_id integer,
    lat character varying,
    lng character varying,
    celular character varying,
    zona_id integer,
    clie_id integer
);


ALTER TABLE core.empresas OWNER TO postgres;

--
-- Name: empresas_empr_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.empresas_empr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.empresas_empr_id_seq OWNER TO postgres;

--
-- Name: empresas_empr_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.empresas_empr_id_seq OWNED BY core.empresas.empr_id;


--
-- Name: equipos; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.equipos (
    equi_id integer NOT NULL,
    descripcion character varying(255) NOT NULL,
    marca character varying(255) NOT NULL,
    codigo character varying(255) NOT NULL,
    ubicacion character varying(100) NOT NULL,
    estado character varying(2) NOT NULL,
    fecha_ultimalectura timestamp without time zone NOT NULL,
    ultima_lectura double precision NOT NULL,
    tipo_horas character varying(10),
    valor_reposicion double precision,
    fecha_reposicion date,
    valor double precision,
    comprobante character varying(255),
    descrip_tecnica text,
    numero_serie double precision,
    adjunto character varying(255) DEFAULT NULL::character varying,
    meta_disponibilidad integer,
    fecha_ingreso date,
    fecha_baja date,
    fecha_garantia date,
    prov_id double precision,
    empr_id integer,
    sect_id character varying,
    ubic_id double precision,
    grup_id integer,
    crit_id integer,
    unme_id integer,
    area_id integer,
    proc_id integer
);


ALTER TABLE core.equipos OWNER TO postgres;

--
-- Name: equipos_equi_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.equipos_equi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.equipos_equi_id_seq OWNER TO postgres;

--
-- Name: equipos_equi_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.equipos_equi_id_seq OWNED BY core.equipos.equi_id;


--
-- Name: jornada_laboral; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.jornada_laboral (
    jola_id integer NOT NULL,
    tip_jornada character varying(255),
    nom_jornada character varying(255),
    duracion_jornada character varying(255),
    hora_inicio_jornada character varying(255),
    hora_fin_jornada character varying(255),
    empr_id integer
);


ALTER TABLE core.jornada_laboral OWNER TO postgres;

--
-- Name: jornada_laboral_jola_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.jornada_laboral_jola_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.jornada_laboral_jola_id_seq OWNER TO postgres;

--
-- Name: jornada_laboral_jola_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.jornada_laboral_jola_id_seq OWNED BY core.jornada_laboral.jola_id;


--
-- Name: no_laborables; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.no_laborables (
    nola_id integer NOT NULL,
    fec_dia date,
    descripcion character varying(255),
    tip_calendario character varying(255),
    eliminado character varying(255),
    cale_id integer,
    empr_id integer
);


ALTER TABLE core.no_laborables OWNER TO postgres;

--
-- Name: no_laborables_nola_id_seq; Type: SEQUENCE; Schema: core; Owner: postgres
--

CREATE SEQUENCE core.no_laborables_nola_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core.no_laborables_nola_id_seq OWNER TO postgres;

--
-- Name: no_laborables_nola_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: postgres
--

ALTER SEQUENCE core.no_laborables_nola_id_seq OWNED BY core.no_laborables.nola_id;


--
-- Name: snapshots; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.snapshots (
    snap_id character varying NOT NULL,
    data text,
    fec_alta date DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE core.snapshots OWNER TO postgres;

--
-- Name: tablas; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.tablas (
    tabl_id character varying NOT NULL,
    tabla character varying NOT NULL,
    valor character varying NOT NULL,
    valor2 character varying,
    valor3 character varying,
    descripcion character varying NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    empr_id integer
);


ALTER TABLE core.tablas OWNER TO postgres;

--
-- Name: transportistas; Type: TABLE; Schema: core; Owner: postgres
--

CREATE TABLE core.transportistas (
    cuit character varying NOT NULL,
    razon_social character varying NOT NULL,
    direccion character varying(500) NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    empr_id integer NOT NULL
);


ALTER TABLE core.transportistas OWNER TO postgres;

--
-- Name: formularios; Type: TABLE; Schema: frm; Owner: postgres
--

CREATE TABLE frm.formularios (
    form_id integer NOT NULL,
    nombre character varying(45),
    descripcion character varying(300),
    eliminado smallint DEFAULT 0,
    fec_alta timestamp without time zone DEFAULT now(),
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    empr_id integer
);


ALTER TABLE frm.formularios OWNER TO postgres;

--
-- Name: formularios_form_id_seq; Type: SEQUENCE; Schema: frm; Owner: postgres
--

CREATE SEQUENCE frm.formularios_form_id_seq
    AS integer
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE frm.formularios_form_id_seq OWNER TO postgres;

--
-- Name: formularios_form_id_seq; Type: SEQUENCE OWNED BY; Schema: frm; Owner: postgres
--

ALTER SEQUENCE frm.formularios_form_id_seq OWNED BY frm.formularios.form_id;


--
-- Name: instancias_formularios_info_id_batch_seq; Type: SEQUENCE; Schema: frm; Owner: postgres
--

CREATE SEQUENCE frm.instancias_formularios_info_id_batch_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE frm.instancias_formularios_info_id_batch_seq OWNER TO postgres;

--
-- Name: instancias_formularios; Type: TABLE; Schema: frm; Owner: postgres
--

CREATE TABLE frm.instancias_formularios (
    inst_id integer NOT NULL,
    label character varying,
    name character varying,
    valor character varying,
    tipo_dato character varying(50),
    requerido boolean DEFAULT false,
    valo_id character varying(50),
    info_id integer DEFAULT currval('frm.instancias_formularios_info_id_batch_seq'::regclass),
    form_id integer,
    orden integer,
    variable character varying(100),
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    eliminado boolean DEFAULT false,
    valor4_base64 bytea,
    columna character varying(50),
    multiple boolean DEFAULT false
);


ALTER TABLE frm.instancias_formularios OWNER TO postgres;

--
-- Name: COLUMN instancias_formularios.valor4_base64; Type: COMMENT; Schema: frm; Owner: postgres
--

COMMENT ON COLUMN frm.instancias_formularios.valor4_base64 IS 'Codificacion en BASE64 de los archivos';


--
-- Name: instancias_formularios_inst_id_seq; Type: SEQUENCE; Schema: frm; Owner: postgres
--

CREATE SEQUENCE frm.instancias_formularios_inst_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE frm.instancias_formularios_inst_id_seq OWNER TO postgres;

--
-- Name: instancias_formularios_inst_id_seq; Type: SEQUENCE OWNED BY; Schema: frm; Owner: postgres
--

ALTER SEQUENCE frm.instancias_formularios_inst_id_seq OWNED BY frm.instancias_formularios.inst_id;


--
-- Name: items; Type: TABLE; Schema: frm; Owner: postgres
--

CREATE TABLE frm.items (
    item_id integer NOT NULL,
    label character varying,
    name character varying,
    tipo_dato character varying,
    valo_id character varying,
    orden integer,
    variable character varying(100),
    form_id integer,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    requerido boolean DEFAULT false,
    valor character varying(500),
    columna character varying(50),
    multiple boolean DEFAULT false
);


ALTER TABLE frm.items OWNER TO postgres;

--
-- Name: COLUMN items.columna; Type: COMMENT; Schema: frm; Owner: postgres
--

COMMENT ON COLUMN frm.items.columna IS 'Clase de Bootstrap para el tamaño';


--
-- Name: COLUMN items.multiple; Type: COMMENT; Schema: frm; Owner: postgres
--

COMMENT ON COLUMN frm.items.multiple IS 'Si se van agregar dinamicamente en el formulario';


--
-- Name: items_item_id_seq; Type: SEQUENCE; Schema: frm; Owner: postgres
--

CREATE SEQUENCE frm.items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE frm.items_item_id_seq OWNER TO postgres;

--
-- Name: items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: frm; Owner: postgres
--

ALTER SEQUENCE frm.items_item_id_seq OWNED BY frm.items.item_id;


--
-- Name: utl_tablas; Type: TABLE; Schema: frm; Owner: postgres
--

CREATE TABLE frm.utl_tablas (
    tabl_id integer NOT NULL,
    tabla character varying(50) DEFAULT NULL::character varying,
    valor character varying(50) DEFAULT NULL::character varying,
    descripcion character varying(200) DEFAULT NULL::character varying,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE frm.utl_tablas OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE; Schema: frm; Owner: postgres
--

CREATE SEQUENCE frm.utl_tablas_tabl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE frm.utl_tablas_tabl_id_seq OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE OWNED BY; Schema: frm; Owner: postgres
--

ALTER SEQUENCE frm.utl_tablas_tabl_id_seq OWNED BY frm.utl_tablas.tabl_id;


--
-- Name: movimientos_no_consumibles; Type: TABLE; Schema: nco; Owner: postgres
--

CREATE TABLE nco.movimientos_no_consumibles (
    monc_id integer NOT NULL,
    estado character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    noco_id character varying NOT NULL,
    depo_id integer,
    dest_id character varying,
    empr_id integer NOT NULL,
    CONSTRAINT movimientos_no_consumibles_check CHECK ((((estado)::text = 'ALTA'::text) OR ((estado)::text = 'ACTIVO'::text) OR ((estado)::text = 'VENCIDO'::text) OR ((estado)::text = 'EN_TRANSITO'::text) OR ((estado)::text = 'EN_REPARACION'::text) OR ((estado)::text = 'INHABILITADO'::text)))
);


ALTER TABLE nco.movimientos_no_consumibles OWNER TO postgres;

--
-- Name: movimientos_no_consumibles_monc_id_seq; Type: SEQUENCE; Schema: nco; Owner: postgres
--

CREATE SEQUENCE nco.movimientos_no_consumibles_monc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE nco.movimientos_no_consumibles_monc_id_seq OWNER TO postgres;

--
-- Name: movimientos_no_consumibles_monc_id_seq; Type: SEQUENCE OWNED BY; Schema: nco; Owner: postgres
--

ALTER SEQUENCE nco.movimientos_no_consumibles_monc_id_seq OWNED BY nco.movimientos_no_consumibles.monc_id;


--
-- Name: no_consumibles; Type: TABLE; Schema: nco; Owner: postgres
--

CREATE TABLE nco.no_consumibles (
    codigo character varying NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying DEFAULT 'ALTA'::character varying NOT NULL,
    fec_vencimiento date,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    tinc_id character varying NOT NULL,
    empr_id integer NOT NULL,
    eliminado boolean DEFAULT false,
    CONSTRAINT no_consumibles_check CHECK ((((estado)::text = 'ALTA'::text) OR ((estado)::text = 'ACTIVO'::text) OR ((estado)::text = 'VENCIDO'::text) OR ((estado)::text = 'EN_TRANSITO'::text) OR ((estado)::text = 'EN_REPARACION'::text) OR ((estado)::text = 'INHABILITADO'::text)))
);


ALTER TABLE nco.no_consumibles OWNER TO postgres;

--
-- Name: no_consumibles_lotes; Type: TABLE; Schema: nco; Owner: postgres
--

CREATE TABLE nco.no_consumibles_lotes (
    noco_id character varying NOT NULL,
    batch_id bigint NOT NULL,
    fec_liberacion timestamp without time zone,
    fec_alta character varying DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    empr_id integer NOT NULL
);


ALTER TABLE nco.no_consumibles_lotes OWNER TO postgres;

--
-- Name: deta_entrada_panol; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.deta_entrada_panol (
    enpa_id integer NOT NULL,
    herr_id integer NOT NULL
);


ALTER TABLE pan.deta_entrada_panol OWNER TO postgres;

--
-- Name: deta_salida_panol; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.deta_salida_panol (
    sapa_id integer NOT NULL,
    herr_id integer NOT NULL
);


ALTER TABLE pan.deta_salida_panol OWNER TO postgres;

--
-- Name: entrada_panol; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.entrada_panol (
    enpa_id integer NOT NULL,
    usuario_app character varying NOT NULL,
    destino character varying NOT NULL,
    empr_id integer NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    pano_id integer NOT NULL,
    observaciones character varying,
    eliminado boolean DEFAULT false NOT NULL,
    comprobante character varying NOT NULL,
    responsable character varying NOT NULL
);


ALTER TABLE pan.entrada_panol OWNER TO postgres;

--
-- Name: entrada_panol_enpa_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.entrada_panol_enpa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.entrada_panol_enpa_id_seq OWNER TO postgres;

--
-- Name: entrada_panol_enpa_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.entrada_panol_enpa_id_seq OWNED BY pan.entrada_panol.enpa_id;


--
-- Name: estanteria; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.estanteria (
    estan_id integer NOT NULL,
    descripcion character varying,
    codigo character varying NOT NULL,
    filas integer NOT NULL,
    fec_alta timestamp(0) without time zone DEFAULT now() NOT NULL,
    usuario_app character varying NOT NULL,
    usuario character varying DEFAULT CURRENT_USER,
    empr_id integer NOT NULL,
    pano_id integer NOT NULL
);


ALTER TABLE pan.estanteria OWNER TO postgres;

--
-- Name: estanteria_estan_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.estanteria_estan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.estanteria_estan_id_seq OWNER TO postgres;

--
-- Name: estanteria_estan_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.estanteria_estan_id_seq OWNED BY pan.estanteria.estan_id;


--
-- Name: herramientas; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.herramientas (
    herr_id integer NOT NULL,
    codigo character varying NOT NULL,
    marca character varying NOT NULL,
    modelo character varying,
    tipo character varying,
    descripcion character varying,
    pano_id integer NOT NULL,
    usuario_app character varying NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    empr_id integer NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    estado character varying DEFAULT 'ACTIVO'::character varying
);


ALTER TABLE pan.herramientas OWNER TO postgres;

--
-- Name: herramientas_herr_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.herramientas_herr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.herramientas_herr_id_seq OWNER TO postgres;

--
-- Name: herramientas_herr_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.herramientas_herr_id_seq OWNED BY pan.herramientas.herr_id;


--
-- Name: panol; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.panol (
    pano_id integer NOT NULL,
    descripcion character varying NOT NULL,
    direccion character varying,
    loca_id character varying,
    prov_id character varying,
    pais_id character varying,
    lat character varying,
    lng character varying,
    empr_id integer NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    esta_id integer
);


ALTER TABLE pan.panol OWNER TO postgres;

--
-- Name: panol_pano_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.panol_pano_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.panol_pano_id_seq OWNER TO postgres;

--
-- Name: panol_pano_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.panol_pano_id_seq OWNED BY pan.panol.pano_id;


--
-- Name: salida_panol; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.salida_panol (
    sapa_id integer NOT NULL,
    usuario_app character varying NOT NULL,
    destino character varying NOT NULL,
    empr_id integer NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    pano_id integer NOT NULL,
    observaciones character varying,
    eliminado boolean DEFAULT false NOT NULL,
    comprobante character varying NOT NULL,
    responsable character varying NOT NULL
);


ALTER TABLE pan.salida_panol OWNER TO postgres;

--
-- Name: salida_panol_sapa_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.salida_panol_sapa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.salida_panol_sapa_id_seq OWNER TO postgres;

--
-- Name: salida_panol_sapa_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.salida_panol_sapa_id_seq OWNED BY pan.salida_panol.sapa_id;


--
-- Name: trazacomponente; Type: TABLE; Schema: pan; Owner: postgres
--

CREATE TABLE pan.trazacomponente (
    traz_id integer NOT NULL,
    coeq_id integer NOT NULL,
    estan_id integer,
    fila integer,
    fecha timestamp(0) without time zone DEFAULT now(),
    fecha_entrega timestamp(0) without time zone,
    ultimo_recibe character varying NOT NULL,
    ultimo_entrega character varying NOT NULL,
    estado character varying NOT NULL,
    observaciones character varying,
    usuario_app character varying NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    empr_id integer NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    pano_id integer NOT NULL
);


ALTER TABLE pan.trazacomponente OWNER TO postgres;

--
-- Name: trazacomponente_traz_id_seq; Type: SEQUENCE; Schema: pan; Owner: postgres
--

CREATE SEQUENCE pan.trazacomponente_traz_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pan.trazacomponente_traz_id_seq OWNER TO postgres;

--
-- Name: trazacomponente_traz_id_seq; Type: SEQUENCE OWNED BY; Schema: pan; Owner: postgres
--

ALTER SEQUENCE pan.trazacomponente_traz_id_seq OWNED BY pan.trazacomponente.traz_id;


--
-- Name: costos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.costos (
    fec_vigencia date NOT NULL,
    valor money NOT NULL,
    umed character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    recu_id integer NOT NULL,
    empr_id integer
);


ALTER TABLE prd.costos OWNER TO postgres;

--
-- Name: empaque; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.empaque (
    empa_id integer NOT NULL,
    nombre character varying NOT NULL,
    unidad_medida character varying NOT NULL,
    capacidad double precision NOT NULL,
    empr_id integer NOT NULL,
    usuario_app character varying NOT NULL,
    eliminado boolean NOT NULL,
    fech_alta date DEFAULT now() NOT NULL,
    tara double precision,
    arti_id integer
);


ALTER TABLE prd.empaque OWNER TO postgres;

--
-- Name: COLUMN empaque.eliminado; Type: COMMENT; Schema: prd; Owner: postgres
--

COMMENT ON COLUMN prd.empaque.eliminado IS 'false';


--
-- Name: empaque_empa_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.empaque_empa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.empaque_empa_id_seq OWNER TO postgres;

--
-- Name: empaque_empa_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.empaque_empa_id_seq OWNED BY prd.empaque.empa_id;


--
-- Name: establecimientos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.establecimientos (
    esta_id integer NOT NULL,
    nombre character varying NOT NULL,
    lng character varying,
    lat character varying,
    calle character varying,
    altura character varying,
    localidad character varying,
    estado character varying DEFAULT 'AC'::character varying,
    pais character varying,
    fec_alta date DEFAULT now(),
    usuario character varying,
    empr_id integer,
    eliminado boolean DEFAULT false
);


ALTER TABLE prd.establecimientos OWNER TO postgres;

--
-- Name: establecimientos_esta_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.establecimientos_esta_id_seq
    AS integer
    START WITH 13
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.establecimientos_esta_id_seq OWNER TO postgres;

--
-- Name: establecimientos_esta_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.establecimientos_esta_id_seq OWNED BY prd.establecimientos.esta_id;


--
-- Name: etapas; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.etapas (
    etap_id integer NOT NULL,
    nombre character varying NOT NULL,
    nom_recipiente character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    proc_id integer NOT NULL,
    eliminado smallint DEFAULT 0 NOT NULL,
    empr_id integer,
    link character varying(100),
    orden integer NOT NULL,
    form_id integer,
    tiet_id character varying DEFAULT 'prd_tipos_etapaSimple'::character varying NOT NULL
);


ALTER TABLE prd.etapas OWNER TO postgres;

--
-- Name: etapas_materiales; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.etapas_materiales (
    etap_id integer NOT NULL,
    arti_id integer NOT NULL
);


ALTER TABLE prd.etapas_materiales OWNER TO postgres;

--
-- Name: etapas_productos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.etapas_productos (
    etap_id integer NOT NULL,
    arti_id integer NOT NULL
);


ALTER TABLE prd.etapas_productos OWNER TO postgres;

--
-- Name: etapas_salidas; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.etapas_salidas (
    etap_id integer NOT NULL,
    arti_id integer NOT NULL
);


ALTER TABLE prd.etapas_salidas OWNER TO postgres;

--
-- Name: etapas_articulos_vw; Type: VIEW; Schema: prd; Owner: postgres
--

CREATE VIEW prd.etapas_articulos_vw AS
 SELECT em.etap_id,
    em.arti_id,
    aa.barcode,
    'ENT'::text,
    e2.nombre,
    e2.orden,
    e2.empr_id
   FROM prd.etapas_materiales em,
    alm.alm_articulos aa,
    prd.etapas e2
  WHERE ((em.etap_id = e2.etap_id) AND (aa.arti_id = em.arti_id))
UNION ALL
 SELECT ep.etap_id,
    ep.arti_id,
    aa.barcode,
    'PRO'::text,
    e2.nombre,
    e2.orden,
    e2.empr_id
   FROM prd.etapas_productos ep,
    alm.alm_articulos aa,
    prd.etapas e2
  WHERE ((ep.etap_id = e2.etap_id) AND (aa.arti_id = ep.arti_id))
UNION ALL
 SELECT es.etap_id,
    es.arti_id,
    aa.barcode,
    'SAL'::text,
    e2.nombre,
    e2.orden,
    e2.empr_id
   FROM prd.etapas_salidas es,
    alm.alm_articulos aa,
    prd.etapas e2
  WHERE ((es.etap_id = e2.etap_id) AND (aa.arti_id = es.arti_id))
  ORDER BY 6;


ALTER TABLE prd.etapas_articulos_vw OWNER TO postgres;

--
-- Name: etapas_etap_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.etapas_etap_id_seq
    AS integer
    START WITH 35
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.etapas_etap_id_seq OWNER TO postgres;

--
-- Name: etapas_etap_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.etapas_etap_id_seq OWNED BY prd.etapas.etap_id;


--
-- Name: formulas; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.formulas (
    form_id integer NOT NULL,
    descripcion character varying NOT NULL,
    cantidad double precision NOT NULL,
    eliminado boolean DEFAULT false,
    aplicacion character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    unme_id character varying NOT NULL,
    empr_id integer NOT NULL
);


ALTER TABLE prd.formulas OWNER TO postgres;

--
-- Name: formulas_articulos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.formulas_articulos (
    cantidad double precision NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    unme_id character varying,
    form_id integer NOT NULL,
    arti_id integer NOT NULL
);


ALTER TABLE prd.formulas_articulos OWNER TO postgres;

--
-- Name: formulas_form_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.formulas_form_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.formulas_form_id_seq OWNER TO postgres;

--
-- Name: formulas_form_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.formulas_form_id_seq OWNED BY prd.formulas.form_id;


--
-- Name: lotes_audit_log; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.lotes_audit_log (
    batch_id bigint NOT NULL,
    mensaje character varying NOT NULL,
    paso character varying NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL
);


ALTER TABLE prd.lotes_audit_log OWNER TO postgres;

--
-- Name: lotes_batch_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.lotes_batch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.lotes_batch_id_seq OWNER TO postgres;

--
-- Name: lotes_batch_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.lotes_batch_id_seq OWNED BY prd.lotes.batch_id;


--
-- Name: lotes_responsables; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.lotes_responsables (
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    batch_id integer NOT NULL,
    user_id integer,
    turn_id character varying NOT NULL
);


ALTER TABLE prd.lotes_responsables OWNER TO postgres;

--
-- Name: lotes_tareas_planificadas; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.lotes_tareas_planificadas (
    tapl_id bigint NOT NULL,
    batch_id bigint NOT NULL
);


ALTER TABLE prd.lotes_tareas_planificadas OWNER TO postgres;

--
-- Name: movimientos_trasportes; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.movimientos_trasportes (
    motr_id bigint NOT NULL,
    boleta character varying,
    fecha_entrada date,
    patente character varying,
    acoplado character varying,
    conductor character varying,
    tipo character varying,
    bruto double precision,
    tara double precision,
    neto double precision,
    prov_id integer,
    esta_id integer,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    estado character varying DEFAULT 'INICIADO'::character varying,
    reci_id integer,
    transportista character varying,
    cuit character varying,
    accion character varying,
    clie_id integer,
    empr_id integer
);


ALTER TABLE prd.movimientos_trasportes OWNER TO postgres;

--
-- Name: movimientos_trasportes_motr_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.movimientos_trasportes_motr_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.movimientos_trasportes_motr_id_seq OWNER TO postgres;

--
-- Name: movimientos_trasportes_motr_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.movimientos_trasportes_motr_id_seq OWNED BY prd.movimientos_trasportes.motr_id;


--
-- Name: procesos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.procesos (
    proc_id integer NOT NULL,
    nombre character varying NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    empr_id integer
);


ALTER TABLE prd.procesos OWNER TO postgres;

--
-- Name: recursos; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.recursos (
    recu_id integer NOT NULL,
    tipo character varying NOT NULL,
    cant_capacidad double precision,
    umed_capacidad character varying,
    cant_tiempo_capacidad character varying,
    umed_iempo_capacidad character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    arti_id integer,
    empr_id integer,
    equi_id integer,
    CONSTRAINT recursos_check CHECK (((tipo)::text = ANY (ARRAY[('MATERIAL'::character varying)::text, ('TRABAJO'::character varying)::text])))
);


ALTER TABLE prd.recursos OWNER TO postgres;

--
-- Name: recursos_lotes; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.recursos_lotes (
    batch_id integer NOT NULL,
    recu_id integer NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    empr_id integer,
    cantidad double precision NOT NULL,
    tipo character varying NOT NULL,
    empa_id integer,
    empa_cantidad double precision,
    CONSTRAINT recursos_lotes_check CHECK ((((tipo)::text = 'MATERIA_PRIMA'::text) OR ((tipo)::text = 'PRODUCTO'::text) OR ((tipo)::text = 'EQUIPO'::text) OR ((tipo)::text = 'HUMANO'::text) OR ((tipo)::text = 'CONSUMO'::text)))
);


ALTER TABLE prd.recursos_lotes OWNER TO postgres;

--
-- Name: productos_lotes_vw; Type: VIEW; Schema: prd; Owner: postgres
--

CREATE VIEW prd.productos_lotes_vw AS
 SELECT r.arti_id,
    aa.barcode,
    rl.cantidad,
    rl.batch_id
   FROM prd.recursos_lotes rl,
    prd.recursos r,
    alm.alm_articulos aa
  WHERE ((r.recu_id = rl.recu_id) AND (r.arti_id = aa.arti_id) AND ((rl.tipo)::text = 'PRODUCTO'::text));


ALTER TABLE prd.productos_lotes_vw OWNER TO postgres;

--
-- Name: productos_prod_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.productos_prod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.productos_prod_id_seq OWNER TO postgres;

--
-- Name: productos_prod_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.productos_prod_id_seq OWNED BY prd.procesos.proc_id;


--
-- Name: recipientes; Type: TABLE; Schema: prd; Owner: postgres
--

CREATE TABLE prd.recipientes (
    reci_id integer NOT NULL,
    tipo character varying DEFAULT 0 NOT NULL,
    estado character varying DEFAULT 'VACIO'::character varying NOT NULL,
    nombre character varying NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    eliminado smallint DEFAULT 0 NOT NULL,
    empr_id integer,
    depo_id integer NOT NULL,
    motr_id integer,
    care_id character varying DEFAULT 'cate_recipienteBOX'::character varying NOT NULL,
    CONSTRAINT recipientes_check CHECK ((((tipo)::text = 'PRODUCTIVO'::text) OR ((tipo)::text = 'DEPOSITO'::text) OR ((tipo)::text = 'TRANSPORTE'::text))),
    CONSTRAINT recipientes_check_estado CHECK ((((estado)::text = 'VACIO'::text) OR ((estado)::text = 'LLENO'::text)))
);


ALTER TABLE prd.recipientes OWNER TO postgres;

--
-- Name: recipiente_reci_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.recipiente_reci_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.recipiente_reci_id_seq OWNER TO postgres;

--
-- Name: recipiente_reci_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.recipiente_reci_id_seq OWNED BY prd.recipientes.reci_id;


--
-- Name: recursos_recu_id_seq; Type: SEQUENCE; Schema: prd; Owner: postgres
--

CREATE SEQUENCE prd.recursos_recu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE prd.recursos_recu_id_seq OWNER TO postgres;

--
-- Name: recursos_recu_id_seq; Type: SEQUENCE OWNED BY; Schema: prd; Owner: postgres
--

ALTER SEQUENCE prd.recursos_recu_id_seq OWNED BY prd.recursos.recu_id;


--
-- Name: pedidos_trabajo; Type: TABLE; Schema: pro; Owner: postgres
--

CREATE TABLE pro.pedidos_trabajo (
    petr_id integer NOT NULL,
    cod_proyecto character varying NOT NULL,
    descripcion character varying NOT NULL,
    estado character varying,
    objetivo character varying DEFAULT 0,
    eliminado boolean DEFAULT false NOT NULL,
    fec_inicio timestamp without time zone NOT NULL,
    fec_entrega timestamp without time zone,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    umti_id character varying,
    info_id integer,
    proc_id character varying NOT NULL,
    empr_id integer,
    clie_id integer,
    case_id character varying,
    case_id_final character varying,
    tipt_id character varying NOT NULL
);


ALTER TABLE pro.pedidos_trabajo OWNER TO postgres;

--
-- Name: pedidos_trabajo_forms; Type: TABLE; Schema: pro; Owner: postgres
--

CREATE TABLE pro.pedidos_trabajo_forms (
    nom_tarea character varying NOT NULL,
    task_id character varying NOT NULL,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    petr_id integer NOT NULL,
    info_id integer NOT NULL
);


ALTER TABLE pro.pedidos_trabajo_forms OWNER TO postgres;

--
-- Name: pedidos_trabajo_petr_id_seq; Type: SEQUENCE; Schema: pro; Owner: postgres
--

CREATE SEQUENCE pro.pedidos_trabajo_petr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pro.pedidos_trabajo_petr_id_seq OWNER TO postgres;

--
-- Name: pedidos_trabajo_petr_id_seq; Type: SEQUENCE OWNED BY; Schema: pro; Owner: postgres
--

ALTER SEQUENCE pro.pedidos_trabajo_petr_id_seq OWNED BY pro.pedidos_trabajo.petr_id;


--
-- Name: procesos; Type: TABLE; Schema: pro; Owner: postgres
--

CREATE TABLE pro.procesos (
    proc_id character varying NOT NULL,
    nombre character varying NOT NULL,
    descripcion character varying NOT NULL,
    lanzar_bpm boolean NOT NULL,
    planificar_tareas boolean NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    nombre_bpm character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    esin_id character varying NOT NULL,
    empr_id integer,
    form_id integer
);


ALTER TABLE pro.procesos OWNER TO postgres;

--
-- Name: utl_tablas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utl_tablas (
    tabl_id integer NOT NULL,
    tabla character varying(50) DEFAULT NULL::character varying,
    valor character varying(50) DEFAULT NULL::character varying,
    descripcion character varying(200) DEFAULT NULL::character varying,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE public.utl_tablas OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utl_tablas_tabl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.utl_tablas_tabl_id_seq OWNER TO postgres;

--
-- Name: utl_tablas_tabl_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utl_tablas_tabl_id_seq OWNED BY public.utl_tablas.tabl_id;


--
-- Name: memberships_menues; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.memberships_menues (
    modulo character varying NOT NULL,
    opcion character varying NOT NULL,
    "group" character varying,
    role character varying,
    fec_alta date DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL
);


ALTER TABLE seg.memberships_menues OWNER TO postgres;

--
-- Name: memberships_users; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.memberships_users (
    "group" character varying NOT NULL,
    role character varying NOT NULL,
    fec_alta character varying DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    email character varying NOT NULL
);


ALTER TABLE seg.memberships_users OWNER TO postgres;

--
-- Name: menues; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.menues (
    modulo character varying(4) NOT NULL,
    opcion character varying NOT NULL,
    texto character varying NOT NULL,
    url character varying,
    javascript character varying,
    orden integer DEFAULT 0,
    url_icono character varying,
    texto_onmouseover character varying,
    eliminado smallint DEFAULT 0,
    fec_alta character varying DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    opcion_padre character varying,
    CONSTRAINT menues_check CHECK ((((modulo)::text = 'PRD'::text) OR ((modulo)::text = 'CORE'::text) OR ((modulo)::text = 'ALM'::text) OR ((modulo)::text = 'MAN'::text) OR ((modulo)::text = 'TAR'::text) OR ((modulo)::text = 'PAN'::text) OR ((modulo)::text = 'LOG'::text) OR ((modulo)::text = 'SEG'::text) OR ((modulo)::text = 'TRZ'::text) OR ((modulo)::text = 'PRO'::text) OR ((modulo)::text = 'FIS'::text) OR ((modulo)::text = 'BPM'::text)))
);


ALTER TABLE seg.menues OWNER TO postgres;

--
-- Name: menues_users_vw; Type: VIEW; Schema: seg; Owner: postgres
--

CREATE VIEW seg.menues_users_vw AS
 SELECT mm.modulo,
    mm.opcion,
    mm."group",
    mm.role,
    mu.email
   FROM seg.memberships_menues mm,
    seg.memberships_users mu
  WHERE (((mm."group")::text = (mu."group")::text) AND ((mm.role)::text = (mu.role)::text))
UNION
 SELECT mm.modulo,
    mm.opcion,
    mm."group",
    'TODOS'::character varying AS role,
    mu.email
   FROM seg.memberships_menues mm,
    seg.memberships_users mu
  WHERE (((mm."group")::text = (mu."group")::text) AND ((mm.role IS NULL) OR ((mm.role)::text = ''::text)))
UNION
 SELECT mm.modulo,
    mm.opcion,
    'TODOS'::character varying AS "group",
    'TODOS'::character varying AS role,
    'TODOS'::character varying AS email
   FROM seg.memberships_menues mm,
    seg.memberships_users mu
  WHERE (((mm."group" IS NULL) OR ((mm."group")::text = ''::text)) AND ((mm.role IS NULL) OR ((mm.role)::text = ''::text)))
  ORDER BY 1, 2;


ALTER TABLE seg.menues_users_vw OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.roles (
    rol_id integer NOT NULL,
    nombre character varying,
    descripcion character varying,
    fec_alta date,
    eliminado smallint DEFAULT 0 NOT NULL
);


ALTER TABLE seg.roles OWNER TO postgres;

--
-- Name: settings; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.settings (
    id integer NOT NULL,
    site_title character varying(50) NOT NULL,
    timezone character varying(100) NOT NULL,
    recaptcha character varying(5) NOT NULL,
    theme character varying(100) NOT NULL
);


ALTER TABLE seg.settings OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: seg; Owner: postgres
--

CREATE SEQUENCE seg.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seg.settings_id_seq OWNER TO postgres;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: seg; Owner: postgres
--

ALTER SEQUENCE seg.settings_id_seq OWNED BY seg.settings.id;


--
-- Name: tokens; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.tokens (
    id integer NOT NULL,
    token character varying(255) NOT NULL,
    user_id bigint NOT NULL,
    created date NOT NULL
);


ALTER TABLE seg.tokens OWNER TO postgres;

--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: seg; Owner: postgres
--

CREATE SEQUENCE seg.tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seg.tokens_id_seq OWNER TO postgres;

--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: seg; Owner: postgres
--

ALTER SEQUENCE seg.tokens_id_seq OWNED BY seg.tokens.id;


--
-- Name: users; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.users (
    id integer NOT NULL,
    email character varying(100),
    first_name character varying(100),
    last_name character varying(100),
    role character varying(10),
    password text,
    last_login character varying(100),
    status character varying(100),
    banned_users character varying(100),
    passmd5 text,
    telefono character varying,
    dni character varying,
    usernick character varying,
    depo_id integer,
    image bytea,
    image_name character varying(100)
);


ALTER TABLE seg.users OWNER TO postgres;

--
-- Name: COLUMN users.image; Type: COMMENT; Schema: seg; Owner: postgres
--

COMMENT ON COLUMN seg.users.image IS 'Imagen codificada base64';


--
-- Name: COLUMN users.image_name; Type: COMMENT; Schema: seg; Owner: postgres
--

COMMENT ON COLUMN seg.users.image_name IS 'Nombre de la imagen para extraer la extension
';


--
-- Name: users_business; Type: TABLE; Schema: seg; Owner: postgres
--

CREATE TABLE seg.users_business (
    busines character varying(50) NOT NULL,
    email character varying(50) NOT NULL
);


ALTER TABLE seg.users_business OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: seg; Owner: postgres
--

CREATE SEQUENCE seg.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE seg.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: seg; Owner: postgres
--

ALTER SEQUENCE seg.users_id_seq OWNED BY seg.users.id;


--
-- Name: choferes; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.choferes (
    dni character varying NOT NULL,
    nombre character varying,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL
);


ALTER TABLE sicpoa.choferes OWNER TO postgres;

--
-- Name: depositos; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.depositos (
    depo_id integer NOT NULL,
    calle character varying NOT NULL,
    altura character varying,
    depa_id character varying NOT NULL,
    empr_id character varying NOT NULL
);


ALTER TABLE sicpoa.depositos OWNER TO postgres;

--
-- Name: depositos_depo_id_seq; Type: SEQUENCE; Schema: sicpoa; Owner: postgres
--

CREATE SEQUENCE sicpoa.depositos_depo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sicpoa.depositos_depo_id_seq OWNER TO postgres;

--
-- Name: depositos_depo_id_seq; Type: SEQUENCE OWNED BY; Schema: sicpoa; Owner: postgres
--

ALTER SEQUENCE sicpoa.depositos_depo_id_seq OWNED BY sicpoa.depositos.depo_id;


--
-- Name: deta_infracciones; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.deta_infracciones (
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    case_id bigint NOT NULL,
    tiin_id character varying NOT NULL
);


ALTER TABLE sicpoa.deta_infracciones OWNER TO postgres;

--
-- Name: COLUMN deta_infracciones.tiin_id; Type: COMMENT; Schema: sicpoa; Owner: postgres
--

COMMENT ON COLUMN sicpoa.deta_infracciones.tiin_id IS 'infracciones en core.tablas';


--
-- Name: detalles_documento; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.detalles_documento (
    dedo_id integer NOT NULL,
    cantidad real NOT NULL,
    precio_unitario real,
    descuento real,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER,
    usuario_app character varying NOT NULL,
    docu_id character varying NOT NULL,
    tido_id character varying NOT NULL,
    tipr_id character varying NOT NULL,
    unme_id character varying NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    unidades integer
);


ALTER TABLE sicpoa.detalles_documento OWNER TO postgres;

--
-- Name: COLUMN detalles_documento.tipr_id; Type: COMMENT; Schema: sicpoa; Owner: postgres
--

COMMENT ON COLUMN sicpoa.detalles_documento.tipr_id IS 'tipo de producto en core.tablas';


--
-- Name: detalles_documento_dedo_id_seq; Type: SEQUENCE; Schema: sicpoa; Owner: postgres
--

CREATE SEQUENCE sicpoa.detalles_documento_dedo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sicpoa.detalles_documento_dedo_id_seq OWNER TO postgres;

--
-- Name: detalles_documento_dedo_id_seq; Type: SEQUENCE OWNED BY; Schema: sicpoa; Owner: postgres
--

ALTER SEQUENCE sicpoa.detalles_documento_dedo_id_seq OWNED BY sicpoa.detalles_documento.dedo_id;


--
-- Name: documentos; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.documentos (
    num_documento character varying NOT NULL,
    fec_emision date NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    tido_id character varying NOT NULL,
    imag_id integer,
    empr_id_emisor character varying NOT NULL,
    empr_id_destino character varying NOT NULL,
    case_id bigint NOT NULL,
    eliminado boolean DEFAULT false NOT NULL
);


ALTER TABLE sicpoa.documentos OWNER TO postgres;

--
-- Name: COLUMN documentos.tido_id; Type: COMMENT; Schema: sicpoa; Owner: postgres
--

COMMENT ON COLUMN sicpoa.documentos.tido_id IS 'tipo documento en core.tablas';


--
-- Name: COLUMN documentos.imag_id; Type: COMMENT; Schema: sicpoa; Owner: postgres
--

COMMENT ON COLUMN sicpoa.documentos.imag_id IS 'imagen guardada en frm.instancias_formularios';


--
-- Name: empresas; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.empresas (
    cuit character varying NOT NULL,
    razon_social character varying NOT NULL,
    num_establecimiento character varying,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL
);


ALTER TABLE sicpoa.empresas OWNER TO postgres;

--
-- Name: infracciones; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.infracciones (
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    case_id bigint NOT NULL,
    depositario character varying,
    documento character varying,
    domicilio_legal character varying,
    domicilio_comercial character varying,
    telefono character varying,
    email character varying,
    detalle_infraccion character varying,
    caracteristicas_organolepticas character varying,
    caracteristicas_deposito character varying,
    tipo_camara character varying,
    temperatura_actual real,
    fecha_hora timestamp without time zone
);


ALTER TABLE sicpoa.infracciones OWNER TO postgres;

--
-- Name: inspecciones; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.inspecciones (
    case_id bigint NOT NULL,
    patente_tractor character varying NOT NULL,
    nro_senasa character varying,
    productos character varying NOT NULL,
    reprecintado boolean DEFAULT false,
    bruto real,
    tara real,
    ticket character varying,
    resultado character varying,
    cant_fajas integer,
    bruto_reprecintado real,
    ticket_reprecintado character varying,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    petr_id integer NOT NULL,
    chof_id character varying NOT NULL,
    inca_id integer,
    observaciones character varying,
    info_id_doc integer,
    eliminado boolean DEFAULT false NOT NULL,
    tel_transportista character varying,
    email_transportista character varying,
    se_constituye character varying,
    domicilio_constituye character varying,
    propiedad_de character varying,
    atendidos_por character varying,
    caracter_de character varying,
    proceden_a character varying,
    departamento character varying,
    localidad character varying,
    inspectores character varying
);


ALTER TABLE sicpoa.inspecciones OWNER TO postgres;

--
-- Name: COLUMN inspecciones.inca_id; Type: COMMENT; Schema: sicpoa; Owner: postgres
--

COMMENT ON COLUMN sicpoa.inspecciones.inca_id IS 'acta infraccion en call en frm.instancias formulario';


--
-- Name: inspecciones_empresas; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.inspecciones_empresas (
    rol character varying NOT NULL,
    empr_id character varying NOT NULL,
    case_id bigint NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    depo_id integer,
    eliminado boolean DEFAULT false NOT NULL,
    CONSTRAINT inspecciones_empresas_check CHECK ((((rol)::text = 'ORIGEN'::text) OR ((rol)::text = 'DESTINO'::text) OR ((rol)::text = 'TRANSPORTISTA'::text)))
);


ALTER TABLE sicpoa.inspecciones_empresas OWNER TO postgres;

--
-- Name: inspecciones_termicos; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.inspecciones_termicos (
    temperatura real NOT NULL,
    precintos character varying NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    case_id bigint NOT NULL,
    term_id character varying NOT NULL
);


ALTER TABLE sicpoa.inspecciones_termicos OWNER TO postgres;

--
-- Name: permisos_transito; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.permisos_transito (
    perm_id character varying NOT NULL,
    lugar_emision character varying NOT NULL,
    fecha_hora_salida timestamp without time zone NOT NULL,
    tipo character varying,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL,
    case_id bigint NOT NULL,
    soli_num character varying,
    origen character varying,
    neto character varying,
    bruto character varying,
    temperatura real,
    productos character varying,
    CONSTRAINT permisos_transito_check CHECK ((((tipo)::text = 'PT'::text) OR ((tipo)::text = 'PTR'::text)))
);


ALTER TABLE sicpoa.permisos_transito OWNER TO postgres;

--
-- Name: termicos; Type: TABLE; Schema: sicpoa; Owner: postgres
--

CREATE TABLE sicpoa.termicos (
    patente character varying NOT NULL,
    fec_alta timestamp without time zone DEFAULT now() NOT NULL,
    usuario character varying DEFAULT CURRENT_USER NOT NULL,
    usuario_app character varying NOT NULL
);


ALTER TABLE sicpoa.termicos OWNER TO postgres;

--
-- Name: articulos; Type: TABLE; Schema: sta; Owner: postgres
--

CREATE TABLE sta.articulos (
    id character varying,
    "Etapa" character varying,
    "U. Medida" character varying,
    "Código" character varying,
    "Descripción" character varying,
    procesado boolean DEFAULT false,
    fec_proceso date
);


ALTER TABLE sta.articulos OWNER TO postgres;

--
-- Name: articulos_etapas; Type: TABLE; Schema: sta; Owner: postgres
--

CREATE TABLE sta.articulos_etapas (
    "Etapa" character varying,
    "Entrada" character varying,
    "Producto" character varying,
    "Salida" character varying,
    procesado boolean DEFAULT false,
    fec_proceso date
);


ALTER TABLE sta.articulos_etapas OWNER TO postgres;

--
-- Name: hitos; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.hitos (
    numero character varying NOT NULL,
    descripcion character varying,
    fec_inicio timestamp without time zone,
    user_id character varying,
    objetivo integer,
    unidad_tiempo character varying,
    esta_id integer,
    documento bytea,
    petr_id integer NOT NULL,
    eliminado boolean DEFAULT false NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    hito_id integer NOT NULL,
    nombre_documento character varying(255)
);


ALTER TABLE tst.hitos OWNER TO postgres;

--
-- Name: hitos_hito_id_seq; Type: SEQUENCE; Schema: tst; Owner: postgres
--

CREATE SEQUENCE tst.hitos_hito_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.hitos_hito_id_seq OWNER TO postgres;

--
-- Name: hitos_hito_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: postgres
--

ALTER SEQUENCE tst.hitos_hito_id_seq OWNED BY tst.hitos.hito_id;


--
-- Name: origen_tarea_planficada; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.origen_tarea_planficada (
    origen character varying NOT NULL,
    tapl_id bigint NOT NULL,
    orta_id bigint NOT NULL
);


ALTER TABLE tst.origen_tarea_planficada OWNER TO postgres;

--
-- Name: plantillas; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.plantillas (
    plan_id integer NOT NULL,
    nombre character varying NOT NULL,
    empr_id integer NOT NULL,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE tst.plantillas OWNER TO postgres;

--
-- Name: plantillas_plan_id_seq; Type: SEQUENCE; Schema: tst; Owner: postgres
--

CREATE SEQUENCE tst.plantillas_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.plantillas_plan_id_seq OWNER TO postgres;

--
-- Name: plantillas_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: postgres
--

ALTER SEQUENCE tst.plantillas_plan_id_seq OWNED BY tst.plantillas.plan_id;


--
-- Name: recursos_tareas; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.recursos_tareas (
    tapl_id integer NOT NULL,
    recu_id integer NOT NULL
);


ALTER TABLE tst.recursos_tareas OWNER TO postgres;

--
-- Name: rel_plantillas_tareas; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.rel_plantillas_tareas (
    plan_id integer NOT NULL,
    tare_id integer NOT NULL
);


ALTER TABLE tst.rel_plantillas_tareas OWNER TO postgres;

--
-- Name: rel_tareas_pedidos; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.rel_tareas_pedidos (
    tapl_id integer NOT NULL,
    pema_id integer NOT NULL
);


ALTER TABLE tst.rel_tareas_pedidos OWNER TO postgres;

--
-- Name: subtareas; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.subtareas (
    suta_id integer NOT NULL,
    nombre character varying,
    descripcion character varying NOT NULL,
    duracion character varying,
    tare_id integer NOT NULL,
    form_id integer,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false
);


ALTER TABLE tst.subtareas OWNER TO postgres;

--
-- Name: subtareas_suta_id_seq; Type: SEQUENCE; Schema: tst; Owner: postgres
--

CREATE SEQUENCE tst.subtareas_suta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.subtareas_suta_id_seq OWNER TO postgres;

--
-- Name: subtareas_suta_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: postgres
--

ALTER SEQUENCE tst.subtareas_suta_id_seq OWNED BY tst.subtareas.suta_id;


--
-- Name: tareas_planificadas; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.tareas_planificadas (
    tapl_id integer NOT NULL,
    nombre character varying NOT NULL,
    fecha date,
    user_id character varying,
    equi_id integer,
    case_id character varying(32),
    tare_id integer,
    proc_id character varying,
    form_id integer,
    rece_id integer,
    info_id integer,
    eliminado boolean DEFAULT false NOT NULL,
    estado character varying DEFAULT 'creada'::character varying NOT NULL,
    fec_inicio timestamp without time zone,
    fec_fin timestamp without time zone,
    descripcion character varying,
    hora_duracion character varying,
    empr_id integer NOT NULL
);


ALTER TABLE tst.tareas_planificadas OWNER TO postgres;

--
-- Name: tareas_planificadas_tapl_id_seq; Type: SEQUENCE; Schema: tst; Owner: postgres
--

CREATE SEQUENCE tst.tareas_planificadas_tapl_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.tareas_planificadas_tapl_id_seq OWNER TO postgres;

--
-- Name: tareas_planificadas_tapl_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: postgres
--

ALTER SEQUENCE tst.tareas_planificadas_tapl_id_seq OWNED BY tst.tareas_planificadas.tapl_id;


--
-- Name: tareas_std; Type: TABLE; Schema: tst; Owner: postgres
--

CREATE TABLE tst.tareas_std (
    tare_id integer NOT NULL,
    nombre character varying NOT NULL,
    descripcion character varying,
    duracion character varying,
    form_id integer,
    rece_id integer,
    proc_id character varying,
    fec_alta timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    eliminado boolean DEFAULT false,
    empr_id integer NOT NULL
);


ALTER TABLE tst.tareas_std OWNER TO postgres;

--
-- Name: tareas_std_tare_id_seq; Type: SEQUENCE; Schema: tst; Owner: postgres
--

CREATE SEQUENCE tst.tareas_std_tare_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE tst.tareas_std_tare_id_seq OWNER TO postgres;

--
-- Name: tareas_std_tare_id_seq; Type: SEQUENCE OWNED BY; Schema: tst; Owner: postgres
--

ALTER SEQUENCE tst.tareas_std_tare_id_seq OWNED BY tst.tareas_std.tare_id;


--
-- Name: ajustes ajus_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.ajustes ALTER COLUMN ajus_id SET DEFAULT nextval('alm.ajustes_ajus_id_seq'::regclass);


--
-- Name: alm_articulos arti_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_articulos ALTER COLUMN arti_id SET DEFAULT nextval('alm.alm_articulos_arti_id_seq'::regclass);


--
-- Name: alm_depositos depo_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_depositos ALTER COLUMN depo_id SET DEFAULT nextval('alm.alm_depositos_depo_id_seq'::regclass);


--
-- Name: alm_deta_entrega_materiales deen_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_entrega_materiales ALTER COLUMN deen_id SET DEFAULT nextval('alm.alm_deta_entrega_materiales_deen_id_seq'::regclass);


--
-- Name: alm_deta_pedidos_materiales depe_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_pedidos_materiales ALTER COLUMN depe_id SET DEFAULT nextval('alm.alm_deta_pedidos_materiales_depe_id_seq'::regclass);


--
-- Name: alm_deta_recepcion_materiales dere_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_recepcion_materiales ALTER COLUMN dere_id SET DEFAULT nextval('alm.alm_deta_recepcion_materiales_dere_id_seq'::regclass);


--
-- Name: alm_entrega_materiales enma_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_entrega_materiales ALTER COLUMN enma_id SET DEFAULT nextval('alm.alm_entrega_materiales_enma_id_seq'::regclass);


--
-- Name: alm_lotes lote_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes ALTER COLUMN lote_id SET DEFAULT nextval('alm.alm_lotes_lote_id_seq'::regclass);


--
-- Name: alm_pedidos_materiales pema_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_pedidos_materiales ALTER COLUMN pema_id SET DEFAULT nextval('alm.alm_pedidos_materiales_pema_id_seq'::regclass);


--
-- Name: alm_proveedores prov_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores ALTER COLUMN prov_id SET DEFAULT nextval('alm.alm_proveedores_prov_id_seq'::regclass);


--
-- Name: alm_recepcion_materiales rema_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_recepcion_materiales ALTER COLUMN rema_id SET DEFAULT nextval('alm.alm_recepcion_materiales_rema_id_seq'::regclass);


--
-- Name: deta_ajustes deaj_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_ajustes ALTER COLUMN deaj_id SET DEFAULT nextval('alm.deta_ajustes_deaj_id_seq'::regclass);


--
-- Name: deta_movimientos_internos demi_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos ALTER COLUMN demi_id SET DEFAULT nextval('alm.deta_movimientos_internos_demi_id_seq'::regclass);


--
-- Name: items item_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.items ALTER COLUMN item_id SET DEFAULT nextval('alm.items_item_id_seq'::regclass);


--
-- Name: movimientos_internos moin_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.movimientos_internos ALTER COLUMN moin_id SET DEFAULT nextval('alm.movimientos_internos_moin_id_seq'::regclass);


--
-- Name: utl_tablas tabl_id; Type: DEFAULT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.utl_tablas ALTER COLUMN tabl_id SET DEFAULT nextval('alm.utl_tablas_tabl_id_seq'::regclass);


--
-- Name: calendario cale_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.calendario ALTER COLUMN cale_id SET DEFAULT nextval('core.calendario_cale_id_seq'::regclass);


--
-- Name: clientes clie_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.clientes ALTER COLUMN clie_id SET DEFAULT nextval('core.clientes_clie_id_seq'::regclass);


--
-- Name: componente_equipo coeq_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.componente_equipo ALTER COLUMN coeq_id SET DEFAULT nextval('core.componente_equipo_coeq_id_seq'::regclass);


--
-- Name: empresas empr_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.empresas ALTER COLUMN empr_id SET DEFAULT nextval('core.empresas_empr_id_seq'::regclass);


--
-- Name: equipos equi_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.equipos ALTER COLUMN equi_id SET DEFAULT nextval('core.equipos_equi_id_seq'::regclass);


--
-- Name: jornada_laboral jola_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.jornada_laboral ALTER COLUMN jola_id SET DEFAULT nextval('core.jornada_laboral_jola_id_seq'::regclass);


--
-- Name: no_laborables nola_id; Type: DEFAULT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.no_laborables ALTER COLUMN nola_id SET DEFAULT nextval('core.no_laborables_nola_id_seq'::regclass);


--
-- Name: formularios form_id; Type: DEFAULT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.formularios ALTER COLUMN form_id SET DEFAULT nextval('frm.formularios_form_id_seq'::regclass);


--
-- Name: instancias_formularios inst_id; Type: DEFAULT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.instancias_formularios ALTER COLUMN inst_id SET DEFAULT nextval('frm.instancias_formularios_inst_id_seq'::regclass);


--
-- Name: items item_id; Type: DEFAULT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.items ALTER COLUMN item_id SET DEFAULT nextval('frm.items_item_id_seq'::regclass);


--
-- Name: utl_tablas tabl_id; Type: DEFAULT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.utl_tablas ALTER COLUMN tabl_id SET DEFAULT nextval('frm.utl_tablas_tabl_id_seq'::regclass);


--
-- Name: movimientos_no_consumibles monc_id; Type: DEFAULT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.movimientos_no_consumibles ALTER COLUMN monc_id SET DEFAULT nextval('nco.movimientos_no_consumibles_monc_id_seq'::regclass);


--
-- Name: entrada_panol enpa_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.entrada_panol ALTER COLUMN enpa_id SET DEFAULT nextval('pan.entrada_panol_enpa_id_seq'::regclass);


--
-- Name: estanteria estan_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.estanteria ALTER COLUMN estan_id SET DEFAULT nextval('pan.estanteria_estan_id_seq'::regclass);


--
-- Name: herramientas herr_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.herramientas ALTER COLUMN herr_id SET DEFAULT nextval('pan.herramientas_herr_id_seq'::regclass);


--
-- Name: panol pano_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.panol ALTER COLUMN pano_id SET DEFAULT nextval('pan.panol_pano_id_seq'::regclass);


--
-- Name: salida_panol sapa_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.salida_panol ALTER COLUMN sapa_id SET DEFAULT nextval('pan.salida_panol_sapa_id_seq'::regclass);


--
-- Name: trazacomponente traz_id; Type: DEFAULT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.trazacomponente ALTER COLUMN traz_id SET DEFAULT nextval('pan.trazacomponente_traz_id_seq'::regclass);


--
-- Name: empaque empa_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.empaque ALTER COLUMN empa_id SET DEFAULT nextval('prd.empaque_empa_id_seq'::regclass);


--
-- Name: establecimientos esta_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.establecimientos ALTER COLUMN esta_id SET DEFAULT nextval('prd.establecimientos_esta_id_seq'::regclass);


--
-- Name: etapas etap_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas ALTER COLUMN etap_id SET DEFAULT nextval('prd.etapas_etap_id_seq'::regclass);


--
-- Name: formulas form_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas ALTER COLUMN form_id SET DEFAULT nextval('prd.formulas_form_id_seq'::regclass);


--
-- Name: lotes batch_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes ALTER COLUMN batch_id SET DEFAULT nextval('prd.lotes_batch_id_seq'::regclass);


--
-- Name: movimientos_trasportes motr_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes ALTER COLUMN motr_id SET DEFAULT nextval('prd.movimientos_trasportes_motr_id_seq'::regclass);


--
-- Name: procesos proc_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.procesos ALTER COLUMN proc_id SET DEFAULT nextval('prd.productos_prod_id_seq'::regclass);


--
-- Name: recipientes reci_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recipientes ALTER COLUMN reci_id SET DEFAULT nextval('prd.recipiente_reci_id_seq'::regclass);


--
-- Name: recursos recu_id; Type: DEFAULT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos ALTER COLUMN recu_id SET DEFAULT nextval('prd.recursos_recu_id_seq'::regclass);


--
-- Name: pedidos_trabajo petr_id; Type: DEFAULT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo ALTER COLUMN petr_id SET DEFAULT nextval('pro.pedidos_trabajo_petr_id_seq'::regclass);


--
-- Name: utl_tablas tabl_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utl_tablas ALTER COLUMN tabl_id SET DEFAULT nextval('public.utl_tablas_tabl_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.settings ALTER COLUMN id SET DEFAULT nextval('seg.settings_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.tokens ALTER COLUMN id SET DEFAULT nextval('seg.tokens_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.users ALTER COLUMN id SET DEFAULT nextval('seg.users_id_seq'::regclass);


--
-- Name: depositos depo_id; Type: DEFAULT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.depositos ALTER COLUMN depo_id SET DEFAULT nextval('sicpoa.depositos_depo_id_seq'::regclass);


--
-- Name: detalles_documento dedo_id; Type: DEFAULT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.detalles_documento ALTER COLUMN dedo_id SET DEFAULT nextval('sicpoa.detalles_documento_dedo_id_seq'::regclass);


--
-- Name: hitos hito_id; Type: DEFAULT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.hitos ALTER COLUMN hito_id SET DEFAULT nextval('tst.hitos_hito_id_seq'::regclass);


--
-- Name: plantillas plan_id; Type: DEFAULT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.plantillas ALTER COLUMN plan_id SET DEFAULT nextval('tst.plantillas_plan_id_seq'::regclass);


--
-- Name: subtareas suta_id; Type: DEFAULT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.subtareas ALTER COLUMN suta_id SET DEFAULT nextval('tst.subtareas_suta_id_seq'::regclass);


--
-- Name: tareas_planificadas tapl_id; Type: DEFAULT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas ALTER COLUMN tapl_id SET DEFAULT nextval('tst.tareas_planificadas_tapl_id_seq'::regclass);


--
-- Name: tareas_std tare_id; Type: DEFAULT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_std ALTER COLUMN tare_id SET DEFAULT nextval('tst.tareas_std_tare_id_seq'::regclass);


--
-- Name: ajustes ajustes_pk; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.ajustes
    ADD CONSTRAINT ajustes_pk PRIMARY KEY (ajus_id);


--
-- Name: alm_articulos alm_articulos_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_articulos
    ADD CONSTRAINT alm_articulos_pkey PRIMARY KEY (arti_id);


--
-- Name: alm_depositos alm_depositos_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_depositos
    ADD CONSTRAINT alm_depositos_pkey PRIMARY KEY (depo_id);


--
-- Name: alm_deta_entrega_materiales alm_deta_entrega_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_entrega_materiales
    ADD CONSTRAINT alm_deta_entrega_materiales_pkey PRIMARY KEY (deen_id);


--
-- Name: alm_deta_pedidos_materiales alm_deta_pedidos_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_pedidos_materiales
    ADD CONSTRAINT alm_deta_pedidos_materiales_pkey PRIMARY KEY (depe_id);


--
-- Name: alm_deta_recepcion_materiales alm_deta_recepcion_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_recepcion_materiales
    ADD CONSTRAINT alm_deta_recepcion_materiales_pkey PRIMARY KEY (dere_id);


--
-- Name: alm_entrega_materiales alm_entrega_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_entrega_materiales
    ADD CONSTRAINT alm_entrega_materiales_pkey PRIMARY KEY (enma_id);


--
-- Name: alm_lotes alm_lotes_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_pkey PRIMARY KEY (lote_id);


--
-- Name: alm_lotes alm_lotes_un; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_un UNIQUE (prov_id, arti_id, depo_id, codigo, batch_id);


--
-- Name: alm_pedidos_materiales alm_pedidos_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_pedidos_materiales
    ADD CONSTRAINT alm_pedidos_materiales_pkey PRIMARY KEY (pema_id);


--
-- Name: alm_proveedores_articulos alm_proveedores_articulos_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores_articulos
    ADD CONSTRAINT alm_proveedores_articulos_pkey PRIMARY KEY (prov_id, arti_id);


--
-- Name: alm_proveedores alm_proveedores_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores
    ADD CONSTRAINT alm_proveedores_pkey PRIMARY KEY (prov_id);


--
-- Name: alm_recepcion_materiales alm_recepcion_materiales_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_recepcion_materiales
    ADD CONSTRAINT alm_recepcion_materiales_pkey PRIMARY KEY (rema_id);


--
-- Name: deta_ajustes deta_ajustes_pk; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_ajustes
    ADD CONSTRAINT deta_ajustes_pk PRIMARY KEY (deaj_id);


--
-- Name: deta_movimientos_internos deta_movimientos_internos_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos
    ADD CONSTRAINT deta_movimientos_internos_pkey PRIMARY KEY (demi_id);


--
-- Name: items items_pk; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.items
    ADD CONSTRAINT items_pk PRIMARY KEY (item_id);


--
-- Name: movimientos_internos movimientos_internos_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.movimientos_internos
    ADD CONSTRAINT movimientos_internos_pkey PRIMARY KEY (moin_id);


--
-- Name: origen_pedido_materiales origen_pedido_materiales_pk; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.origen_pedido_materiales
    ADD CONSTRAINT origen_pedido_materiales_pk PRIMARY KEY (tipo, orig_id, pema_id);


--
-- Name: utl_tablas utl_tablas_pkey; Type: CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.utl_tablas
    ADD CONSTRAINT utl_tablas_pkey PRIMARY KEY (tabl_id);


--
-- Name: calendario calendario_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.calendario
    ADD CONSTRAINT calendario_pkey PRIMARY KEY (cale_id);


--
-- Name: case_empresa case_empresa_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.case_empresa
    ADD CONSTRAINT case_empresa_pk PRIMARY KEY (case_id);


--
-- Name: case_empresa case_empresa_un; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.case_empresa
    ADD CONSTRAINT case_empresa_un UNIQUE (case_id);


--
-- Name: clientes clientes_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT clientes_pk PRIMARY KEY (clie_id);


--
-- Name: componente_equipo componente_equipo_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.componente_equipo
    ADD CONSTRAINT componente_equipo_pk PRIMARY KEY (coeq_id);


--
-- Name: empresas empresas_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.empresas
    ADD CONSTRAINT empresas_pkey PRIMARY KEY (empr_id);


--
-- Name: equipos equipos_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.equipos
    ADD CONSTRAINT equipos_pkey PRIMARY KEY (equi_id);


--
-- Name: jornada_laboral jornada_laboral_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.jornada_laboral
    ADD CONSTRAINT jornada_laboral_pkey PRIMARY KEY (jola_id);


--
-- Name: no_laborables no_laborables_pkey; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.no_laborables
    ADD CONSTRAINT no_laborables_pkey PRIMARY KEY (nola_id);


--
-- Name: snapshots snapshots_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.snapshots
    ADD CONSTRAINT snapshots_pk PRIMARY KEY (snap_id);


--
-- Name: tablas tablas_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.tablas
    ADD CONSTRAINT tablas_pk PRIMARY KEY (tabl_id);


--
-- Name: transportistas transportistas_pk; Type: CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.transportistas
    ADD CONSTRAINT transportistas_pk PRIMARY KEY (cuit);


--
-- Name: formularios formularios_pk; Type: CONSTRAINT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.formularios
    ADD CONSTRAINT formularios_pk PRIMARY KEY (form_id);


--
-- Name: instancias_formularios instancias_formularios_pk; Type: CONSTRAINT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.instancias_formularios
    ADD CONSTRAINT instancias_formularios_pk PRIMARY KEY (inst_id);


--
-- Name: items items_pk; Type: CONSTRAINT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.items
    ADD CONSTRAINT items_pk PRIMARY KEY (item_id);


--
-- Name: utl_tablas utl_tablas_pkey; Type: CONSTRAINT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.utl_tablas
    ADD CONSTRAINT utl_tablas_pkey PRIMARY KEY (tabl_id);


--
-- Name: movimientos_no_consumibles movimientos_no_consumibles_pk; Type: CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.movimientos_no_consumibles
    ADD CONSTRAINT movimientos_no_consumibles_pk PRIMARY KEY (monc_id);


--
-- Name: no_consumibles_lotes no_consumibles_lotes_un; Type: CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.no_consumibles_lotes
    ADD CONSTRAINT no_consumibles_lotes_un UNIQUE (noco_id, empr_id, batch_id, fec_liberacion);


--
-- Name: no_consumibles no_consumibles_pk; Type: CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.no_consumibles
    ADD CONSTRAINT no_consumibles_pk PRIMARY KEY (codigo, empr_id);


--
-- Name: entrada_panol entrada_panol_pk; Type: CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.entrada_panol
    ADD CONSTRAINT entrada_panol_pk PRIMARY KEY (enpa_id);


--
-- Name: estanteria estanteria_pk; Type: CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.estanteria
    ADD CONSTRAINT estanteria_pk PRIMARY KEY (estan_id);


--
-- Name: herramientas herramientas_pk; Type: CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.herramientas
    ADD CONSTRAINT herramientas_pk PRIMARY KEY (herr_id);


--
-- Name: panol panol_pk; Type: CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.panol
    ADD CONSTRAINT panol_pk PRIMARY KEY (pano_id);


--
-- Name: salida_panol salida_panol_pk; Type: CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.salida_panol
    ADD CONSTRAINT salida_panol_pk PRIMARY KEY (sapa_id);


--
-- Name: costos costos_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.costos
    ADD CONSTRAINT costos_pk PRIMARY KEY (fec_vigencia, recu_id);


--
-- Name: empaque empaque_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.empaque
    ADD CONSTRAINT empaque_pk PRIMARY KEY (empa_id);


--
-- Name: establecimientos establecimientos_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.establecimientos
    ADD CONSTRAINT establecimientos_pk PRIMARY KEY (esta_id);


--
-- Name: etapas_materiales etapas_materiales_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_materiales
    ADD CONSTRAINT etapas_materiales_un UNIQUE (etap_id, arti_id);


--
-- Name: etapas etapas_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_pk PRIMARY KEY (etap_id);


--
-- Name: etapas_productos etapas_productos_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_productos
    ADD CONSTRAINT etapas_productos_un UNIQUE (etap_id, arti_id);


--
-- Name: etapas_salidas etapas_salidas_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_salidas
    ADD CONSTRAINT etapas_salidas_un UNIQUE (etap_id, arti_id);


--
-- Name: formulas formulas_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas
    ADD CONSTRAINT formulas_pk PRIMARY KEY (form_id);


--
-- Name: lotes_tareas_planificadas lotes_tareas_planificadas_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_tareas_planificadas
    ADD CONSTRAINT lotes_tareas_planificadas_pk PRIMARY KEY (tapl_id, batch_id);


--
-- Name: lotes lotes_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes
    ADD CONSTRAINT lotes_un UNIQUE (batch_id);


--
-- Name: movimientos_trasportes movimientos_trasportes_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_pk PRIMARY KEY (motr_id);


--
-- Name: procesos productos_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.procesos
    ADD CONSTRAINT productos_pk PRIMARY KEY (proc_id);


--
-- Name: procesos productos_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.procesos
    ADD CONSTRAINT productos_un UNIQUE (nombre);


--
-- Name: recipientes recipientes_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recipientes
    ADD CONSTRAINT recipientes_pk PRIMARY KEY (reci_id);


--
-- Name: recursos recursos_pk; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos
    ADD CONSTRAINT recursos_pk PRIMARY KEY (recu_id);


--
-- Name: recursos recursos_un; Type: CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos
    ADD CONSTRAINT recursos_un UNIQUE (arti_id);


--
-- Name: pedidos_trabajo_forms pedidos_trabajo_forms_pk; Type: CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo_forms
    ADD CONSTRAINT pedidos_trabajo_forms_pk PRIMARY KEY (petr_id, info_id, task_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_pk; Type: CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_pk PRIMARY KEY (petr_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_un; Type: CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_un UNIQUE (cod_proyecto, empr_id);


--
-- Name: procesos procesos_pk; Type: CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.procesos
    ADD CONSTRAINT procesos_pk PRIMARY KEY (proc_id);


--
-- Name: procesos procesos_un; Type: CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.procesos
    ADD CONSTRAINT procesos_un UNIQUE (nombre, empr_id);


--
-- Name: utl_tablas utl_tablas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utl_tablas
    ADD CONSTRAINT utl_tablas_pkey PRIMARY KEY (tabl_id);


--
-- Name: memberships_users memberships_pk; Type: CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.memberships_users
    ADD CONSTRAINT memberships_pk PRIMARY KEY ("group", role, email);


--
-- Name: menues menues_pk; Type: CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.menues
    ADD CONSTRAINT menues_pk PRIMARY KEY (modulo, opcion);


--
-- Name: tokens tokens_pk; Type: CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.tokens
    ADD CONSTRAINT tokens_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: users users_un; Type: CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.users
    ADD CONSTRAINT users_un UNIQUE (email);


--
-- Name: inspecciones actas_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones
    ADD CONSTRAINT actas_pk PRIMARY KEY (case_id);


--
-- Name: choferes choferes_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.choferes
    ADD CONSTRAINT choferes_pk PRIMARY KEY (dni);


--
-- Name: depositos depositos_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.depositos
    ADD CONSTRAINT depositos_pk PRIMARY KEY (depo_id);


--
-- Name: deta_infracciones deta_infracciones_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.deta_infracciones
    ADD CONSTRAINT deta_infracciones_pk PRIMARY KEY (case_id, tiin_id);


--
-- Name: detalles_documento detalles_documento_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.detalles_documento
    ADD CONSTRAINT detalles_documento_pk PRIMARY KEY (dedo_id);


--
-- Name: documentos documentos_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_pk PRIMARY KEY (num_documento, tido_id);


--
-- Name: empresas empresas_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.empresas
    ADD CONSTRAINT empresas_pk PRIMARY KEY (cuit);


--
-- Name: infracciones infracciones_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.infracciones
    ADD CONSTRAINT infracciones_pk PRIMARY KEY (case_id);


--
-- Name: inspecciones_empresas inspecciones_empresas_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_empresas
    ADD CONSTRAINT inspecciones_empresas_pk PRIMARY KEY (empr_id, case_id, rol);


--
-- Name: inspecciones_termicos inspecciones_termicos_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_termicos
    ADD CONSTRAINT inspecciones_termicos_pk PRIMARY KEY (case_id, term_id);


--
-- Name: permisos_transito permisos_transito_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.permisos_transito
    ADD CONSTRAINT permisos_transito_pk PRIMARY KEY (perm_id, case_id);


--
-- Name: termicos termicos_pk; Type: CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.termicos
    ADD CONSTRAINT termicos_pk PRIMARY KEY (patente);


--
-- Name: hitos hitos_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.hitos
    ADD CONSTRAINT hitos_pk PRIMARY KEY (hito_id);


--
-- Name: rel_tareas_pedidos newtable_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_tareas_pedidos
    ADD CONSTRAINT newtable_pk PRIMARY KEY (tapl_id, pema_id);


--
-- Name: origen_tarea_planficada origen_tarea_planficada_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.origen_tarea_planficada
    ADD CONSTRAINT origen_tarea_planficada_pk PRIMARY KEY (origen, tapl_id, orta_id);


--
-- Name: plantillas plantillas_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.plantillas
    ADD CONSTRAINT plantillas_pk PRIMARY KEY (plan_id);


--
-- Name: rel_plantillas_tareas rel_plantillas_tareas_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_plantillas_tareas
    ADD CONSTRAINT rel_plantillas_tareas_pk PRIMARY KEY (plan_id, tare_id);


--
-- Name: subtareas subtareas_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.subtareas
    ADD CONSTRAINT subtareas_pk PRIMARY KEY (suta_id);


--
-- Name: tareas_planificadas tareas_planificadas_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas
    ADD CONSTRAINT tareas_planificadas_pk PRIMARY KEY (tapl_id);


--
-- Name: tareas_std tareas_std_pk; Type: CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_std
    ADD CONSTRAINT tareas_std_pk PRIMARY KEY (tare_id);


--
-- Name: lotes_fec_planificado_idx; Type: INDEX; Schema: prd; Owner: postgres
--

CREATE INDEX lotes_fec_planificado_idx ON prd.lotes USING btree (fec_planificado);


--
-- Name: lotes_hijos_batch_id_idx; Type: INDEX; Schema: prd; Owner: postgres
--

CREATE INDEX lotes_hijos_batch_id_idx ON prd.lotes_hijos USING btree (batch_id);


--
-- Name: lotes_hijos_batch_id_padre_idx; Type: INDEX; Schema: prd; Owner: postgres
--

CREATE INDEX lotes_hijos_batch_id_padre_idx ON prd.lotes_hijos USING btree (batch_id_padre);


--
-- Name: users_business_busines_idx; Type: INDEX; Schema: seg; Owner: postgres
--

CREATE INDEX users_business_busines_idx ON seg.users_business USING btree (busines, email);


--
-- Name: documentos_fec_alta_idx; Type: INDEX; Schema: sicpoa; Owner: postgres
--

CREATE INDEX documentos_fec_alta_idx ON sicpoa.documentos USING btree (fec_alta);


--
-- Name: empresas_num_establecimiento_idx; Type: INDEX; Schema: sicpoa; Owner: postgres
--

CREATE INDEX empresas_num_establecimiento_idx ON sicpoa.empresas USING btree (num_establecimiento);


--
-- Name: empresas_razon_social_idx; Type: INDEX; Schema: sicpoa; Owner: postgres
--

CREATE INDEX empresas_razon_social_idx ON sicpoa.empresas USING btree (razon_social);


--
-- Name: inspecciones_fec_alta_idx; Type: INDEX; Schema: sicpoa; Owner: postgres
--

CREATE INDEX inspecciones_fec_alta_idx ON sicpoa.inspecciones USING btree (fec_alta);


--
-- Name: inspecciones_resultado_idx; Type: INDEX; Schema: sicpoa; Owner: postgres
--

CREATE INDEX inspecciones_resultado_idx ON sicpoa.inspecciones USING btree (resultado);


--
-- Name: alm_deta_entrega_materiales asociar_lote_hijo_ai; Type: TRIGGER; Schema: alm; Owner: postgres
--

CREATE TRIGGER asociar_lote_hijo_ai AFTER INSERT ON alm.alm_deta_entrega_materiales FOR EACH ROW EXECUTE PROCEDURE prd.asociar_lote_hijo_trg();


--
-- Name: alm_articulos crear_producto_ai; Type: TRIGGER; Schema: alm; Owner: postgres
--

CREATE TRIGGER crear_producto_ai AFTER INSERT ON alm.alm_articulos FOR EACH ROW EXECUTE PROCEDURE prd.crear_prd_recurso_trg();


--
-- Name: alm_articulos eliminar_producto_ad; Type: TRIGGER; Schema: alm; Owner: postgres
--

CREATE TRIGGER eliminar_producto_ad AFTER DELETE ON alm.alm_articulos FOR EACH ROW EXECUTE PROCEDURE prd.eliminar_prd_recurso_trg();


--
-- Name: alm_deta_pedidos_materiales tgrupdateresto; Type: TRIGGER; Schema: alm; Owner: postgres
--

CREATE TRIGGER tgrupdateresto AFTER INSERT ON alm.alm_deta_pedidos_materiales FOR EACH ROW EXECUTE PROCEDURE alm.fnupdateresto();


--
-- Name: tablas set_tabla_id_bui; Type: TRIGGER; Schema: core; Owner: postgres
--

CREATE TRIGGER set_tabla_id_bui BEFORE INSERT OR UPDATE ON core.tablas FOR EACH ROW EXECUTE PROCEDURE core.set_tabla_id_trg();


--
-- Name: instancias_formularios tg_increment_info_id; Type: TRIGGER; Schema: frm; Owner: postgres
--

CREATE TRIGGER tg_increment_info_id BEFORE INSERT ON frm.instancias_formularios FOR EACH STATEMENT EXECUTE PROCEDURE frm.increment_info_id_batch();


--
-- Name: lotes lotes_ult_modificacion_trg; Type: TRIGGER; Schema: prd; Owner: postgres
--

CREATE TRIGGER lotes_ult_modificacion_trg BEFORE UPDATE ON prd.lotes FOR EACH ROW EXECUTE PROCEDURE core.ult_modificacion_trg();


--
-- Name: ajustes ajustes_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.ajustes
    ADD CONSTRAINT ajustes_fk FOREIGN KEY (tipo_ajuste) REFERENCES core.tablas(tabl_id);


--
-- Name: alm_articulos alm_articulos_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_articulos
    ADD CONSTRAINT alm_articulos_fk FOREIGN KEY (tiar_id) REFERENCES core.tablas(tabl_id);


--
-- Name: alm_articulos alm_articulos_unme_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_articulos
    ADD CONSTRAINT alm_articulos_unme_id_fk FOREIGN KEY (unme_id) REFERENCES core.tablas(tabl_id);


--
-- Name: alm_deta_entrega_materiales alm_deta_entrega_materiales_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_entrega_materiales
    ADD CONSTRAINT alm_deta_entrega_materiales_fk FOREIGN KEY (enma_id) REFERENCES alm.alm_entrega_materiales(enma_id);


--
-- Name: alm_deta_pedidos_materiales alm_deta_pedidos_materiales_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_pedidos_materiales
    ADD CONSTRAINT alm_deta_pedidos_materiales_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: alm_deta_pedidos_materiales alm_deta_pedidos_materiales_fk_1; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_pedidos_materiales
    ADD CONSTRAINT alm_deta_pedidos_materiales_fk_1 FOREIGN KEY (pema_id) REFERENCES alm.alm_pedidos_materiales(pema_id);


--
-- Name: alm_deta_recepcion_materiales alm_deta_recepcion_materiales_lote_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_recepcion_materiales
    ADD CONSTRAINT alm_deta_recepcion_materiales_lote_id_fk FOREIGN KEY (lote_id) REFERENCES alm.alm_lotes(lote_id);


--
-- Name: alm_deta_recepcion_materiales alm_deta_recepcion_materiales_rema_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_deta_recepcion_materiales
    ADD CONSTRAINT alm_deta_recepcion_materiales_rema_id_fk FOREIGN KEY (rema_id) REFERENCES alm.alm_recepcion_materiales(rema_id);


--
-- Name: alm_entrega_materiales alm_entrega_materiales_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_entrega_materiales
    ADD CONSTRAINT alm_entrega_materiales_fk FOREIGN KEY (pema_id) REFERENCES alm.alm_pedidos_materiales(pema_id);


--
-- Name: alm_depositos alm_establecimientos_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_depositos
    ADD CONSTRAINT alm_establecimientos_fk FOREIGN KEY (esta_id) REFERENCES prd.establecimientos(esta_id);


--
-- Name: alm_lotes alm_lotes_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: alm_lotes alm_lotes_fk_1; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_fk_1 FOREIGN KEY (prov_id) REFERENCES alm.alm_proveedores(prov_id);


--
-- Name: alm_lotes alm_lotes_fk_7; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_fk_7 FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: alm_lotes alm_lotes_fk_batch_id; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_lotes
    ADD CONSTRAINT alm_lotes_fk_batch_id FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: alm_pedidos_materiales alm_pedidos_materiales_batch_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_pedidos_materiales
    ADD CONSTRAINT alm_pedidos_materiales_batch_id_fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: alm_proveedores_articulos alm_proveedores_articulos_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores_articulos
    ADD CONSTRAINT alm_proveedores_articulos_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: alm_proveedores_articulos alm_proveedores_articulos_fk_1; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores_articulos
    ADD CONSTRAINT alm_proveedores_articulos_fk_1 FOREIGN KEY (prov_id) REFERENCES alm.alm_proveedores(prov_id);


--
-- Name: alm_proveedores alm_proveedores_fk_1; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores
    ADD CONSTRAINT alm_proveedores_fk_1 FOREIGN KEY (pais_id) REFERENCES core.tablas(tabl_id);


--
-- Name: alm_recepcion_materiales alm_recepcion_materiales_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_recepcion_materiales
    ADD CONSTRAINT alm_recepcion_materiales_fk FOREIGN KEY (prov_id) REFERENCES alm.alm_proveedores(prov_id);


--
-- Name: deta_ajustes deta_ajustes_ajustes_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_ajustes
    ADD CONSTRAINT deta_ajustes_ajustes_fk FOREIGN KEY (ajus_id) REFERENCES alm.ajustes(ajus_id);


--
-- Name: deta_ajustes deta_ajustes_alm_lotes_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_ajustes
    ADD CONSTRAINT deta_ajustes_alm_lotes_fk FOREIGN KEY (lote_id) REFERENCES alm.alm_lotes(lote_id);


--
-- Name: deta_movimientos_internos deta_movimientos_internos_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos
    ADD CONSTRAINT deta_movimientos_internos_fk FOREIGN KEY (moin_id) REFERENCES alm.movimientos_internos(moin_id);


--
-- Name: deta_movimientos_internos deta_movimientos_internos_fk_1; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos
    ADD CONSTRAINT deta_movimientos_internos_fk_1 FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: deta_movimientos_internos deta_movimientos_internos_lote_id_destino_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos
    ADD CONSTRAINT deta_movimientos_internos_lote_id_destino_fk FOREIGN KEY (lote_id_destino) REFERENCES alm.alm_lotes(lote_id);


--
-- Name: deta_movimientos_internos deta_movimientos_internos_lote_id_origen_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.deta_movimientos_internos
    ADD CONSTRAINT deta_movimientos_internos_lote_id_origen_fk FOREIGN KEY (lote_id_origen) REFERENCES alm.alm_lotes(lote_id);


--
-- Name: movimientos_internos movimientos_internos_depo_id_destino_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.movimientos_internos
    ADD CONSTRAINT movimientos_internos_depo_id_destino_fk FOREIGN KEY (depo_id_destino) REFERENCES alm.alm_depositos(depo_id);


--
-- Name: movimientos_internos movimientos_internos_depo_id_origenfk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.movimientos_internos
    ADD CONSTRAINT movimientos_internos_depo_id_origenfk FOREIGN KEY (depo_id_origen) REFERENCES alm.alm_depositos(depo_id);


--
-- Name: origen_pedido_materiales origen_pedido_materiales_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.origen_pedido_materiales
    ADD CONSTRAINT origen_pedido_materiales_fk FOREIGN KEY (pema_id) REFERENCES alm.alm_pedidos_materiales(pema_id);


--
-- Name: alm_proveedores proveedores_esta_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores
    ADD CONSTRAINT proveedores_esta_id_fk FOREIGN KEY (esta_id) REFERENCES core.tablas(tabl_id);


--
-- Name: alm_proveedores proveedores_loca_id_fk; Type: FK CONSTRAINT; Schema: alm; Owner: postgres
--

ALTER TABLE ONLY alm.alm_proveedores
    ADD CONSTRAINT proveedores_loca_id_fk FOREIGN KEY (loca_id) REFERENCES core.tablas(tabl_id);


--
-- Name: clientes clientes_fk; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT clientes_fk FOREIGN KEY (ticl_id) REFERENCES core.tablas(tabl_id);


--
-- Name: clientes clientes_fk2; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.clientes
    ADD CONSTRAINT clientes_fk2 FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: tablas tablas_empr_id_fk; Type: FK CONSTRAINT; Schema: core; Owner: postgres
--

ALTER TABLE ONLY core.tablas
    ADD CONSTRAINT tablas_empr_id_fk FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: items items_fk; Type: FK CONSTRAINT; Schema: frm; Owner: postgres
--

ALTER TABLE ONLY frm.items
    ADD CONSTRAINT items_fk FOREIGN KEY (form_id) REFERENCES frm.formularios(form_id);


--
-- Name: movimientos_no_consumibles movimientos_no_consumibles_depo_id_fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.movimientos_no_consumibles
    ADD CONSTRAINT movimientos_no_consumibles_depo_id_fk FOREIGN KEY (depo_id) REFERENCES alm.alm_depositos(depo_id);


--
-- Name: movimientos_no_consumibles movimientos_no_consumibles_dest_id_fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.movimientos_no_consumibles
    ADD CONSTRAINT movimientos_no_consumibles_dest_id_fk FOREIGN KEY (dest_id) REFERENCES core.tablas(tabl_id);


--
-- Name: movimientos_no_consumibles movimientos_no_consumibles_noco_id_fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.movimientos_no_consumibles
    ADD CONSTRAINT movimientos_no_consumibles_noco_id_fk FOREIGN KEY (noco_id, empr_id) REFERENCES nco.no_consumibles(codigo, empr_id);


--
-- Name: no_consumibles_lotes no_consumibles_lotes_batch_id__fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.no_consumibles_lotes
    ADD CONSTRAINT no_consumibles_lotes_batch_id__fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: no_consumibles_lotes no_consumibles_lotes_noco_id_fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.no_consumibles_lotes
    ADD CONSTRAINT no_consumibles_lotes_noco_id_fk FOREIGN KEY (noco_id, empr_id) REFERENCES nco.no_consumibles(codigo, empr_id);


--
-- Name: no_consumibles no_consumibles_tinc_id_fk; Type: FK CONSTRAINT; Schema: nco; Owner: postgres
--

ALTER TABLE ONLY nco.no_consumibles
    ADD CONSTRAINT no_consumibles_tinc_id_fk FOREIGN KEY (tinc_id) REFERENCES core.tablas(tabl_id);


--
-- Name: deta_entrada_panol deta_entrada_pano_herr_idl_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.deta_entrada_panol
    ADD CONSTRAINT deta_entrada_pano_herr_idl_fk FOREIGN KEY (herr_id) REFERENCES pan.herramientas(herr_id);


--
-- Name: deta_entrada_panol deta_entrada_panol_entr_panol_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.deta_entrada_panol
    ADD CONSTRAINT deta_entrada_panol_entr_panol_fk FOREIGN KEY (enpa_id) REFERENCES pan.entrada_panol(enpa_id);


--
-- Name: deta_salida_panol deta_salida_panol_herr_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.deta_salida_panol
    ADD CONSTRAINT deta_salida_panol_herr_id_fk FOREIGN KEY (herr_id) REFERENCES pan.herramientas(herr_id);


--
-- Name: deta_salida_panol deta_salida_panol_sapa_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.deta_salida_panol
    ADD CONSTRAINT deta_salida_panol_sapa_id_fk FOREIGN KEY (sapa_id) REFERENCES pan.salida_panol(sapa_id);


--
-- Name: entrada_panol entrada_panol_pano_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.entrada_panol
    ADD CONSTRAINT entrada_panol_pano_id_fk FOREIGN KEY (pano_id) REFERENCES pan.panol(pano_id);


--
-- Name: estanteria estanteria_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.estanteria
    ADD CONSTRAINT estanteria_fk FOREIGN KEY (pano_id) REFERENCES pan.panol(pano_id);


--
-- Name: herramientas herramientas_pano_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.herramientas
    ADD CONSTRAINT herramientas_pano_id_fk FOREIGN KEY (pano_id) REFERENCES pan.panol(pano_id);


--
-- Name: panol panol_esta_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.panol
    ADD CONSTRAINT panol_esta_id_fk FOREIGN KEY (esta_id) REFERENCES prd.establecimientos(esta_id);


--
-- Name: salida_panol salida_panol_pano_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.salida_panol
    ADD CONSTRAINT salida_panol_pano_id_fk FOREIGN KEY (pano_id) REFERENCES pan.panol(pano_id);


--
-- Name: trazacomponente trazacomponente_estan_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.trazacomponente
    ADD CONSTRAINT trazacomponente_estan_id_fk FOREIGN KEY (estan_id) REFERENCES pan.estanteria(estan_id);


--
-- Name: trazacomponente trazacomponente_pano_id_fk; Type: FK CONSTRAINT; Schema: pan; Owner: postgres
--

ALTER TABLE ONLY pan.trazacomponente
    ADD CONSTRAINT trazacomponente_pano_id_fk FOREIGN KEY (pano_id) REFERENCES pan.panol(pano_id);


--
-- Name: costos costos_recursos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.costos
    ADD CONSTRAINT costos_recursos_fk FOREIGN KEY (recu_id) REFERENCES prd.recursos(recu_id);


--
-- Name: empaque empaque_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.empaque
    ADD CONSTRAINT empaque_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: establecimientos establecimientos_estado_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.establecimientos
    ADD CONSTRAINT establecimientos_estado_fk FOREIGN KEY (estado) REFERENCES core.tablas(tabl_id);


--
-- Name: establecimientos establecimientos_localidad_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.establecimientos
    ADD CONSTRAINT establecimientos_localidad_fk FOREIGN KEY (localidad) REFERENCES core.tablas(tabl_id);


--
-- Name: establecimientos establecimientos_pais_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.establecimientos
    ADD CONSTRAINT establecimientos_pais_fk FOREIGN KEY (pais) REFERENCES core.tablas(tabl_id);


--
-- Name: etapas etapas_empr_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_empr_id_fk FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: etapas etapas_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_fk FOREIGN KEY (form_id) REFERENCES frm.formularios(form_id);


--
-- Name: etapas etapas_form_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_form_id_fk FOREIGN KEY (form_id) REFERENCES frm.formularios(form_id);


--
-- Name: etapas_materiales etapas_materiales_arti_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_materiales
    ADD CONSTRAINT etapas_materiales_arti_id_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: etapas_materiales etapas_materiales_etap_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_materiales
    ADD CONSTRAINT etapas_materiales_etap_id_fk FOREIGN KEY (etap_id) REFERENCES prd.etapas(etap_id);


--
-- Name: etapas_materiales etapas_materiales_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_materiales
    ADD CONSTRAINT etapas_materiales_fk FOREIGN KEY (etap_id) REFERENCES prd.etapas(etap_id);


--
-- Name: etapas etapas_proc_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_proc_id_fk FOREIGN KEY (proc_id) REFERENCES prd.procesos(proc_id);


--
-- Name: etapas etapas_procesos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_procesos_fk FOREIGN KEY (proc_id) REFERENCES prd.procesos(proc_id);


--
-- Name: etapas_productos etapas_productos_arti_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_productos
    ADD CONSTRAINT etapas_productos_arti_id_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: etapas_productos etapas_productos_etap_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_productos
    ADD CONSTRAINT etapas_productos_etap_id_fk FOREIGN KEY (etap_id) REFERENCES prd.etapas(etap_id);


--
-- Name: etapas_salidas etapas_salidas_etap_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_salidas
    ADD CONSTRAINT etapas_salidas_etap_id_fk FOREIGN KEY (etap_id) REFERENCES prd.etapas(etap_id);


--
-- Name: etapas_salidas etapas_salidas_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas_salidas
    ADD CONSTRAINT etapas_salidas_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: etapas etapas_tiet_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.etapas
    ADD CONSTRAINT etapas_tiet_id_fk FOREIGN KEY (tiet_id) REFERENCES core.tablas(tabl_id);


--
-- Name: formulas_articulos formulas_articulos__unme_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas_articulos
    ADD CONSTRAINT formulas_articulos__unme_id_fk FOREIGN KEY (unme_id) REFERENCES core.tablas(tabl_id);


--
-- Name: formulas_articulos formulas_articulos_arti_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas_articulos
    ADD CONSTRAINT formulas_articulos_arti_id_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: formulas_articulos formulas_articulos_form_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas_articulos
    ADD CONSTRAINT formulas_articulos_form_id_fk FOREIGN KEY (form_id) REFERENCES prd.formulas(form_id);


--
-- Name: formulas formulas_unme_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.formulas
    ADD CONSTRAINT formulas_unme_id_fk FOREIGN KEY (unme_id) REFERENCES core.tablas(tabl_id);


--
-- Name: lotes lotes_alm_articulos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes
    ADD CONSTRAINT lotes_alm_articulos_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: lotes lotes_etapas_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes
    ADD CONSTRAINT lotes_etapas_fk FOREIGN KEY (etap_id) REFERENCES prd.etapas(etap_id) ON DELETE RESTRICT;


--
-- Name: lotes_hijos lotes_hijos_lotes_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_hijos
    ADD CONSTRAINT lotes_hijos_lotes_fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: lotes_hijos lotes_hijos_lotes_padres_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_hijos
    ADD CONSTRAINT lotes_hijos_lotes_padres_fk FOREIGN KEY (batch_id_padre) REFERENCES prd.lotes(batch_id);


--
-- Name: lotes lotes_recipientes_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes
    ADD CONSTRAINT lotes_recipientes_fk FOREIGN KEY (reci_id) REFERENCES prd.recipientes(reci_id);


--
-- Name: lotes_responsables lotes_responsables_batch_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_responsables
    ADD CONSTRAINT lotes_responsables_batch_id_fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: lotes_responsables lotes_responsables_turn_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_responsables
    ADD CONSTRAINT lotes_responsables_turn_id_fk FOREIGN KEY (turn_id) REFERENCES core.tablas(tabl_id);


--
-- Name: lotes_responsables lotes_responsables_user_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_responsables
    ADD CONSTRAINT lotes_responsables_user_id_fk FOREIGN KEY (user_id) REFERENCES seg.users(id);


--
-- Name: lotes_tareas_planificadas lotes_tareas_planificadas_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_tareas_planificadas
    ADD CONSTRAINT lotes_tareas_planificadas_fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id);


--
-- Name: lotes_tareas_planificadas lotes_tareas_planificadas_fk_1; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.lotes_tareas_planificadas
    ADD CONSTRAINT lotes_tareas_planificadas_fk_1 FOREIGN KEY (tapl_id) REFERENCES tst.tareas_planificadas(tapl_id);


--
-- Name: movimientos_trasportes movimientos_trasportes__transportista_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes__transportista_fk FOREIGN KEY (cuit) REFERENCES core.transportistas(cuit);


--
-- Name: movimientos_trasportes movimientos_trasportes_clie_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_clie_id_fk FOREIGN KEY (clie_id) REFERENCES core.clientes(clie_id);


--
-- Name: movimientos_trasportes movimientos_trasportes_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_fk FOREIGN KEY (prov_id) REFERENCES alm.alm_proveedores(prov_id);


--
-- Name: movimientos_trasportes movimientos_trasportes_fk_1; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_fk_1 FOREIGN KEY (esta_id) REFERENCES prd.establecimientos(esta_id);


--
-- Name: movimientos_trasportes movimientos_trasportes_fk_2; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_fk_2 FOREIGN KEY (reci_id) REFERENCES prd.recipientes(reci_id);


--
-- Name: movimientos_trasportes movimientos_trasportes_fk_empr; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.movimientos_trasportes
    ADD CONSTRAINT movimientos_trasportes_fk_empr FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: recipientes recipientes_alm_depositos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recipientes
    ADD CONSTRAINT recipientes_alm_depositos_fk FOREIGN KEY (depo_id) REFERENCES alm.alm_depositos(depo_id);


--
-- Name: recipientes recipientes_care_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recipientes
    ADD CONSTRAINT recipientes_care_id_fk FOREIGN KEY (care_id) REFERENCES core.tablas(tabl_id);


--
-- Name: recipientes recipientes_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recipientes
    ADD CONSTRAINT recipientes_fk FOREIGN KEY (motr_id) REFERENCES prd.movimientos_trasportes(motr_id);


--
-- Name: recursos recursos_arti_id_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos
    ADD CONSTRAINT recursos_arti_id_fk FOREIGN KEY (arti_id) REFERENCES alm.alm_articulos(arti_id);


--
-- Name: recursos recursos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos
    ADD CONSTRAINT recursos_fk FOREIGN KEY (equi_id) REFERENCES core.equipos(equi_id);


--
-- Name: recursos_lotes recursos_lotes_lotes_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos_lotes
    ADD CONSTRAINT recursos_lotes_lotes_fk FOREIGN KEY (batch_id) REFERENCES prd.lotes(batch_id) ON DELETE RESTRICT;


--
-- Name: recursos_lotes recursos_lotes_recursos_fk; Type: FK CONSTRAINT; Schema: prd; Owner: postgres
--

ALTER TABLE ONLY prd.recursos_lotes
    ADD CONSTRAINT recursos_lotes_recursos_fk FOREIGN KEY (recu_id) REFERENCES prd.recursos(recu_id) ON DELETE RESTRICT;


--
-- Name: pedidos_trabajo pedidos_trabajo_clie_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_clie_id_fk FOREIGN KEY (clie_id) REFERENCES core.clientes(clie_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_empr_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_empr_id_fk FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_estado_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_estado_fk FOREIGN KEY (estado) REFERENCES core.tablas(tabl_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_fk FOREIGN KEY (proc_id) REFERENCES pro.procesos(proc_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_fk_1; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_fk_1 FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_proc_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_proc_id_fk FOREIGN KEY (proc_id) REFERENCES pro.procesos(proc_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_tipt_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_tipt_id_fk FOREIGN KEY (tipt_id) REFERENCES core.tablas(tabl_id);


--
-- Name: pedidos_trabajo pedidos_trabajo_umti_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.pedidos_trabajo
    ADD CONSTRAINT pedidos_trabajo_umti_id_fk FOREIGN KEY (umti_id) REFERENCES core.tablas(tabl_id);


--
-- Name: procesos procesos_esin_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.procesos
    ADD CONSTRAINT procesos_esin_id_fk FOREIGN KEY (esin_id) REFERENCES core.tablas(tabl_id);


--
-- Name: procesos procesos_form_id_fk; Type: FK CONSTRAINT; Schema: pro; Owner: postgres
--

ALTER TABLE ONLY pro.procesos
    ADD CONSTRAINT procesos_form_id_fk FOREIGN KEY (form_id) REFERENCES frm.formularios(form_id);


--
-- Name: memberships_menues memberships_menues_modulo_opcion_fk; Type: FK CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.memberships_menues
    ADD CONSTRAINT memberships_menues_modulo_opcion_fk FOREIGN KEY (modulo, opcion) REFERENCES seg.menues(modulo, opcion);


--
-- Name: memberships_users memberships_users_fk; Type: FK CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.memberships_users
    ADD CONSTRAINT memberships_users_fk FOREIGN KEY (email) REFERENCES seg.users(email);


--
-- Name: menues menues_opcion_padre_fk; Type: FK CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.menues
    ADD CONSTRAINT menues_opcion_padre_fk FOREIGN KEY (modulo, opcion_padre) REFERENCES seg.menues(modulo, opcion);


--
-- Name: users_business users_business_fk; Type: FK CONSTRAINT; Schema: seg; Owner: postgres
--

ALTER TABLE ONLY seg.users_business
    ADD CONSTRAINT users_business_fk FOREIGN KEY (email) REFERENCES seg.users(email);


--
-- Name: depositos depositos_depa_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.depositos
    ADD CONSTRAINT depositos_depa_id_fk FOREIGN KEY (depa_id) REFERENCES core.tablas(tabl_id);


--
-- Name: depositos depositos_empr_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.depositos
    ADD CONSTRAINT depositos_empr_id_fk FOREIGN KEY (empr_id) REFERENCES sicpoa.empresas(cuit);


--
-- Name: deta_infracciones deta_infracciones_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.deta_infracciones
    ADD CONSTRAINT deta_infracciones_fk FOREIGN KEY (tiin_id) REFERENCES core.tablas(tabl_id);


--
-- Name: detalles_documento detalles_documento_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.detalles_documento
    ADD CONSTRAINT detalles_documento_fk FOREIGN KEY (unme_id) REFERENCES core.tablas(tabl_id);


--
-- Name: detalles_documento detalles_documento_num_documento_tido_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.detalles_documento
    ADD CONSTRAINT detalles_documento_num_documento_tido_id_fk FOREIGN KEY (docu_id, tido_id) REFERENCES sicpoa.documentos(num_documento, tido_id);


--
-- Name: documentos documentos_case_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_case_id_fk FOREIGN KEY (case_id) REFERENCES sicpoa.inspecciones(case_id);


--
-- Name: documentos documentos_empr_id_destino_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_empr_id_destino_fk FOREIGN KEY (empr_id_destino) REFERENCES sicpoa.empresas(cuit);


--
-- Name: documentos documentos_empr_id_emisor_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_empr_id_emisor_fk FOREIGN KEY (empr_id_emisor) REFERENCES sicpoa.empresas(cuit);


--
-- Name: documentos documentos_imag_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_imag_id_fk FOREIGN KEY (imag_id) REFERENCES frm.instancias_formularios(inst_id);


--
-- Name: documentos documentos_tido_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.documentos
    ADD CONSTRAINT documentos_tido_id_fk FOREIGN KEY (tido_id) REFERENCES core.tablas(tabl_id);


--
-- Name: infracciones infracciones_case_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.infracciones
    ADD CONSTRAINT infracciones_case_id_fk FOREIGN KEY (case_id) REFERENCES sicpoa.inspecciones(case_id);


--
-- Name: inspecciones inspecciones_chof_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones
    ADD CONSTRAINT inspecciones_chof_id_fk FOREIGN KEY (chof_id) REFERENCES sicpoa.choferes(dni);


--
-- Name: inspecciones_empresas inspecciones_empresas_case_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_empresas
    ADD CONSTRAINT inspecciones_empresas_case_id_fk FOREIGN KEY (case_id) REFERENCES sicpoa.inspecciones(case_id);


--
-- Name: inspecciones_empresas inspecciones_empresas_depo_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_empresas
    ADD CONSTRAINT inspecciones_empresas_depo_id_fk FOREIGN KEY (depo_id) REFERENCES sicpoa.depositos(depo_id);


--
-- Name: inspecciones_empresas inspecciones_empresas_empr_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_empresas
    ADD CONSTRAINT inspecciones_empresas_empr_id_fk FOREIGN KEY (empr_id) REFERENCES sicpoa.empresas(cuit);


--
-- Name: inspecciones inspecciones_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones
    ADD CONSTRAINT inspecciones_fk FOREIGN KEY (departamento) REFERENCES core.tablas(tabl_id);


--
-- Name: inspecciones inspecciones_inca_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones
    ADD CONSTRAINT inspecciones_inca_id_fk FOREIGN KEY (inca_id) REFERENCES frm.instancias_formularios(inst_id);


--
-- Name: inspecciones inspecciones_petr_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones
    ADD CONSTRAINT inspecciones_petr_id_fk FOREIGN KEY (petr_id) REFERENCES pro.pedidos_trabajo(petr_id);


--
-- Name: inspecciones_termicos inspecciones_termicos_case_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_termicos
    ADD CONSTRAINT inspecciones_termicos_case_id_fk FOREIGN KEY (case_id) REFERENCES sicpoa.inspecciones(case_id);


--
-- Name: inspecciones_termicos inspecciones_termicos_term_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.inspecciones_termicos
    ADD CONSTRAINT inspecciones_termicos_term_id_fk FOREIGN KEY (term_id) REFERENCES sicpoa.termicos(patente);


--
-- Name: permisos_transito permisos_transito_case_id_fk; Type: FK CONSTRAINT; Schema: sicpoa; Owner: postgres
--

ALTER TABLE ONLY sicpoa.permisos_transito
    ADD CONSTRAINT permisos_transito_case_id_fk FOREIGN KEY (case_id) REFERENCES sicpoa.inspecciones(case_id);


--
-- Name: hitos hitos_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.hitos
    ADD CONSTRAINT hitos_fk FOREIGN KEY (petr_id) REFERENCES pro.pedidos_trabajo(petr_id);


--
-- Name: rel_tareas_pedidos newtable_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_tareas_pedidos
    ADD CONSTRAINT newtable_fk FOREIGN KEY (tapl_id) REFERENCES tst.tareas_planificadas(tapl_id);


--
-- Name: rel_tareas_pedidos newtable_fk_1; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_tareas_pedidos
    ADD CONSTRAINT newtable_fk_1 FOREIGN KEY (pema_id) REFERENCES alm.alm_pedidos_materiales(pema_id);


--
-- Name: origen_tarea_planficada origen_tarea_planficada_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.origen_tarea_planficada
    ADD CONSTRAINT origen_tarea_planficada_fk FOREIGN KEY (tapl_id) REFERENCES tst.tareas_planificadas(tapl_id);


--
-- Name: recursos_tareas recursos_tareas_fk_1; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.recursos_tareas
    ADD CONSTRAINT recursos_tareas_fk_1 FOREIGN KEY (tapl_id) REFERENCES tst.tareas_planificadas(tapl_id);


--
-- Name: rel_plantillas_tareas rel_plantillas_tareas_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_plantillas_tareas
    ADD CONSTRAINT rel_plantillas_tareas_fk FOREIGN KEY (tare_id) REFERENCES tst.tareas_std(tare_id);


--
-- Name: rel_plantillas_tareas rel_plantillas_tareas_fk_1; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.rel_plantillas_tareas
    ADD CONSTRAINT rel_plantillas_tareas_fk_1 FOREIGN KEY (plan_id) REFERENCES tst.plantillas(plan_id);


--
-- Name: tareas_planificadas tareas_planificadas_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas
    ADD CONSTRAINT tareas_planificadas_fk FOREIGN KEY (empr_id) REFERENCES core.empresas(empr_id);


--
-- Name: tareas_planificadas tareas_planificadas_form_id_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas
    ADD CONSTRAINT tareas_planificadas_form_id_fk FOREIGN KEY (form_id) REFERENCES frm.formularios(form_id);


--
-- Name: tareas_planificadas tareas_planificadas_rece_id_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas
    ADD CONSTRAINT tareas_planificadas_rece_id_fk FOREIGN KEY (rece_id) REFERENCES prd.formulas(form_id);


--
-- Name: tareas_planificadas tareas_planificadas_tare_id_fk; Type: FK CONSTRAINT; Schema: tst; Owner: postgres
--

ALTER TABLE ONLY tst.tareas_planificadas
    ADD CONSTRAINT tareas_planificadas_tare_id_fk FOREIGN KEY (tare_id) REFERENCES tst.tareas_std(tare_id);


--
-- PostgreSQL database dump complete
--

